"use client";

import { apparentSidebarIsDark, apparentSidebarStyle } from "@/lib/theme-colors/apparent-sidebar";
import { teamPageRequirement } from "@/lib/access/team-route-permissions";
import Link from "@/components/language/link";
import * as React from "react";
import { useTranslations } from "next-intl";
import { usePathname } from "@/hooks/use-locale-navigation";
import {
  ListOrdered,
  LayoutDashboard,
  Users,
  Store,
  Package,
  Tags,
  Tag,
  ShoppingCart,
  Settings,
  BarChart,
  BarChart3,
  SearchX,
  ChevronRight,
  Home,
  ClipboardList,
  Layers,
  Warehouse,
  FileBox,
  ArrowLeftRight,
  Gift,
  Megaphone,
  Percent,
  FileText,
  Globe,
  PlusCircle,
  ArrowLeft,
  MapPin,
  UserCog,
  CreditCard,
  HandCoins,
  MessageSquare,
  Newspaper,
  ListTree,
  Bot,
  CalendarClock,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Rocket,
  Receipt,
  Landmark,
  BookOpen,
  GalleryHorizontalEnd,
  LayoutGrid,
  PanelsTopLeft,
  History,
  UserRound,
  type LucideIcon,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { apparentPaintColor, useAppSettings, presetColors } from "@/stores/app-settings";
import { useAiAvailability } from "@/components/ai-authoring/ai-availability-provider";
import {
  useMultiVendorMode,
  useAppSettings as usePublicAppSettings,
} from "@/providers/app-settings-provider";
import { USER_ROLES } from "@/config/app.config";
import { DEFAULT_STORE_NAME } from "@/config/branding.config";
import { AppImage } from "@/components/ui/app-image";
import { useAppTheme } from "@/providers/theme-provider";
import { useInboxUnreadCount } from "@/hooks/use-inbox-unread-count";
import { SidebarCountBadge } from "@/components/layout/sidebar-count-badge";
import {
  SidebarAccountMenu,
  type AccountMenuLink,
} from "@/components/layout/account-menu";
import { adminSettingsSectionFromPath } from "@/components/admin/settings/settings-sections";
import { AdminSettingsSidebarNav } from "@/components/admin/settings/settings-sidebar-nav";

// Icon mapping
const iconMap: Record<string, LucideIcon> = {
  LayoutDashboard,
  PanelsTopLeft,
  ListOrdered,
  Users,
  Store,
  Package,
  Tags,
  Tag,
  ShoppingCart,
  Settings,
  BarChart,
  BarChart3,
  SearchX,
  Home,
  ClipboardList,
  Layers,
  Warehouse,
  FileBox,
  ArrowLeftRight,
  Gift,
  Megaphone,
  Percent,
  FileText,
  Globe,
  PlusCircle,
  ArrowLeft,
  MapPin,
  UserCog,
  CreditCard,
  HandCoins,
  MessageSquare,
  Newspaper,
  ListTree,
  Bot,
  CalendarClock,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Rocket,
  Receipt,
  Landmark,
  BookOpen,
  GalleryHorizontalEnd,
  LayoutGrid,
  History,
};

/**
 * The sidebar shown beside a POS sub-page.
 *
 * Built per area rather than declared once, because `DashboardSidebar` is
 * mounted by BOTH the admin and the vendor layout. A single `/admin/*` list
 * meant a vendor was offered admin links, and `app/[locale]/admin/layout.tsx`
 * requires `isAdmin` — so following one bounced them to the login page from
 * inside their own dashboard.
 *
 * Reached by vendors on `/vendor/pos/staff`, their till reports (the POS
 * terminal itself renders no sidebar).
 */
type DashboardArea = "admin" | "vendor";

function dashboardAreaFromPath(basePath: string): DashboardArea {
  return basePath === "/vendor" || basePath.startsWith("/vendor/")
    ? "vendor"
    : "admin";
}

function buildPosNavItems(area: DashboardArea): NavItem[] {
  if (area === "vendor") {
    return [
      { label: "pos.newSale", href: "/vendor/pos", icon: "ShoppingCart" },
      {
        label: "admin.sidebar.orders",
        href: "/vendor/orders",
        icon: "ClipboardList",
      },
      // The seller's till reports. Their staff are managed outside POS.
      { label: "pos.reports.navLabel", href: "/vendor/pos/staff", icon: "BarChart3" },
      { label: "admin.sidebar.staff", href: "/vendor/staff", icon: "Users" },
      { label: "locations.title", href: "/vendor/locations", icon: "MapPin" },
    ];
  }

  return [
    { label: "pos.newSale", href: "/admin/pos", icon: "ShoppingCart" },
    {
      label: "admin.sidebar.orders",
      href: "/admin/orders",
      icon: "ClipboardList",
    },
    {
      // Till sales by cashier and counter, and the drawers' counts.
      label: "pos.reports.navLabel",
      href: "/admin/pos/staff",
      icon: "BarChart3",
    },
    {
      // The canonical screen, not the `/admin/pos/locations` redirect that used
      // to live here — locations are no longer a POS-only concern.
      label: "admin.sidebar.posLocations",
      href: "/admin/locations",
      icon: "MapPin",
    },
  ];
}

/** Live counts a nav entry can carry as a badge. Only top-level leaf entries render one. */
type NavCountKey = "inboxUnread";

interface NavItem {
  label: string;
  href: string;
  icon: string;
  items?: NavItem[];
  countKey?: NavCountKey;
}

interface DashboardSidebarProps {
  locale: string;
  user: {
    name: string;
    email: string;
    image?: string;
    role: string;
  };
  vendorPermissions?: string[];
  /**
   * The admin area only: the member's team role (lib/access/team-permissions.ts).
   * A restricted member sees only the areas their role reaches; absent or
   * `fullAccess` shows everything.
   */
  teamAccess?: { fullAccess: boolean; permissions: string[] };
  /**
   * The vendor area only: the store lets vendors see their abandoned
   * checkouts (Vendors → Configuration). Absent reads as off.
   */
  vendorAbandonedCheckouts?: boolean;
  /** The admin area only: the running release, shown under the account menu. */
  appVersion?: string;
}

const adminNavGroups: {
  label: string;
  items: NavItem[];
  collapsible?: boolean;
}[] = [
  {
    label: "",
    items: [
      // ── Overview ──────────────────────────────
      {
        label: "admin.sidebar.overview",
        href: "/admin/dashboard",
        icon: "LayoutDashboard",
      },
            // ── Measure ───────────────────────────────
      {
        label: "admin.sidebar.analytics",
        href: "/admin/analytics",
        icon: "BarChart3",
        // An index child plus a deeper sibling, the same shape as Vendors:
        // the sibling's longer href wins, so only one entry lights up.
        items: [
          {
            label: "admin.sidebar.traffic",
            href: "/admin/analytics",
            icon: "BarChart3",
          },
          {
            label: "admin.sidebar.searchInsights",
            href: "/admin/analytics/search",
            icon: "SearchX",
          },
        ],
      },
      // ── Sell (daily operations) ───────────────
      {
        label: "admin.sidebar.orders",
        href: "/admin/orders",
        icon: "ClipboardList",
        items: [
          {
            label: "admin.sidebar.allOrders",
            href: "/admin/orders",
            icon: "ClipboardList",
          },
          {
            label: "admin.sidebar.preorders",
            href: "/admin/preorders",
            icon: "CalendarClock",
          },
          {
            label: "admin.sidebar.returns",
            href: "/admin/returns",
            icon: "ArrowLeftRight",
          },
          // Pre-sale, so it sits with the order queue rather than under
          // Products: a quote request is a lead being worked, not a catalogue
          // record being edited.
          {
            label: "admin.sidebar.quotes",
            href: "/admin/quotes",
            icon: "FileText",
          },
          {
            label: "admin.sidebar.abandonedCheckouts",
            href: "/admin/abandoned-checkouts",
            icon: "ShoppingCart",
          },
        ],
      },
      {
        label: "admin.sidebar.products",
        href: "/admin/products",
        icon: "Package",
        items: [
          {
            label: "admin.sidebar.allProducts",
            href: "/admin/products",
            icon: "Package",
          },
          {
            label: "admin.sidebar.globalVariants",
            href: "/admin/global-variants",
            icon: "SlidersHorizontal",
          },
          {
            label: "admin.sidebar.collections",
            href: "/admin/collections",
            icon: "Layers",
          },
          {
            label: "admin.sidebar.categories",
            href: "/admin/categories",
            icon: "Tags",
          },
          {
            label: "admin.sidebar.brands",
            href: "/admin/brands",
            icon: "Tag",
          },
          {
            label: "admin.sidebar.inventory",
            href: "/admin/inventory",
            icon: "Warehouse",
          },
          // Between Inventory and Transfers on purpose: Transfers moves stock
          // *between* these, so the thing being moved and the places it moves
          // between read in order.
          {
            label: "locations.title",
            href: "/admin/locations",
            icon: "MapPin",
          },
          // {
          //   label: "admin.sidebar.purchaseOrders",
          //   href: "/admin/purchase-orders",
          //   icon: "FileBox",
          // },
          {
            label: "admin.sidebar.transfers",
            href: "/admin/transfers",
            icon: "ArrowLeftRight",
          },
          {
            label: "admin.sidebar.reviews",
            href: "/admin/reviews",
            icon: "MessageSquare",
          },
          // {
          //   label: "admin.sidebar.giftCards",
          //   href: "/admin/gift-cards",
          //   icon: "Gift",
          // },
        ],
      },
      {
        label: "admin.sidebar.aiStudio",
        href: "/admin/ai-studio",
        icon: "Sparkles",
      },
       {
        label: "admin.sidebar.aiSalesAgent",
        href: "/admin/ai-sales-agent",
        icon: "Bot",
      },
      // ── People ────────────────────────────────
      {
        label: "admin.sidebar.customers",
        href: "/admin/customers",
        icon: "Users",
      },
      {
        label: "admin.sidebar.vendors",
        href: "/admin/vendors",
        icon: "Store",
        items: [
          {
            label: "admin.sidebar.vendors",
            href: "/admin/vendors",
            icon: "Store",
          },
          {
            label: "admin.sidebar.vendorPlans",
            href: "/admin/vendors/plans",
            icon: "Layers",
          },
          {
            label: "admin.sidebar.vendorConfiguration",
            href: "/admin/vendors/configuration",
            icon: "SlidersHorizontal",
          },
          {
            label: "admin.sidebar.vendorOnboarding",
            href: "/admin/vendors/onboarding",
            icon: "ClipboardList",
          },
          {
            label: "admin.sidebar.accessRequests",
            href: "/admin/access-requests",
            icon: "ShieldCheck",
          },
        ],
      },
      {
        label: "admin.sidebar.staff",
        href: "/admin/staff",
        icon: "UserCog",
      },
      // ── Money ─────────────────────────────────
      // "Payments" answered "did this charge go through". "Finance" answers
      // "how is the business doing", which is a different question and takes
      // different screens — so the group is renamed and Overview leads it.
      {
        label: "admin.sidebar.finance",
        href: "/admin/finance",
        icon: "Landmark",
        items: [
          {
            label: "admin.sidebar.financeOverview",
            href: "/admin/finance",
            icon: "Landmark",
          },
          // Stock value and its ledger. The page sits under /admin/inventory
          // for staff who reach it from Inventory; the most-specific-href rule
          // above lights it up here, not under Products.
          {
            label: "admin.sidebar.inventoryLedger",
            href: "/admin/inventory/finance",
            icon: "BookOpen",
          },
          {
            label: "admin.sidebar.expenses",
            href: "/admin/finance/expenses",
            icon: "Receipt",
          },
          {
            label: "admin.sidebar.payouts",
            href: "/admin/payouts",
            icon: "HandCoins",
          },
          {
            label: "admin.sidebar.receivables",
            href: "/admin/finance/receivables",
            icon: "ArrowLeftRight",
          },
          {
            label: "admin.sidebar.payments",
            href: "/admin/payments",
            icon: "CreditCard",
          },
          {
            label: "admin.sidebar.transactions",
            href: "/admin/payments/transactions",
            icon: "CreditCard",
          },
          {
            label: "admin.sidebar.financeReports",
            href: "/admin/finance/reports",
            icon: "FileText",
          },
        ],
      },
      // ── Grow (sales-driving tools) ────────────
      // {
      //   label: "admin.sidebar.marketing",
      //   href: "/admin/marketing",
      //   icon: "Megaphone",
      // },
      {
        label: "admin.sidebar.discounts",
        href: "/admin/discounts",
        icon: "Percent",
      },
      {
        label: "admin.sidebar.boosts",
        href: "/admin/boosts",
        icon: "Rocket",
        items: [
          {
            label: "admin.sidebar.boostCampaigns",
            href: "/admin/boosts",
            icon: "Rocket",
          },
          {
            label: "admin.sidebar.boostPositions",
            href: "/admin/boosts/positions",
            icon: "ListOrdered",
          },
        ],
      },
     
      // ── Engage ────────────────────────────────
      {
        label: "admin.sidebar.content",
        href: "/admin/content/blog-posts",
        icon: "FileText",
        items: [
          {
            label: "admin.sidebar.blogPosts",
            href: "/admin/content/blog-posts",
            icon: "Newspaper",
          },
        ],
      },
      {
        label: "admin.sidebar.inbox",
        href: "/admin/inbox",
        icon: "MessageSquare",
        countKey: "inboxUnread",
      },
      // {
      //   label: "admin.sidebar.markets",
      //   href: "/admin/markets",
      //   icon: "Globe",
      // }
    ],
  },
  {
    label: "admin.sidebar.salesChannels",
    collapsible: true,
    items: [
      {
        label: "admin.sidebar.onlineStore",
        href: "/admin/online-store",
        icon: "Store",
        items: [
          // Customize first: the daily-driver editor. Every storefront
          // template lives INSIDE it (switcher), never as its own item.
          {
            label: "admin.sidebar.customize",
            href: "/admin/online-store/customize",
            icon: "PanelsTopLeft",
          },
          {
            label: "admin.sidebar.themes",
            href: "/admin/online-store/theme",
            icon: "Layers",
          },
          {
            label: "admin.sidebar.pages",
            href: "/admin/online-store/pages",
            icon: "FileText",
          },
          {
            label: "admin.sidebar.navigation",
            href: "/admin/online-store/menus",
            icon: "ListTree",
          },
          {
            label: "admin.sidebar.sliders",
            href: "/admin/online-store/sliders",
            icon: "GalleryHorizontalEnd",
          },
          {
            label: "admin.sidebar.campaignBanners",
            href: "/admin/online-store/campaign-banners",
            icon: "Megaphone",
          },
          {
            label: "admin.sidebar.checkout",
            href: "/admin/online-store/checkout",
            icon: "CreditCard",
          },
          // The store-wide card design plus the catalogue's out-of-stock
          // policy — a dedicated editor like Checkout, so it gets its own
          // entry; templates still live only inside Customize.
          {
            label: "admin.sidebar.productCard",
            href: "/admin/online-store/product-card",
            icon: "LayoutGrid",
          },
        ],
      },
      {
        label: "admin.sidebar.pos",
        href: "/admin/pos",
        icon: "ShoppingCart",
      },
    ],
  },
];

function buildVendorNavGroups(
  permissions: string[] | undefined,
  posEnabled: boolean,
  vendorPlansEnabled: boolean,
  abandonedCheckoutsEnabled: boolean,
): { label: string; items: NavItem[] }[] {
  const perms = new Set(permissions || []);
  const items: NavItem[] = [
    {
      label: "vendor.dashboard",
      href: "/vendor/dashboard",
      icon: "LayoutDashboard",
    },
  ];

  {
    const hasProductAccess =
      perms.has("view_products") ||
      perms.has("manage_products") ||
      perms.has("create_products") ||
      perms.has("edit_products") ||
      perms.has("delete_products");
    const hasBrandAccess = perms.has("view_brands");

    if (hasProductAccess || hasBrandAccess) {
      const productItems: NavItem[] = [];

      if (hasProductAccess) {
        productItems.push(
          {
            label: "admin.sidebar.allProducts",
            href: "/vendor/products",
            icon: "Package",
          },
          {
            label: "admin.sidebar.inventory",
            href: "/vendor/inventory",
            icon: "Warehouse",
          },
          // Next to Inventory rather than under POS: the two are read together
          // (the inventory list filters by location, the product form stocks
          // by it), and burying this under the register is what left vendors
          // with the register switched off unable to find it at all.
          {
            label: "locations.title",
            href: "/vendor/locations",
            icon: "MapPin",
          },
          // Moving stock between those locations, as the admin nav places it.
          {
            label: "admin.sidebar.transfers",
            href: "/vendor/transfers",
            icon: "ArrowLeftRight",
          },
        );
      }

      if (hasBrandAccess) {
        productItems.push({
          label: "admin.sidebar.brands",
          href: "/vendor/brands",
          icon: "Tag",
        });
      }

      items.push({
        label: "vendor.products",
        href: productItems[0].href,
        icon: "Package",
        items: productItems,
      });
    }
  }

  if (
    perms.has("view_orders") ||
    perms.has("manage_orders") ||
    perms.has("create_orders") ||
    perms.has("edit_orders") ||
    perms.has("delete_orders")
  ) {
    items.push({
      label: "vendor.orders",
      href: "/vendor/orders",
      icon: "ShoppingCart",
      items: [
        {
          label: "admin.sidebar.allOrders",
          href: "/vendor/orders",
          icon: "ClipboardList",
        },
        {
          label: "admin.sidebar.preorders",
          href: "/vendor/preorders",
          icon: "CalendarClock",
        },
        {
          label: "admin.sidebar.returns",
          href: "/vendor/returns",
          icon: "ArrowLeftRight",
        },
        // Requests for a price on this vendor's own products, which the
        // vendor answers unless the store has taken the quote over.
        {
          label: "admin.sidebar.quotes",
          href: "/vendor/quotes",
          icon: "FileText",
        },
        // The checkouts that held this vendor's products, its own lines
        // only — unless the store has switched the page off for vendors.
        ...(abandonedCheckoutsEnabled
          ? [
              {
                label: "admin.sidebar.abandonedCheckouts",
                href: "/vendor/abandoned-checkouts",
                icon: "ShoppingCart",
              },
            ]
          : []),
      ],
    });
    // Derived entirely from the vendor's own orders (registered and guest
    // buyers alike), so it shares the order-viewing gate rather than needing
    // a permission of its own.
    items.push({
      label: "admin.sidebar.customers",
      href: "/vendor/customers",
      icon: "Users",
    });
  }

  if (
    perms.has("view_payouts") ||
    perms.has("manage_payouts") ||
    perms.has("create_payouts") ||
    perms.has("edit_payouts") ||
    perms.has("delete_payouts")
  ) {
    // One group rather than two flat entries: a payout is the end of a story
    // the other screens tell, and a vendor asking "why is this the number"
    // should find the answer next to it rather than somewhere else in the nav.
    items.push({
      label: "vendor.finance",
      href: "/vendor/finance",
      icon: "Landmark",
      items: [
        {
          label: "admin.sidebar.financeOverview",
          href: "/vendor/finance",
          icon: "Landmark",
        },
        {
          label: "vendor.statements",
          href: "/vendor/finance/statements",
          icon: "FileText",
        },
        {
          label: "admin.sidebar.expenses",
          href: "/vendor/finance/expenses",
          icon: "Receipt",
        },
        {
          label: "vendor.payouts",
          href: "/vendor/payouts",
          icon: "HandCoins",
        },
        {
          label: "vendor.owedToPlatform",
          href: "/vendor/finance/owed",
          icon: "ArrowLeftRight",
        },
      ],
    });
  }

  if (
    perms.has("view_inbox") ||
    perms.has("reply_inbox") ||
    perms.has("manage_inbox")
  ) {
    items.push({
      label: "admin.sidebar.inbox",
      href: "/vendor/inbox",
      icon: "MessageSquare",
      countKey: "inboxUnread",
    });
  }

  if (
    perms.has("view_discounts") ||
    perms.has("manage_discounts") ||
    perms.has("create_discounts") ||
    perms.has("edit_discounts") ||
    perms.has("delete_discounts") ||
    perms.has("manage_products") ||
    perms.has("create_products") ||
    perms.has("edit_products") ||
    perms.has("delete_products")
  ) {
    items.push({
      label: "admin.sidebar.discounts",
      href: "/vendor/discounts",
      icon: "Percent",
    });
  }

  if (perms.has("view_boosts") || perms.has("manage_boosts")) {
    items.push({
      label: "vendor.boosts",
      href: "/vendor/boosts",
      icon: "Rocket",
    });
  }

  // Gated on the store-settings permissions the billing page itself requires,
  // so the entry is never offered to someone the page would bounce: a plan
  // sets the commission rate and the product/staff ceilings, which makes it
  // the concern of whoever configures the store rather than whoever
  // reconciles its payouts.
  if (
    vendorPlansEnabled &&
    (perms.has("view_store_settings") ||
      perms.has("manage_store_settings") ||
      perms.has("edit_store_settings"))
  ) {
    items.push({
      label: "vendor.planBilling",
      href: "/vendor/billing",
      icon: "CreditCard",
    });
  }

  // The Activity log is not behind a permission: this sidebar is only ever the
  // store owner's (vendor staff work in /staff), and "My activity" is the
  // owner's own history. The staff tab inside the page is what `view_staff`
  // gates, on the server. It lives under Team because the team's activity is
  // what most of it is about — and stays a plain entry when Team is hidden, so
  // it is never offered inside a group the viewer cannot open.
  const activityLogItem: NavItem = {
    label: "admin.sidebar.activityLog",
    href: "/vendor/activity-log",
    icon: "History",
  };

  if (
    perms.has("view_staff") ||
    perms.has("manage_staff") ||
    perms.has("create_staff") ||
    perms.has("edit_staff") ||
    perms.has("delete_staff") ||
    perms.has("manage_store_settings")
  ) {
    items.push({
      label: "admin.sidebar.staff",
      href: "/vendor/staff",
      icon: "UserCog",
      items: [
        {
          label: "admin.sidebar.staffMembers",
          href: "/vendor/staff",
          icon: "Users",
        },
        activityLogItem,
      ],
    });
  } else {
    items.push(activityLogItem);
  }

  // Online Store and POS sit under their own Sales Channels heading, as they
  // do in the admin nav.
  const salesChannelItems: NavItem[] = [];

  // The Vendor CMS, named and shaped like the admin's Online Store: the
  // vendor's own landing page (the Home tab of their storefront) and the
  // sliders it places. Gated like the store profile it sits beside.
  if (
    perms.has("view_store_settings") ||
    perms.has("manage_store_settings") ||
    perms.has("edit_store_settings")
  ) {
    salesChannelItems.push({
      label: "admin.sidebar.onlineStore",
      href: "/vendor/online-store",
      icon: "Store",
      items: [
        {
          label: "admin.sidebar.customize",
          href: "/vendor/online-store/customize",
          icon: "PanelsTopLeft",
        },
        {
          label: "admin.sidebar.sliders",
          href: "/vendor/online-store/sliders",
          icon: "GalleryHorizontalEnd",
        },
        {
          label: "admin.sidebar.campaignBanners",
          href: "/vendor/online-store/campaign-banners",
          icon: "Megaphone",
        },
      ],
    });
  }

  if (posEnabled && perms.has("access_pos")) {
    salesChannelItems.push({
      label: "admin.sidebar.pos",
      href: "/vendor/pos",
      icon: "ShoppingCart",
    });
    items.push({
      label: "pos.reports.navLabel",
      href: "/vendor/pos/staff",
      icon: "BarChart3",
    });
  }

  if (salesChannelItems.length === 0) {
    return [{ label: "", items }];
  }

  return [
    { label: "", items },
    { label: "admin.sidebar.salesChannels", items: salesChannelItems },
  ];
}

function filterNavGroupsByHref<T extends { items: NavItem[] }>(
  groups: T[],
  blockedHrefs: Set<string>,
): T[] {
  return groups.map((group) => ({
    ...group,
    items: filterNavItemsByHref(group.items, blockedHrefs),
  }));
}

function filterNavGroupsByTeamRole<T extends { items: NavItem[] }>(
  groups: T[],
  reaches: (href: string) => boolean,
): T[] {
  return groups
    .map((group) => ({ ...group, items: filterNavItemsByTeamRole(group.items, reaches) }))
    .filter((group) => group.items.length > 0);
}

/** A section stays while any entry under it is reachable; a leaf, when it is. */
function filterNavItemsByTeamRole(
  items: NavItem[],
  reaches: (href: string) => boolean,
): NavItem[] {
  return items.flatMap((item) => {
    if (item.items) {
      const children = filterNavItemsByTeamRole(item.items, reaches);
      return children.length > 0 ? [{ ...item, items: children }] : [];
    }
    return reaches(item.href) ? [item] : [];
  });
}

function filterNavItemsByHref(
  items: NavItem[],
  blockedHrefs: Set<string>,
): NavItem[] {
  return items
    .filter((item) => !blockedHrefs.has(item.href))
    .map((item) => ({
      ...item,
      items: item.items
        ? filterNavItemsByHref(item.items, blockedHrefs)
        : undefined,
    }));
}

// Determine whether `href` is the active nav target for the current path.
// Exact matches always win. A prefix match (basePath nested under href) only
// counts when no other href in the tree is a longer, more specific match — so
// an "index" child (/admin/vendors) does not light up alongside the deeper
// sibling that actually matches (/admin/vendors/onboarding), and a page listed
// in one section (Finance › /admin/inventory/finance) does not also light up
// the section whose href it happens to sit under (Products › /admin/inventory).
export function isNavHrefActive(
  basePath: string,
  href: string,
  siblingHrefs: string[],
): boolean {
  if (basePath === href) return true;
  if (!basePath.startsWith(`${href}/`)) return false;
  return !siblingHrefs.some(
    (other) =>
      other !== href &&
      other.length > href.length &&
      (basePath === other || basePath.startsWith(`${other}/`)),
  );
}

// Every sidebar link is `prefetch={false}` on purpose. The tree holds 50–90
// links, and Next 16's viewport prefetch rendered a `/_tree` partial for each
// of them on every dashboard page view — more server work than the page
// itself. A click now pays one round trip instead (with `false`, Next 16 does
// not prefetch on hover either).
function CollapsedHoverSubmenu({
  item,
  submenuItems,
  Icon,
  isActive,
  isApparent,
  isRTL,
  basePath,
  navHrefs,
  tLabel,
}: {
  item: NavItem;
  submenuItems: NavItem[];
  Icon: LucideIcon;
  isActive: boolean;
  isApparent: boolean;
  isRTL: boolean;
  basePath: string;
  /** Every href in the tree; the most specific match wins. */
  navHrefs: string[];
  tLabel: (key: string) => string;
}) {
  const [open, setOpen] = React.useState(false);
  const closeTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const cancelClose = React.useCallback(() => {
    if (closeTimer.current) {
      clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
  }, []);

  const scheduleClose = React.useCallback(() => {
    cancelClose();
    closeTimer.current = setTimeout(() => setOpen(false), 120);
  }, [cancelClose]);

  React.useEffect(() => () => cancelClose(), [cancelClose]);

  return (
    <SidebarMenuItem
      className="group-data-[collapsible=icon]:w-full"
      onMouseEnter={() => {
        cancelClose();
        setOpen(true);
      }}
      onMouseLeave={scheduleClose}
    >
      <DropdownMenu open={open} onOpenChange={setOpen} modal={false}>
        <DropdownMenuTrigger asChild>
          <SidebarMenuButton
            size="sm"
            isActive={isActive}
            className={cn(
              "relative rounded-lg px-3 py-2.5 h-9 text-[13px] transition-colors w-full justify-center group/btn cursor-pointer",
              "group-data-[collapsible=icon]:h-auto group-data-[collapsible=icon]:w-full group-data-[collapsible=icon]:py-3 group-data-[collapsible=icon]:flex-col group-data-[collapsible=icon]:gap-1.5 group-data-[collapsible=icon]:rounded-md group-data-[collapsible=icon]:px-1.5",
              isApparent
                ? isActive
                  ? "bg-white/20 text-white hover:bg-white/25 font-semibold"
                  : "text-white/80 hover:bg-white/10 hover:text-white font-semibold"
                : isActive
                  ? "bg-primary/10 text-primary hover:bg-primary/10 dark:bg-white/15 dark:text-white dark:hover:bg-white/20 font-semibold"
                  : "text-foreground/70 hover:bg-muted/60 hover:text-foreground font-semibold",
            )}
          >
            <Icon className="size-4.5 shrink-0 stroke-2 transition-transform duration-300 group-data-[collapsible=icon]:size-5" />
            {/* The flyout cue: a small chevron at the tile's edge, level with
                the icon, so the icon keeps the size and axis of the entries
                without a submenu. The span keeps it out of the menu button's
                `[&>svg]:size-5`, which would otherwise enlarge it. */}
            <span
              className={cn(
                "pointer-events-none absolute top-2 flex h-5 items-center opacity-60 transition duration-200 group-data-[state=open]/btn:opacity-100",
                isRTL
                  ? "left-1.5 group-data-[state=open]/btn:-translate-x-0.5"
                  : "right-1.5 group-data-[state=open]/btn:translate-x-0.5",
                isApparent
                  ? "text-white/70"
                  : isActive
                    ? "text-sidebar-accent-foreground"
                    : "text-muted-foreground",
              )}
              aria-hidden="true"
            >
              <ChevronRight
                className={cn("size-3 stroke-[2.5]", isRTL && "rotate-180")}
              />
            </span>
            <span
              className={cn(
                "hidden text-[11px] leading-tight group-data-[collapsible=icon]:block text-center wrap-break-word whitespace-normal overflow-visible",
                isApparent
                  ? "text-white"
                  : isActive
                    ? "text-sidebar-accent-foreground"
                    : "text-muted-foreground",
              )}
            >
              {tLabel(item.label)}
            </span>
          </SidebarMenuButton>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          side={isRTL ? "left" : "right"}
          align="start"
          sideOffset={10}
          onMouseEnter={cancelClose}
          onMouseLeave={scheduleClose}
          onCloseAutoFocus={(e) => e.preventDefault()}
          className="w-56 p-2 rounded-2xl shadow-xl border-border/50 bg-popover/95 backdrop-blur-sm"
        >
          {submenuItems.map((child) => {
            const isChildItemActive = isNavHrefActive(
              basePath,
              child.href,
              navHrefs,
            );
            return (
              <DropdownMenuItem
                key={child.href}
                asChild
                className="p-0 mb-0.5 last:mb-0 focus:bg-transparent"
              >
                <Link
                  prefetch={false}
                  href={child.href}
                  className={cn(
                    "flex w-full items-center gap-2 px-3 py-1.5 rounded-xl cursor-pointer transition-colors",
                    isChildItemActive
                      ? "bg-muted text-foreground font-semibold"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground",
                  )}
                >
                  <span className="text-sm">{tLabel(child.label)}</span>
                </Link>
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    </SidebarMenuItem>
  );
}

// The sidebar's foot: the signed-in account, with the release under it in the
// admin area.
function DashboardSidebarFooter({
  locale,
  user,
  accountLinks,
  appVersion,
  isApparent,
  isRTL,
  isIconCollapsed,
}: {
  locale: string;
  user: { name: string; email: string; image?: string };
  accountLinks: AccountMenuLink[];
  appVersion?: string;
  isApparent: boolean;
  isRTL: boolean;
  isIconCollapsed: boolean;
}) {
  const t = useTranslations();

  return (
    <SidebarFooter className="mt-auto gap-2 px-3 py-3 group-data-[collapsible=icon]:p-2">
      <SidebarAccountMenu
        locale={locale}
        user={user}
        links={accountLinks}
        isApparent={isApparent}
        isRTL={isRTL}
        isIconCollapsed={isIconCollapsed}
      />
      {appVersion && (
        <p
          className={cn(
            "text-center text-[11px] leading-none tabular-nums",
            isApparent ? "text-white/70" : "text-muted-foreground",
          )}
        >
          <span className="group-data-[collapsible=icon]:hidden">
            {t("admin.accountMenu.version", { version: `v${appVersion}` })}
          </span>
          <span className="hidden group-data-[collapsible=icon]:inline">
            v{appVersion}
          </span>
        </p>
      )}
    </SidebarFooter>
  );
}

// Scrolls the menu just far enough to show a section that has just opened —
// its header and the links under it — but never so far that the header itself
// leaves the top, when the links are longer than the menu is tall.
function revealOpenedSection(header: HTMLElement) {
  const scroller = header.closest<HTMLElement>(
    '[data-slot="sidebar-content-scroller"]',
  );
  const item = header.closest<HTMLElement>(
    '[data-sidebar="menu-sub-item"], [data-sidebar="menu-item"]',
  );
  if (!scroller || !item) return;

  // A top-level section's links render inside its item; a nested section's in
  // the list that follows it.
  const links =
    item.dataset.sidebar === "menu-item"
      ? item
      : ((item.nextElementSibling as HTMLElement | null) ?? item);
  const view = scroller.getBoundingClientRect();
  const gap = 12;
  const overflow = links.getBoundingClientRect().bottom + gap - view.bottom;
  const headroom = header.getBoundingClientRect().top - gap - view.top;
  const distance = Math.min(overflow, headroom);
  if (distance <= 0) return;

  const reduceMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)",
  ).matches;
  scroller.scrollBy({
    top: distance,
    behavior: reduceMotion ? "auto" : "smooth",
  });
}

export function DashboardSidebar({
  locale,
  user,
  vendorPermissions,
  teamAccess,
  vendorAbandonedCheckouts = false,
  appVersion,
}: DashboardSidebarProps) {
  const t = useTranslations();
  const pathname = usePathname();
  const basePath = React.useMemo(() => {
    const prefix = `/${locale}`;
    if (pathname?.startsWith(prefix)) {
      const stripped = pathname.slice(prefix.length);
      return stripped.length ? stripped : "/";
    }
    return pathname;
  }, [pathname, locale]);
  const { navColor, navPaint, presetColor, primaryColor, secondaryColor, previewBrand, rtl } = useAppSettings();
  const { isMultiVendor } = useMultiVendorMode();
  const {
    storeName,
    logoUrl,
    darkModeLogoUrl,
    faviconUrl,
    posEnabled,
    boostingEnabled,
    vendorPlansEnabled,
  } = usePublicAppSettings();
  const { isDark } = useAppTheme();
  const { state: sidebarState, isMobile } = useSidebar();
  const tLabel = React.useCallback(
    (key: string) => {
      if (!key.includes(".")) return key;
      try {
        return t(key as never);
      } catch {
        return key;
      }
    },
    [t],
  );

  // Detect if we're on a POS page
  const isPosTerminal =
    basePath === "/admin/pos" ||
    basePath === "/vendor/pos" ||
    basePath === "/staff/pos";
  const isPosPage =
    isPosTerminal ||
    basePath.startsWith("/admin/pos/") ||
    basePath.startsWith("/vendor/pos/") ||
    basePath.startsWith("/staff/pos/");

  // Settings open inside the dashboard: while one of its pages is showing, the
  // settings menu takes the main menu's place, with a way back out under its
  // search box.
  const settingsSectionId =
    user.role === USER_ROLES.ADMIN
      ? adminSettingsSectionFromPath(basePath)
      : null;

  // Keyed off the path, not the role: an admin browsing the vendor area must
  // still be offered the vendor links they are actually looking at.
  const posNavItems = React.useMemo(
    () => buildPosNavItems(dashboardAreaFromPath(basePath)),
    [basePath],
  );

  // Settings → AI also governs the hub entry: the page behind it exists to
  // launch generation, so offering it while AI is off sends the user to a
  // warning banner instead of a tool.
  const { available: aiAvailable } = useAiAvailability();

  const navGroups = React.useMemo(() => {
    // Only two areas mount this component — `app/[locale]/admin/layout.tsx`
    // (which requires `isAdmin`) and `app/[locale]/vendor/layout.tsx`. Staff get
    // `components/staff/staff-sidebar.tsx` instead, so the staff arm that used
    // to sit here was unreachable, and its `/admin/*` hrefs would have bounced
    // a staff user to login had anything ever rendered them.
    const baseGroups =
      user.role === USER_ROLES.ADMIN
        ? adminNavGroups
        : buildVendorNavGroups(
            vendorPermissions,
            Boolean(posEnabled),
            Boolean(vendorPlansEnabled),
            vendorAbandonedCheckouts,
          );

    let nextGroups = baseGroups;

    if (!isMultiVendor && user.role === USER_ROLES.ADMIN) {
      nextGroups = filterNavGroupsByHref(
        nextGroups,
        new Set(["/admin/vendors", "/admin/payouts"]),
      );
    }

    if (!isMultiVendor && user.role === USER_ROLES.VENDOR) {
      nextGroups = filterNavGroupsByHref(
        nextGroups,
        new Set(["/vendor/preorders"]),
      );
    }

    if (!boostingEnabled) {
      nextGroups = filterNavGroupsByHref(
        nextGroups,
        new Set(["/vendor/boosts", "/admin/boosts"]),
      );
    }

    if (!aiAvailable) {
      nextGroups = filterNavGroupsByHref(
        nextGroups,
        new Set(["/admin/ai-studio"]),
      );
    }

    if (user.role === USER_ROLES.ADMIN && !posEnabled) {
      nextGroups = nextGroups.map((group) => {
        if (group.label === "admin.sidebar.salesChannels") {
          return {
            ...group,
            items: group.items.filter((item) => item.href !== "/admin/pos"),
          };
        }
        return group;
      });
    }

    // A restricted team role: only the areas it reaches, by the same rules the
    // area layouts enforce.
    if (user.role === USER_ROLES.ADMIN && teamAccess && !teamAccess.fullAccess) {
      const held = new Set(teamAccess.permissions);
      nextGroups = filterNavGroupsByTeamRole(nextGroups, (href) => {
        const required = teamPageRequirement(href);
        return !required || required.length === 0 || required.some((permission) => held.has(permission));
      });
    }

    return nextGroups;
  }, [
    teamAccess,
    user.role,
    isMultiVendor,
    posEnabled,
    boostingEnabled,
    aiAvailable,
    vendorPlansEnabled,
    vendorPermissions,
    vendorAbandonedCheckouts,
  ]);

  const navHrefs = React.useMemo(
    () =>
      navGroups.flatMap((group) =>
        group.items.flatMap((item) => [
          item.href,
          ...(item.items ?? []).flatMap((child) => [
            child.href,
            ...(child.items ?? []).map((grandChild) => grandChild.href),
          ]),
        ]),
      ),
    [navGroups],
  );

  // Polled only when Inbox is actually in the nav: a vendor without inbox
  // access would be answered 403 on every tick.
  const hasInboxEntry = navGroups.some((group) =>
    group.items.some((item) => item.countKey === "inboxUnread"),
  );
  const inboxUnread = useInboxUnreadCount(
    hasInboxEntry && !isPosPage && !settingsSectionId,
  );
  const navCounts: Record<NavCountKey, number> = { inboxUnread };

  // RTL detection based on locale OR manual setting
  const isRTL = locale === "ar" || rtl; // Arabic locale or manual RTL toggle
  const sidebarSide = isRTL ? "right" : "left";

  // Force collapsed behavior to minimize (icon rail)
  const collapsible = "icon";
  const isIconCollapsed =
    !isMobile && collapsible === "icon" && sidebarState === "collapsed";

  // Determine if using apparent (brand-painted) sidebar
  const isApparent = navColor === "apparent";

  // The apparent sidebar's paint: the live theme's primary, or its secondary
  // when the viewer chose it (Preferences) — or the theme editor's unsaved
  // colours while it is open. The built-in preset hex backs up legacy
  // documents where the colour may be missing.
  const paintColor = apparentPaintColor({ navPaint, primaryColor, secondaryColor, previewBrand });
  const presetColorHex =
    typeof paintColor === "string" && paintColor.trim()
      ? paintColor
      : presetColors[presetColor]?.hex;
  // The logo's dark-surface artwork only where the sidebar IS dark: a light
  // brand (cyan, orange) paints a light apparent sidebar.
  const useDarkSidebarBrand =
    isDark || (isApparent && apparentSidebarIsDark(presetColorHex));
  const currentLogoUrl =
    useDarkSidebarBrand &&
    typeof darkModeLogoUrl === "string" &&
    darkModeLogoUrl.trim()
      ? darkModeLogoUrl
      : typeof logoUrl === "string" && logoUrl.trim()
        ? logoUrl
        : "";
  // No bundled icon backs this up — an unconfigured favicon shows the store's
  // initial, never this app's own mark.
  const currentFaviconUrl =
    typeof faviconUrl === "string" && faviconUrl.trim() ? faviconUrl : "";
  const brandStoreName =
    typeof storeName === "string" && storeName.trim()
      ? storeName
      : DEFAULT_STORE_NAME;

  const renderSidebarBrand = () => {
    if (isIconCollapsed) {
      return (
        <span className="relative block h-8 w-8 shrink-0 overflow-hidden rounded-md">
          {currentFaviconUrl ? (
            <AppImage
              src={currentFaviconUrl}
              alt="Favicon"
              className="h-8 w-8 object-contain"
              width={32}
              height={32}
            />
          ) : (
            <span
              className={cn(
                "flex h-8 w-8 items-center justify-center rounded-md text-sm font-bold",
                isApparent
                  ? "bg-white/15 text-white"
                  : "bg-primary/10 text-primary",
              )}
            >
              {brandStoreName.trim().charAt(0).toUpperCase()}
            </span>
          )}
        </span>
      );
    }

    if (currentLogoUrl) {
      return (
        <span className="relative block h-8 w-full overflow-hidden">
          <AppImage
            src={currentLogoUrl}
            alt="Logo"
            className="h-8 w-full object-contain object-left"
            width={224}
            height={32}
          />
        </span>
      );
    }

    return (
      <span
        className={cn(
          "block text-lg font-bold truncate",
          isApparent
            ? "text-white"
            : "bg-linear-to-r from-primary to-primary/70 bg-clip-text text-transparent",
        )}
      >
        {brandStoreName}
      </span>
    );
  };

  const initiallyOpenHrefs = React.useMemo(() => {
    const openSet = new Set<string>();
    for (const group of navGroups) {
      for (const item of group.items) {
        const children = item.items;
        if (!children?.length) continue;
        const isSelfActive = isNavHrefActive(basePath, item.href, navHrefs);
        const isChildActive = children.some(
          (child) =>
            isNavHrefActive(basePath, child.href, navHrefs) ||
            (child.items ?? []).some((grandChild) =>
              isNavHrefActive(basePath, grandChild.href, navHrefs),
            ),
        );
        if (isSelfActive || isChildActive) openSet.add(item.href);
      }
    }
    return openSet;
  }, [navGroups, navHrefs, basePath]);

  const [openSections, setOpenSections] = React.useState<Set<string>>(
    () => initiallyOpenHrefs,
  );

  React.useEffect(() => {
    const timer = window.setTimeout(() => {
      setOpenSections(initiallyOpenHrefs);
    }, 0);
    return () => window.clearTimeout(timer);
  }, [initiallyOpenHrefs]);

  const toggleSection = React.useCallback((href: string) => {
    setOpenSections((prev) => {
      const next = new Set(prev);
      if (next.has(href)) next.delete(href);
      else next.add(href);
      return next;
    });
  }, []);

  // The header of the section a click just opened. Once it renders open, the
  // menu scrolls its links into view — a section near the bottom (Online
  // Store) would otherwise unfold out of sight, under the footer.
  const revealAfterOpen = React.useRef<HTMLElement | null>(null);
  React.useEffect(() => {
    const header = revealAfterOpen.current;
    revealAfterOpen.current = null;
    if (header?.isConnected) revealOpenedSection(header);
  }, [openSections]);

  // Removed hover-controlled flyout state to make submenus open on click only
  const canAccessVendorSettings = React.useMemo(() => {
    if (user.role !== USER_ROLES.VENDOR) {
      return false;
    }

    const perms = new Set(vendorPermissions || []);
    return (
      perms.has("view_store_settings") ||
      perms.has("manage_store_settings") ||
      perms.has("create_store_settings") ||
      perms.has("edit_store_settings") ||
      perms.has("delete_store_settings")
    );
  }, [user.role, vendorPermissions]);

  // The signed-in person's own pages, offered by the account menu at the
  // sidebar's foot.
  const accountLinks = React.useMemo<AccountMenuLink[]>(() => {
    if (user.role === USER_ROLES.ADMIN) {
      return [
        { href: "/admin/profile", label: t("adminProfile.title"), Icon: UserRound },
        // Straight to the first section: `/admin/settings` only redirects
        // there, at the cost of a second round trip through its layout.
        { href: "/admin/settings/general", label: t("common.settings"), Icon: Settings },
      ];
    }

    // A vendor's profile is a tab of their settings page, behind the same
    // permission.
    if (canAccessVendorSettings) {
      return [
        { href: "/vendor/settings?tab=account", label: t("common.profile"), Icon: UserRound },
        { href: "/vendor/settings", label: tLabel("vendor.settings"), Icon: Settings },
      ];
    }

    return [];
  }, [user.role, canAccessVendorSettings, t, tLabel]);


  // ============================================
  // POS Terminal — no sidebar (fullscreen)
  // ============================================
  if (isPosTerminal) {
    return null;
  }

  // ============================================
  // POS Sub-pages Sidebar (staff, locations)
  // ============================================
  if (isPosPage) {
    return (
      <Sidebar
        key={`pos-sidebar-${locale}-${sidebarSide}`}
        side={sidebarSide}
        className={cn(
          // Navigation is chrome, not content — keep it out of print output.
          "border-r-0 transition-colors duration-300 print:hidden",
          isRTL && "border-l-0 border-r",
        )}
        style={
          isApparent
            ? apparentSidebarStyle(presetColorHex)
            : undefined
        }
        collapsible={collapsible}
      >
        {!isMobile && (
          <div
            suppressHydrationWarning
            className={`absolute top-0 bottom-0 w-px ${
              isApparent ? "bg-white/30" : "bg-border"
            } z-30 pointer-events-none ${isRTL ? "-left-px" : "-right-px"}`}
          />
        )}
        <SidebarHeader className="border-b-0 px-3 py-3 relative group-data-[collapsible=icon]:px-2">
          <Link
            prefetch={false}
            href="/"
            className="flex w-full items-center px-4 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0"
          >
            {renderSidebarBrand()}
          </Link>
        </SidebarHeader>

        <SidebarContent className="px-3 group-data-[collapsible=icon]:px-1 group-data-[collapsible=icon]:gap-1">
          {/* Back to Admin */}
          <SidebarGroup className="group-data-[collapsible=icon]:px-1 group-data-[collapsible=icon]:py-2">
            <SidebarGroupContent>
              <SidebarMenu className="gap-2 group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:gap-3">
                <SidebarMenuItem>
                  <SidebarMenuButton
                    asChild
                    size="sm"
                    className={cn(
                      "rounded-lg px-3 py-2.5 h-9 text-[13px] transition-colors group-data-[collapsible=icon]:h-auto group-data-[collapsible=icon]:w-full group-data-[collapsible=icon]:rounded-md group-data-[collapsible=icon]:px-2 group-data-[collapsible=icon]:py-3 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:flex-col group-data-[collapsible=icon]:gap-1.5",
                      isApparent
                        ? "text-white/80 hover:bg-white/10 hover:text-white font-semibold"
                        : "text-foreground/70 hover:bg-muted/60 hover:text-foreground font-semibold",
                    )}
                  >
                    <Link prefetch={false} href="/admin/dashboard" className="relative w-full">
                      <div className="flex items-center gap-3 w-full group-data-[collapsible=icon]:justify-center">
                        <ArrowLeft className="size-4.5 shrink-0 stroke-2 transition-transform duration-300 group-data-[collapsible=icon]:size-5" />
                        <span className="group-data-[collapsible=icon]:hidden">
                          {t("common.backToDashboard")}
                        </span>
                      </div>
                      <span
                        className={cn(
                          "hidden text-[11px] leading-tight group-data-[collapsible=icon]:block text-center",
                          isApparent ? "text-white" : "text-muted-foreground",
                        )}
                      >
                        {t("common.back")}
                      </span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>

          {/* POS Navigation */}
          <SidebarGroup className="group-data-[collapsible=icon]:px-1 group-data-[collapsible=icon]:py-2">
            <SidebarGroupLabel
              className={cn(
                "px-4 mb-1 text-[11px] font-semibold tracking-[0.08em] group-data-[collapsible=icon]:hidden uppercase",
                isApparent ? "text-white/60" : "text-muted-foreground/60",
              )}
            >
              {t("admin.sidebar.pos")}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu className="gap-1 group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:gap-3">
                {posNavItems.map((item) => {
                  const Icon = iconMap[item.icon] || Package;
                  // The register's own href, whichever area we are in. It was
                  // hardcoded to `/admin/pos`, so in the vendor area nothing
                  // suppressed the prefix match and "New Sale" lit up on every
                  // POS sub-page alongside the item actually open.
                  const posRootHref = posNavItems[0]?.href;
                  const isPosRoot = item.href === posRootHref;
                  const isItemActive = isPosRoot
                    ? // Exact only: every sub-page sits under this href.
                      basePath === item.href
                    : basePath === item.href ||
                      basePath.startsWith(`${item.href}/`);

                  return (
                    <SidebarMenuItem
                      key={item.href}
                      className="group-data-[collapsible=icon]:w-full"
                    >
                      <SidebarMenuButton
                        asChild
                        size="sm"
                        isActive={isItemActive}
                        className={cn(
                          "rounded-lg px-3 py-2.5 h-9 text-[13px] transition-colors group-data-[collapsible=icon]:h-auto group-data-[collapsible=icon]:w-full group-data-[collapsible=icon]:rounded-md group-data-[collapsible=icon]:px-2 group-data-[collapsible=icon]:py-3 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:flex-col group-data-[collapsible=icon]:gap-1.5",
                          isApparent
                            ? isItemActive
                              ? "bg-white/20 text-white hover:bg-white/25 font-semibold"
                              : "text-white/80 hover:bg-white/10 hover:text-white font-semibold"
                            : isItemActive
                              ? "bg-primary/10 text-primary hover:bg-primary/10 dark:bg-white/15 dark:text-white dark:hover:bg-white/20 font-semibold"
                              : "text-foreground/70 hover:bg-muted/60 hover:text-foreground font-semibold",
                        )}
                      >
                        <Link prefetch={false} href={item.href} className="relative w-full">
                          <div className="flex items-center gap-3 w-full group-data-[collapsible=icon]:justify-center">
                            <Icon className="size-4.5 shrink-0 stroke-2 transition-transform duration-300 group-data-[collapsible=icon]:size-5" />
                            <span className="group-data-[collapsible=icon]:hidden">
                              {tLabel(item.label)}
                            </span>
                          </div>
                          <span
                            className={cn(
                              "hidden text-[11px] leading-tight group-data-[collapsible=icon]:block text-center",
                              isApparent
                                ? "text-white"
                                : isItemActive
                                  ? "text-sidebar-accent-foreground"
                                  : "text-muted-foreground",
                            )}
                          >
                            {tLabel(item.label)}
                          </span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>

        <DashboardSidebarFooter
          locale={locale}
          user={user}
          accountLinks={accountLinks}
          appVersion={appVersion}
          isApparent={isApparent}
          isRTL={isRTL}
          isIconCollapsed={isIconCollapsed}
        />
      </Sidebar>
    );
  }

  // ============================================
  // Default Admin/Vendor Sidebar
  // ============================================
  return (
    <Sidebar
      key={`dashboard-sidebar-${locale}-${sidebarSide}`}
      side={sidebarSide}
      className={cn(
        "border-r-0 transition-colors duration-300",
        isRTL && "border-l-0 border-r",
      )}
      style={
        isApparent
          ? apparentSidebarStyle(presetColorHex)
          : undefined
      }
      collapsible={collapsible}
    >
      {/* Collapse Toggle Button with vertical line - positioned at sidebar level */}
      {!isMobile && (
        <div
          suppressHydrationWarning
          className={`absolute top-0 bottom-0 w-px ${
            isApparent ? "bg-white/30" : "bg-border"
          } z-30 pointer-events-none ${isRTL ? "-left-px" : "-right-px"}`}
        />
      )}
      <SidebarHeader className="border-b-0 px-3 py-3 relative group-data-[collapsible=icon]:px-2">
        <Link
          prefetch={false}
          href="/"
          className="flex w-full items-center px-4 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0"
        >
          {renderSidebarBrand()}
        </Link>
      </SidebarHeader>

      <SidebarContent
        // Keyed on the menu shown, so a swap starts at the top of the list and
        // the settings menu slides in over the place the main one held.
        key={settingsSectionId ? "settings" : "main"}
        className={cn(
          "px-3 group-data-[collapsible=icon]:px-1 group-data-[collapsible=icon]:gap-1",
          settingsSectionId &&
            "pb-3 motion-safe:animate-in motion-safe:fade-in-0 motion-safe:slide-in-from-end-2",
        )}
      >
        {settingsSectionId ? (
          <AdminSettingsSidebarNav
            activeSectionId={settingsSectionId}
            isApparent={isApparent}
            isRTL={isRTL}
            isIconCollapsed={isIconCollapsed}
          />
        ) : navGroups.map((group, groupIndex) => (
          <SidebarGroup
            key={group.label}
            className={cn(
              groupIndex === 0 ? "mt-0" : "mt-2",
              "group-data-[collapsible=icon]:px-1 group-data-[collapsible=icon]:py-2",
            )}
          >
            {group.label && (
              <SidebarGroupLabel
                className={cn(
                  "px-4 mb-1 text-[11px] font-semibold tracking-[0.08em] group-data-[collapsible=icon]:hidden flex items-center uppercase",
                  isApparent ? "text-white/60" : "text-muted-foreground/60",
                )}
              >
                {tLabel(group.label)}
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu className="gap-1 group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:gap-3">
                {group.items.map((item) => {
                  const Icon = iconMap[item.icon] || Package;
                  // Check if item matches current path (self)
                  const isSelfActive = isNavHrefActive(
                    basePath,
                    item.href,
                    navHrefs,
                  );

                  // Check if any child (or grandchild) matches current path
                  const isChildActive = Boolean(
                    item.items?.some(
                      (child) =>
                        isNavHrefActive(basePath, child.href, navHrefs) ||
                        (child.items ?? []).some((grandChild) =>
                          isNavHrefActive(basePath, grandChild.href, navHrefs),
                        ),
                    ),
                  );

                  const isActive = isSelfActive || isChildActive;

                  if (item.items && item.items.length > 0) {
                    const children = item.items;
                    const isOpen = isChildActive || openSections.has(item.href);
                    const isSectionActive = isActive;
                    const isSectionExpanded = isOpen || isChildActive;

                    if (isIconCollapsed) {
                      return (
                        <CollapsedHoverSubmenu
                          key={item.href}
                          item={item}
                          submenuItems={children}
                          Icon={Icon}
                          isActive={isActive}
                          isApparent={isApparent}
                          isRTL={isRTL}
                          basePath={basePath}
                          navHrefs={navHrefs}
                          tLabel={tLabel}
                        />
                      );
                    }

                    return (
                      <SidebarMenuItem key={item.href} className="mb-0.5">
                        <SidebarMenuButton
                          type="button"
                          size="sm"
                          isActive={isSectionActive}
                          aria-expanded={isOpen}
                          onClick={(event) => {
                            if (!isOpen) {
                              revealAfterOpen.current = event.currentTarget;
                            }
                            toggleSection(item.href);
                          }}
                          className={cn(
                            "rounded-lg px-3 py-2.5 h-9 text-[13px] transition-colors w-full justify-between group/btn cursor-pointer",
                            isApparent
                              ? isSectionActive
                                ? "bg-white/20 text-white hover:bg-white/25 font-semibold"
                                : isSectionExpanded
                                  ? "bg-white/10 text-white hover:bg-white/15 font-semibold"
                                  : "text-white/80 hover:bg-white/10 hover:text-white font-semibold"
                              : isSectionActive
                                ? "bg-primary/10 text-primary hover:bg-primary/10 data-[active=true]:bg-primary/10 data-[active=true]:text-primary dark:bg-white/15 dark:text-white dark:hover:bg-white/20 dark:data-[active=true]:bg-white/15 dark:data-[active=true]:text-white font-semibold"
                                : isSectionExpanded
                                  ? "bg-muted/70 text-foreground hover:bg-muted/80 font-semibold"
                                  : "text-foreground/70 hover:bg-muted/60 hover:text-foreground font-semibold",
                          )}
                        >
                          <div className="flex items-center gap-3">
                            <Icon className="size-4.5 shrink-0 stroke-2 transition-transform duration-300 group-data-[collapsible=icon]:size-5" />
                            <span className="group-data-[collapsible=icon]:hidden">
                              {tLabel(item.label)}
                            </span>
                          </div>
                          <ChevronRight
                            className={cn(
                              "h-4 w-4 transition-transform duration-200 opacity-60 group-data-[collapsible=icon]:hidden",
                              isOpen && "rotate-90 opacity-100",
                            )}
                          />
                        </SidebarMenuButton>

                        {isOpen && (
                          <SidebarMenuSub className="ml-2 mt-1 pl-2.5 border-l-0 relative">
                            {children.map((child, childIndex) => {
                              const childSelfActive = isNavHrefActive(
                                basePath,
                                child.href,
                                navHrefs,
                              );
                              const grandChildren = child.items ?? [];
                              const isGrandChildActive = grandChildren.some(
                                (grandChild) =>
                                  isNavHrefActive(
                                    basePath,
                                    grandChild.href,
                                    navHrefs,
                                  ),
                              );
                              const isChildItemActive =
                                childSelfActive || isGrandChildActive;
                              const isChildOpen =
                                childSelfActive ||
                                isGrandChildActive ||
                                openSections.has(child.href);
                              const isChildLeafActive =
                                childSelfActive && !isGrandChildActive;
                              const isLast = childIndex === children.length - 1;

                              return (
                                <React.Fragment key={child.href}>
                                  <SidebarMenuSubItem className="relative h-7 flex items-center pl-4">
                                    {/* Vertical line */}
                                    <div
                                      className={cn(
                                        "absolute left-0 w-px",
                                        isApparent
                                          ? "bg-white/30"
                                          : "bg-muted-foreground/20 dark:bg-white/25",
                                        isLast
                                          ? "top-0 h-3.5"
                                          : "top-0 bottom-0",
                                      )}
                                    />
                                    {/* Horizontal branch */}
                                    <div
                                      className={cn(
                                        "absolute left-0 top-3.5 w-4 h-px",
                                        isApparent
                                          ? "bg-white/30"
                                          : "bg-muted-foreground/20 dark:bg-white/25",
                                      )}
                                    />

                                    {grandChildren.length > 0 ? (
                                      <SidebarMenuSubButton
                                        type="button"
                                        size="sm"
                                        isActive={isChildLeafActive}
                                        aria-expanded={isChildOpen}
                                        onClick={(event) => {
                                          if (!isChildOpen) {
                                            revealAfterOpen.current =
                                              event.currentTarget;
                                          }
                                          toggleSection(child.href);
                                        }}
                                        className={cn(
                                          "rounded-md px-2 py-1 text-[13px] font-medium relative z-10 w-full justify-between",
                                          isApparent
                                            ? isChildLeafActive
                                              ? "bg-white/20 text-white font-semibold"
                                              : isChildOpen
                                                ? "bg-white/10 text-white font-semibold hover:bg-white/15"
                                                : "text-white/90 hover:bg-white/15 hover:text-white"
                                            : isChildLeafActive
                                              ? "bg-muted text-foreground font-semibold data-[active=true]:bg-muted data-[active=true]:text-foreground"
                                              : isChildOpen
                                                ? "bg-muted/60 text-foreground font-semibold hover:bg-muted/70"
                                                : "text-foreground/60 hover:text-foreground",
                                        )}
                                      >
                                        <span>{tLabel(child.label)}</span>
                                        <ChevronRight
                                          className={cn(
                                            "h-3.5 w-3.5 opacity-70 transition-transform",
                                            isChildOpen &&
                                              "rotate-90 opacity-100",
                                          )}
                                        />
                                      </SidebarMenuSubButton>
                                    ) : (
                                      <SidebarMenuSubButton
                                        asChild
                                        size="sm"
                                        isActive={isChildItemActive}
                                        className={cn(
                                          "rounded-md px-2 py-1 text-[13px] font-medium relative z-10 w-full",
                                          isApparent
                                            ? "text-white/90 hover:bg-white/15 hover:text-white"
                                            : "text-foreground/60 hover:text-foreground",
                                          isChildItemActive &&
                                            (isApparent
                                              ? "bg-white/20 text-white font-semibold"
                                              : "bg-muted text-foreground font-semibold data-[active=true]:bg-muted data-[active=true]:text-foreground"),
                                        )}
                                      >
                                        <Link prefetch={false} href={child.href}>
                                          <span>{tLabel(child.label)}</span>
                                        </Link>
                                      </SidebarMenuSubButton>
                                    )}
                                  </SidebarMenuSubItem>

                                  {grandChildren.length > 0 && isChildOpen && (
                                    <SidebarMenuSub className="ml-4 -mt-0.5 mb-0.5 pl-0 border-l-0">
                                      {grandChildren.map((grandChild) => {
                                        const isGrandChildItemActive =
                                          isNavHrefActive(
                                            basePath,
                                            grandChild.href,
                                            navHrefs,
                                          );

                                        return (
                                          <SidebarMenuSubItem
                                            key={grandChild.href}
                                            className="relative h-7 flex items-center pl-4"
                                          >
                                            <div
                                              className={cn(
                                                "absolute left-0 top-3.5 w-3 h-px",
                                                isApparent
                                                  ? "bg-white/25"
                                                  : "bg-muted-foreground/15 dark:bg-white/20",
                                              )}
                                            />
                                            <SidebarMenuSubButton
                                              asChild
                                              size="sm"
                                              isActive={isGrandChildItemActive}
                                              className={cn(
                                                "rounded-md px-2 py-1 text-[12px] font-medium relative z-10 w-full",
                                                isApparent
                                                  ? "text-white/80 hover:bg-white/15 hover:text-white"
                                                  : "text-foreground/60 hover:text-foreground",
                                                isGrandChildItemActive &&
                                                  (isApparent
                                                    ? "bg-white/20 text-white font-semibold"
                                                    : "bg-muted text-foreground font-semibold data-[active=true]:bg-muted data-[active=true]:text-foreground"),
                                              )}
                                            >
                                              <Link prefetch={false} href={grandChild.href}>
                                                <span>
                                                  {tLabel(grandChild.label)}
                                                </span>
                                              </Link>
                                            </SidebarMenuSubButton>
                                          </SidebarMenuSubItem>
                                        );
                                      })}
                                    </SidebarMenuSub>
                                  )}
                                </React.Fragment>
                              );
                            })}
                          </SidebarMenuSub>
                        )}
                      </SidebarMenuItem>
                    );
                  }

                  const count = item.countKey ? navCounts[item.countKey] : 0;

                  return (
                    <SidebarMenuItem
                      key={item.href}
                      className="group-data-[collapsible=icon]:w-full"
                    >
                      <SidebarMenuButton
                        asChild
                        size="sm"
                        isActive={isActive}
                        className={cn(
                          "rounded-lg px-3 py-2.5 h-9 text-[13px] transition-colors group-data-[collapsible=icon]:h-auto group-data-[collapsible=icon]:w-full group-data-[collapsible=icon]:rounded-md group-data-[collapsible=icon]:px-2 group-data-[collapsible=icon]:py-3 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:flex-col group-data-[collapsible=icon]:gap-1.5",
                          isApparent
                            ? isActive
                              ? "bg-white/20 text-white hover:bg-white/25 font-semibold"
                              : "text-white/80 hover:bg-white/10 hover:text-white font-semibold"
                            : isActive
                              ? "bg-primary/10 text-primary hover:bg-primary/10 dark:bg-white/15 dark:text-white dark:hover:bg-white/20 font-semibold"
                              : "text-foreground/70 hover:bg-muted/60 hover:text-foreground font-semibold",
                        )}
                      >
                        <Link prefetch={false} href={item.href} className="relative w-full">
                          <div className="flex items-center gap-3 w-full group-data-[collapsible=icon]:justify-center">
                            <span className="relative inline-flex shrink-0">
                              <Icon className="size-4.5 shrink-0 stroke-2 transition-transform duration-300 group-data-[collapsible=icon]:size-5" />
                              <SidebarCountBadge
                                count={count}
                                isApparent={isApparent}
                                rail
                              />
                            </span>
                            <span className="group-data-[collapsible=icon]:hidden">
                              {tLabel(item.label)}
                            </span>
                            <SidebarCountBadge
                              count={count}
                              isApparent={isApparent}
                            />
                          </div>
                          <span
                            className={cn(
                              "hidden text-[11px] leading-tight group-data-[collapsible=icon]:block text-center break-words whitespace-normal overflow-visible",
                              isApparent
                                ? "text-white"
                                : isActive
                                  ? "text-sidebar-accent-foreground"
                                  : "text-muted-foreground",
                            )}
                          >
                            {tLabel(item.label)}
                          </span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <DashboardSidebarFooter
        locale={locale}
        user={user}
        accountLinks={accountLinks}
        appVersion={appVersion}
        isApparent={isApparent}
        isRTL={isRTL}
        isIconCollapsed={isIconCollapsed}
      />
    </Sidebar>
  );
}

