"use client";

import { ModernProductCard, type ModernProduct } from "./modern-product-card";
import { type Locale } from "@/config/i18n.config";
import {
  CARD_GRID_GAP,
} from "@/components/store/product-grid-columns";

/** Cards on the first grid row are above the fold and eager-load their shot. */
const FIRST_ROW_CARDS = 4;

interface CollectionProductsGridProps {
  products: ModernProduct[];
  locale: Locale;
  showQuickView?: boolean;
}

export function CollectionProductsGrid({
  products,
  locale,
  showQuickView = true,
}: CollectionProductsGridProps) {
  return (
    <div className={`grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 ${CARD_GRID_GAP}`}>
      {products.map((product, index) => (
        <ModernProductCard
          key={product._id}
          product={product}
          locale={locale}
          imagePriority={index < FIRST_ROW_CARDS}
          showQuickView={showQuickView}
        />
      ))}
    </div>
  );
}
