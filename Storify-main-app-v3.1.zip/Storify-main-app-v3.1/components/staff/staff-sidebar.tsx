"use client";

import { apparentSidebarIsDark, apparentSidebarStyle } from "@/lib/theme-colors/apparent-sidebar";
import { staffResourcePermissions } from "@/lib/access/staff-resource-actions";

import * as React from "react";
import Link from "@/components/language/link";
import { usePathname } from "@/hooks/use-locale-navigation";
import { useTranslations } from "next-intl";
import {
  BarChart3,
  SearchX,
  ClipboardList,
  LayoutDashboard,
  Megaphone,
  MessageSquare,
  type LucideIcon,
  Package,
  ShoppingBag,
  ShoppingCart,
  FolderTree,
  Tag,
  Users,
  UserRound,
  Warehouse,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import { DEFAULT_STORE_NAME } from "@/config/branding.config";
import {
  STAFF_PERMISSIONS,
  type StaffPermission,
} from "@/config/permissions.config";
import {
  presetColors,
  apparentPaintColor,
  useAppSettings as useUiAppSettings,
} from "@/stores/app-settings";
import { useAppSettings as usePublicAppSettings } from "@/providers/app-settings-provider";
import { useAppTheme } from "@/providers/theme-provider";
import { AppImage } from "@/components/ui/app-image";
import { SidebarCountBadge } from "@/components/layout/sidebar-count-badge";
import { SidebarAccountMenu } from "@/components/layout/account-menu";
import { useInboxUnreadCount } from "@/hooks/use-inbox-unread-count";
import type { Locale } from "@/config/i18n.config";

interface NavItem {
  key: string;
  href: string;
  label: string;
  icon: LucideIcon;
}

interface NavGroup {
  label?: string;
  items: NavItem[];
}

interface StaffSidebarProps {
  locale: Locale;
  user: {
    name: string;
    email: string;
    image?: string;
  };
  permissions: StaffPermission[];
  posEnabled: boolean;
  storeName?: string;
  /**
   * Whether the staff member's scope can be read against an abandoned
   * checkout: false for one limited by locations alone, whom the page turns
   * away (`staffScopeReachesAbandonedCheckouts`). Absent reads as true.
   */
  abandonedCheckoutsInScope?: boolean;
  /**
   * Whether the staff member is unscoped. The campaign banners are the whole
   * store's, so one limited to vendors, locations or regions is not offered
   * them (the page turns them away). Absent reads as true.
   */
  campaignBannersInScope?: boolean;
}

function buildStaffNav(
  locale: Locale,
  permissions: StaffPermission[],
  posEnabled: boolean,
  abandonedCheckoutsInScope = true,
  campaignBannersInScope = true,
): NavGroup[] {
  const has = (perm: StaffPermission) => permissions.includes(perm);

  const mainItems: NavItem[] = [
    {
      key: "dashboard",
      href: "/staff/dashboard",
      label: "admin.sidebar.dashboard",
      icon: LayoutDashboard,
    },
  ];

  if (staffResourcePermissions("orders").some(has)) {
    mainItems.push({
      key: "orders",
      href: "/staff/orders",
      label: "admin.sidebar.orders",
      icon: ClipboardList,
    });
  }

  // A grant of its own, not a part of Orders: these are shoppers who did not
  // buy, with their contact details.
  if (has(STAFF_PERMISSIONS.VIEW_ABANDONED_CHECKOUTS) && abandonedCheckoutsInScope) {
    mainItems.push({
      key: "abandoned-checkouts",
      href: "/staff/abandoned-checkouts",
      label: "admin.sidebar.abandonedCheckouts",
      icon: ShoppingBag,
    });
  }

  // The popups and bars on the store's Home page.
  if (has(STAFF_PERMISSIONS.VIEW_CAMPAIGN_BANNERS) && campaignBannersInScope) {
    mainItems.push({
      key: "campaign-banners",
      href: "/staff/campaign-banners",
      label: "admin.sidebar.campaignBanners",
      icon: Megaphone,
    });
  }

  if (
    has(STAFF_PERMISSIONS.VIEW_PRODUCTS) ||
    has(STAFF_PERMISSIONS.MANAGE_PRODUCTS) ||
    has(STAFF_PERMISSIONS.CREATE_PRODUCTS) ||
    has(STAFF_PERMISSIONS.EDIT_PRODUCTS) ||
    has(STAFF_PERMISSIONS.DELETE_PRODUCTS)
  ) {
    mainItems.push({
      key: "products",
      href: "/staff/products",
      label: "admin.sidebar.products",
      icon: Package,
    });
  }

  for (const [resource, icon] of [["categories", FolderTree], ["brands", Tag]] as const) {
    if (staffResourcePermissions(resource).some(has)) {
      mainItems.push({ key: resource, href: `/staff/${resource}`, label: `admin.sidebar.${resource}`, icon });
    }
  }

  if (
    has(STAFF_PERMISSIONS.VIEW_INVENTORY) ||
    has(STAFF_PERMISSIONS.MANAGE_INVENTORY) ||
    has(STAFF_PERMISSIONS.CREATE_INVENTORY) ||
    has(STAFF_PERMISSIONS.EDIT_INVENTORY) ||
    has(STAFF_PERMISSIONS.DELETE_INVENTORY)
  ) {
    mainItems.push({
      key: "inventory",
      href: "/staff/inventory",
      label: "admin.sidebar.inventory",
      icon: Warehouse,
    });
  }

  if (
    has(STAFF_PERMISSIONS.VIEW_CUSTOMERS) ||
    has(STAFF_PERMISSIONS.MANAGE_CUSTOMERS) ||
    has(STAFF_PERMISSIONS.CREATE_CUSTOMERS) ||
    has(STAFF_PERMISSIONS.EDIT_CUSTOMERS) ||
    has(STAFF_PERMISSIONS.DELETE_CUSTOMERS)
  ) {
    mainItems.push({
      key: "customers",
      href: "/staff/customers",
      label: "admin.sidebar.customers",
      icon: Users,
    });
  }

  if (has(STAFF_PERMISSIONS.VIEW_ANALYTICS)) {
    mainItems.push(
      {
        key: "analytics",
        href: "/staff/analytics",
        label: "admin.sidebar.analytics",
        icon: BarChart3,
      },
      {
        key: "search-insights",
        href: "/staff/analytics/search",
        label: "admin.sidebar.searchInsights",
        icon: SearchX,
      },
    );
  }

  if (
    has(STAFF_PERMISSIONS.VIEW_INBOX) ||
    has(STAFF_PERMISSIONS.REPLY_INBOX) ||
    has(STAFF_PERMISSIONS.MANAGE_INBOX)
  ) {
    mainItems.push({
      key: "inbox",
      href: "/staff/inbox",
      label: "admin.sidebar.inbox",
      icon: MessageSquare,
    });
  }

  const groups: NavGroup[] = [{ items: mainItems }];

  if (posEnabled && has(STAFF_PERMISSIONS.ACCESS_POS)) {
    groups.push({
      label: "admin.sidebar.salesChannels",
      items: [
        {
          key: "pos",
          href: "/staff/pos",
          label: "admin.sidebar.pos",
          icon: ShoppingCart,
        },
        // Till reports: sales by cashier and counter, the drawers' counts.
        ...(has(STAFF_PERMISSIONS.MANAGE_POS)
          ? [
              {
                key: "posReports",
                href: "/staff/pos/staff",
                label: "pos.reports.navLabel",
                icon: BarChart3,
              },
            ]
          : []),
      ],
    });
  }

  return groups;
}

// Every sidebar link is `prefetch={false}` on purpose. The tree holds 50–90
// links, and Next 16's viewport prefetch rendered a `/_tree` partial for each
// of them on every dashboard page view — more server work than the page
// itself. A click now pays one round trip instead (with `false`, Next 16 does
// not prefetch on hover either).
export function StaffSidebar({
  locale,
  user,
  permissions,
  posEnabled,
  storeName,
  abandonedCheckoutsInScope = true,
  campaignBannersInScope = true,
}: StaffSidebarProps) {
  const t = useTranslations();
  const pathname = usePathname();
  const { navColor, navPaint, presetColor, primaryColor, secondaryColor, previewBrand, rtl } = useUiAppSettings();
  const {
    storeName: liveStoreName,
    logoUrl,
    darkModeLogoUrl,
    faviconUrl,
  } = usePublicAppSettings();
  const { isDark } = useAppTheme();
  const { state: sidebarState, isMobile } = useSidebar();

  const basePath = React.useMemo(() => {
    const prefix = `/${locale}`;
    if (pathname?.startsWith(prefix)) {
      const stripped = pathname.slice(prefix.length);
      return stripped.length ? stripped : "/";
    }
    return pathname || "/";
  }, [pathname, locale]);

  const tLabel = React.useCallback(
    (key: string) => {
      try {
        return t(key as never);
      } catch {
        return key;
      }
    },
    [t],
  );

  const navGroups = React.useMemo(
    () =>
      buildStaffNav(
        locale,
        permissions,
        posEnabled,
        abandonedCheckoutsInScope,
        campaignBannersInScope,
      ),
    [locale, permissions, posEnabled, abandonedCheckoutsInScope, campaignBannersInScope],
  );

  // Polled only when Inbox is in the nav — without inbox access the endpoint
  // answers 403 on every tick.
  const hasInboxEntry = navGroups.some((group) =>
    group.items.some((item) => item.key === "inbox"),
  );
  const inboxUnread = useInboxUnreadCount(
    hasInboxEntry && basePath !== "/staff/pos",
  );

  const isRTL = locale === "ar" || rtl;
  const sidebarSide = isRTL ? "right" : "left";
  const collapsible = "icon";
  const isIconCollapsed =
    !isMobile && collapsible === "icon" && sidebarState === "collapsed";

  const isApparent = navColor === "apparent";
  // The live theme's primary, or its secondary when the viewer chose it — or
  // the theme editor's unsaved colours while it is open.
  const paintColor = apparentPaintColor({ navPaint, primaryColor, secondaryColor, previewBrand });
  const presetColorHex =
    typeof paintColor === "string" && paintColor.trim()
      ? paintColor
      : presetColors[presetColor]?.hex;
  const useDarkSidebarBrand =
    isDark || (isApparent && apparentSidebarIsDark(presetColorHex));

  const brandStoreName =
    typeof liveStoreName === "string" && liveStoreName.trim()
      ? liveStoreName.trim()
      : typeof storeName === "string" && storeName.trim()
        ? storeName.trim()
        : DEFAULT_STORE_NAME;

  const currentLogoUrl =
    useDarkSidebarBrand &&
    typeof darkModeLogoUrl === "string" &&
    darkModeLogoUrl.trim()
      ? darkModeLogoUrl
      : typeof logoUrl === "string" && logoUrl.trim()
        ? logoUrl
        : "";
  // No bundled icon backs this up — an unconfigured favicon shows the store's
  // initial, never this app's own mark.
  const currentFaviconUrl =
    typeof faviconUrl === "string" && faviconUrl.trim() ? faviconUrl : "";

  const renderBrand = () => {
    if (isIconCollapsed) {
      return (
        <span className="relative block h-8 w-8 shrink-0 overflow-hidden rounded-md">
          {currentFaviconUrl ? (
            <AppImage
              src={currentFaviconUrl}
              alt="Favicon"
              className="h-8 w-8 object-contain"
              width={32}
              height={32}
            />
          ) : (
            <span
              className={cn(
                "flex h-8 w-8 items-center justify-center rounded-md text-sm font-bold",
                isApparent
                  ? "bg-white/15 text-white"
                  : "bg-primary/10 text-primary",
              )}
            >
              {brandStoreName.trim().charAt(0).toUpperCase()}
            </span>
          )}
        </span>
      );
    }

    if (currentLogoUrl) {
      return (
        <span className="relative block h-8 w-full overflow-hidden">
          <AppImage
            src={currentLogoUrl}
            alt="Logo"
            className="h-8 w-full object-contain object-left"
            width={224}
            height={32}
          />
        </span>
      );
    }

    return (
      <span
        className={cn(
          "block truncate text-lg font-bold",
          isApparent
            ? "text-white"
            : "bg-linear-to-r from-primary to-primary/70 bg-clip-text text-transparent",
        )}
      >
        {brandStoreName}
      </span>
    );
  };

  const sidebarStyle = isApparent
    ? apparentSidebarStyle(presetColorHex)
    : undefined;

  // The longest nav href the path sits under is the one open. Plain prefix
  // matching lit "Analytics" and "Search insights" together on the latter,
  // whose URL nests under the former's.
  const navHrefs = navGroups.flatMap((group) =>
    group.items.map((item) => item.href),
  );
  const isItemActive = (href: string) => {
    if (basePath === href) return true;
    if (!basePath.startsWith(`${href}/`)) return false;
    return !navHrefs.some(
      (other) =>
        other.length > href.length &&
        (basePath === other || basePath.startsWith(`${other}/`)),
    );
  };

  if (basePath === "/staff/pos") {
    return null;
  }

  return (
    <Sidebar
      key={`staff-sidebar-${locale}-${sidebarSide}`}
      side={sidebarSide}
      className={cn(
        "border-r-0 transition-colors duration-300",
        isRTL && "border-l-0 border-r",
      )}
      style={sidebarStyle}
      collapsible={collapsible}
    >
      {!isMobile && (
        <div
          suppressHydrationWarning
          className={cn(
            "absolute top-0 bottom-0 w-px z-30 pointer-events-none",
            isApparent ? "bg-white/30" : "bg-border",
            isRTL ? "-left-px" : "-right-px",
          )}
        />
      )}

      <SidebarHeader className="border-b-0 px-3 py-3 relative group-data-[collapsible=icon]:px-2">
        <Link
          prefetch={false}
          href="/staff/dashboard"
          className="flex w-full items-center px-4 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0"
        >
          {renderBrand()}
        </Link>
      </SidebarHeader>

      <SidebarContent className="px-3 group-data-[collapsible=icon]:px-1 group-data-[collapsible=icon]:gap-1">
        {navGroups.map((group, groupIndex) => (
          <SidebarGroup
            key={group.label ?? `group-${groupIndex}`}
            className={cn(
              groupIndex === 0 ? "mt-0" : "mt-2",
              "group-data-[collapsible=icon]:px-1 group-data-[collapsible=icon]:py-2",
            )}
          >
            {group.label && (
              <SidebarGroupLabel
                className={cn(
                  "px-4 mb-1 text-[11px] font-semibold tracking-[0.08em] uppercase group-data-[collapsible=icon]:hidden flex items-center",
                  isApparent ? "text-white/60" : "text-muted-foreground/60",
                )}
              >
                {tLabel(group.label)}
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu className="gap-1 group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:gap-3">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const active = isItemActive(item.href);
                  const count = item.key === "inbox" ? inboxUnread : 0;
                  return (
                    <SidebarMenuItem
                      key={item.key}
                      className="group-data-[collapsible=icon]:w-full"
                    >
                      <SidebarMenuButton
                        asChild
                        size="sm"
                        isActive={active}
                        className={cn(
                          "rounded-lg px-3 py-2.5 h-9 text-[13px] transition-colors group-data-[collapsible=icon]:h-auto group-data-[collapsible=icon]:w-full group-data-[collapsible=icon]:rounded-md group-data-[collapsible=icon]:px-2 group-data-[collapsible=icon]:py-3 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:flex-col group-data-[collapsible=icon]:gap-1.5",
                          isApparent
                            ? active
                              ? "bg-white/20 text-white hover:bg-white/25 font-semibold"
                              : "text-white/80 hover:bg-white/10 hover:text-white font-semibold"
                            : active
                              ? "bg-emerald-50 text-emerald-600 hover:bg-emerald-50 dark:bg-white/15 dark:text-white dark:hover:bg-white/20 font-semibold"
                              : "text-foreground/70 hover:bg-muted/60 hover:text-foreground font-semibold",
                        )}
                      >
                        <Link prefetch={false} href={item.href} className="relative w-full">
                          <div className="flex w-full items-center gap-3 group-data-[collapsible=icon]:justify-center">
                            <span className="relative inline-flex shrink-0">
                              <Icon className="size-4.5 shrink-0 stroke-2 transition-transform duration-300 group-data-[collapsible=icon]:size-5" />
                              <SidebarCountBadge
                                count={count}
                                isApparent={isApparent}
                                rail
                              />
                            </span>
                            <span className="group-data-[collapsible=icon]:hidden">
                              {tLabel(item.label)}
                            </span>
                            <SidebarCountBadge
                              count={count}
                              isApparent={isApparent}
                            />
                          </div>
                          <span
                            className={cn(
                              "hidden text-[11px] leading-tight group-data-[collapsible=icon]:block text-center wrap-break-word whitespace-normal overflow-visible",
                              isApparent
                                ? "text-white"
                                : active
                                  ? "text-sidebar-accent-foreground"
                                  : "text-muted-foreground",
                            )}
                          >
                            {tLabel(item.label)}
                          </span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter className="mt-auto px-3 py-3 group-data-[collapsible=icon]:p-2">
        <SidebarAccountMenu
          locale={locale}
          user={user}
          links={[
            { href: "/staff/profile", label: tLabel("common.profile"), Icon: UserRound },
          ]}
          isApparent={isApparent}
          isRTL={isRTL}
          isIconCollapsed={isIconCollapsed}
        />
      </SidebarFooter>
    </Sidebar>
  );
}
