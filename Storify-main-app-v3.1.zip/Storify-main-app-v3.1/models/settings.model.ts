/**
 * Settings Model - Redesigned
 * Industry-standard architecture with proper sub-document organization
 */

import { cache } from "react";
import { requestMemo } from "@/lib/api/request-scope";
import {
  ALL_VENDOR_PACKS,
  type VendorPermissionPack,
} from "@/config/permissions.config";
import mongoose, { Schema, Document, Model, type Types } from "mongoose";
import { COD_COLLECTED_BY, type CodCollectedBy } from "@/config/app.config";
import {
  DEFAULT_OUT_OF_STOCK_DISPLAY,
  OUT_OF_STOCK_DISPLAY_VALUES,
  type OutOfStockDisplay,
} from "@/lib/catalog/catalog-display";
import {
  getDefaultContentPagesSettings,
  type ContentPagesSettings,
} from "@/lib/site-config/content-pages-config";
import {
  getDefaultHomePageSettings,
  type HomePageSettings,
} from "@/lib/site-config/home-page-config";
import {
  getDefaultHeaderSettings,
  type HeaderSettings,
} from "@/lib/site-config/header-config";
import {
  getDefaultFooterSettings,
  type FooterSettings,
} from "@/lib/site-config/footer-config";
import {
  getDefaultCheckoutSettings,
  type CheckoutSettings,
} from "@/lib/checkout/checkout-config";
import {
  DEFAULT_ACCENT_COLOR,
  DEFAULT_CURRENCY,
  DEFAULT_LANGUAGE,
  DEFAULT_PRESET_COLOR,
  DEFAULT_PRIMARY_COLOR,
  DEFAULT_SECONDARY_COLOR,
  DEFAULT_STORE_NAME,
  DEFAULT_THEME_MODE,
  isLegacySeededBrandText,
  normalizeThemeMode,
  resolveFaviconUrl,
  type ThemeMode,
} from "@/config/branding.config";
import {
  DEFAULT_NOTIFICATION_SETTINGS,
  type NotificationChannelSettings,
  type NotificationSettings,
} from "@/lib/notifications/notification-settings";
import {
  DEFAULT_MIN_WITHDRAWAL_AMOUNT,
  DEFAULT_ORDER_PREFIX,
  DEFAULT_ORDER_SHIPPING_COST,
  DEFAULT_ORDER_TAX_RATE,
  DEFAULT_VENDOR_COMMISSION_RATE,
  ORDER_PREFIX_PATTERN,
} from "@/lib/orders/order-settings";
import {
  DEFAULT_LOYALTY_SPEND_PER_POINT,
  MIN_LOYALTY_SPEND_PER_POINT,
} from "@/lib/customers/loyalty";
import {
  withEffectiveStoreRate,
  type StoredTaxSettings,
} from "@/lib/tax/tax-settings";
import {
  DEFAULT_BILL_VENDOR_COD_SHIPPING,
  DEFAULT_REFUND_ADMIN_FEE_CAP,
  DEFAULT_REFUND_ADMIN_FEE_PERCENT,
  DEFAULT_RESTOCKING_FEE_PERCENT,
  DEFAULT_RETURN_SHIPPING_FEE,
  DEFAULT_PAYOUT_HOLD_MAX_DAYS,
  DEFAULT_RETURN_SHIPPING_REFUND,
  DEFAULT_RETURN_WINDOW_DAYS,
  DEFAULT_RETURN_WINDOW_START,
  MAX_RETURN_WINDOW_DAYS,
  MIN_RETURN_WINDOW_DAYS,
  NEW_STORE_RETURN_SHIPPING_REFUND,
  RETURN_SHIPPING_REFUND_MODES,
  RETURN_WINDOW_STARTS,
  type ReturnShippingRefundMode,
  type ReturnWindowStart,
} from "@/lib/returns/return-policy";
import { RETURN_INSTRUCTIONS_MAX_LENGTH } from "@/lib/returns/return-shipping";
import {
  DEFAULT_LOCKOUT_MINUTES,
  DEFAULT_MAX_LOGIN_ATTEMPTS,
  DEFAULT_SESSION_MAX_AGE_DAYS,
} from "@/lib/security-limits";
import { SUPPORTED_UPLOAD_MIME_TYPES } from "@/lib/storage/types";
import type { AddressHoldSettings } from "@/lib/orders/address-hold-policy";
import {
  POS_SELECTABLE_PAYMENT_METHODS,
  type POSSelectablePaymentMethod,
} from "@/lib/pos/payment";
import {
  COUNTRY_AVAILABILITY_MODES,
  DEFAULT_COUNTRY_AVAILABILITY,
  type CountryAvailability,
} from "@/lib/intl/country-availability";
import {
  CARRIER_LABEL_FILE_TYPES,
  CARRIER_LABEL_STORAGE_MODES,
  CARRIER_MODES,
  CARRIER_PROVIDERS,
  CARRIER_RATE_CHOICES,
  DEFAULT_PACKAGE_PRESET,
  DIMENSION_UNITS,
  PARCEL_WEIGHT_UNITS,
  type CarrierLabelFileType,
  type CarrierLabelStorage,
  type CarrierMode,
  type CarrierProvider,
  type CarrierRateChoice,
  type DimensionUnit,
  type ParcelWeightUnit,
} from "@/lib/shipping/carrier-config";

// ============================================
// General Settings Sub-interface
// ============================================

interface IGeneralSettings {
  storeName: string;
  storeDescription?: string;
  storeEmail: string;
  storePhone?: string;
  storeDomain?: string;
  storeAddress?: string;
  logoUrl?: string;
  darkModeLogoUrl?: string;
  faviconUrl?: string;
  /** Source image for the installed-app (PWA) icon; see `lib/pwa-icons.ts`. */
  appIconUrl?: string;
  defaultLanguage: string;
  defaultCurrency: string;
  supportedLanguages: string[];
  countryAvailability: CountryAvailability;
}

// ============================================
// Appearance Settings Sub-interface
// ============================================

/** Admin-defined color preset saved from the Branding tab's color picker. */
interface ICustomColorPreset {
  id: string;
  name: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
}

interface IAppearanceSettings {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  /** Loading placeholders. Empty keeps a neutral grey. */
  skeletonColor?: string;
  /**
   * Configured theme. `"system"` is a legacy value only readable from
   * pre-existing documents — read it through `normalizeThemeMode()`, never
   * directly, since the app no longer follows the OS preference.
   */
  theme: ThemeMode | "system";
  presetColor: "default" | "cyan" | "purple" | "blue" | "orange" | "red";
  /** User-saved color presets shown alongside the built-in ones. */
  customPresets?: ICustomColorPreset[];
}

// ============================================
// Payment Settings Sub-interfaces
// ============================================

export interface IStripeSettings {
  enabled: boolean;
  publishableKey?: string;
  secretKey?: string;
  webhookSecret?: string;
}

export interface IPayPalSettings {
  enabled: boolean;
  clientId?: string;
  clientSecret?: string;
  mode: "sandbox" | "live";
  webhookId?: string;
}

export interface IRazorpaySettings {
  enabled: boolean;
  keyId?: string;
  keySecret?: string;
  webhookSecret?: string;
}

export interface IPaystackSettings {
  enabled: boolean;
  publicKey?: string;
  secretKey?: string;
}

export interface IPesapalSettings {
  enabled: boolean;
  consumerKey?: string;
  consumerSecret?: string;
  mode: "sandbox" | "live";
  ipnId?: string;
}

export interface IIotecSettings {
  enabled: boolean;
  clientId?: string;
  clientSecret?: string;
  walletId?: string;
  mode: "sandbox" | "live";
}

export interface IOrangeMoneySettings {
  enabled: boolean;
  clientId?: string;
  clientSecret?: string;
  merchantKey?: string;
  /**
   * The operator country whose merchant contract issued the key, as the
   * two-letter code Orange puts in the API path (ci, sn, cm, ml, mg, …).
   * Ignored in sandbox, which always routes through Orange's `dev` segment.
   */
  country?: string;
  mode: "sandbox" | "live";
}

export interface IMtnMomoSettings {
  enabled: boolean;
  /** Ocp-Apim-Subscription-Key from the Collections product subscription. */
  subscriptionKey?: string;
  /** API user UUID — self-provisioned in sandbox, dashboard-issued when live. */
  apiUser?: string;
  apiKey?: string;
  /**
   * X-Target-Environment for live traffic, issued per OpCo at onboarding
   * (mtnuganda, mtnghana, …). Free text, not an enum: coverage is
   * per-contract and grows. Ignored in sandbox, which always sends `sandbox`.
   */
  targetEnvironment?: string;
  /**
   * The host registered with MTN as `providerCallbackHost`. MTN rejects a
   * `requesttopay` whose `X-Callback-Url` names a different host, so this is
   * the only host a callback may be requested for. Blank = no callback; the
   * payment is still confirmed by polling and the reconcile sweep.
   */
  callbackHost?: string;
  mode: "sandbox" | "live";
}

interface ICODSettings {
  enabled: boolean;
  instructions?: string;
  minOrderAmount?: number;
  maxOrderAmount?: number;
}

interface ITurnstileSettings {
  enabled?: boolean;
  siteKey?: string;
  secretKey?: string;
}

interface IPaymentSettings {
  stripe: IStripeSettings;
  paypal: IPayPalSettings;
  razorpay: IRazorpaySettings;
  paystack: IPaystackSettings;
  pesapal: IPesapalSettings;
  iotec: IIotecSettings;
  orange_money: IOrangeMoneySettings;
  mtn_momo: IMtnMomoSettings;
  cod: ICODSettings;
  /** The human check a checkout asks for after repeated refusals. */
  turnstile?: ITurnstileSettings;
  /** Gateways switched over to checkout attempts — an operator's switch. */
  attemptGateways?: string[];
}

// ============================================
// Email Settings Sub-interface
// ============================================

interface ISMTPSettings {
  host?: string;
  port: number;
  user?: string;
  password?: string;
  secure: boolean;
}

interface IEmailSettings {
  enabled: boolean;
  smtp: ISMTPSettings;
  fromEmail?: string;
  fromName?: string;
  replyTo?: string;
  logRetentionDays?: 7 | 30 | 90;
}

// ============================================
// SMS Settings Sub-interface
// ============================================

export interface ISmsSettings {
  /** Master switch. `.env` credentials alone never send a text. */
  enabled: boolean;
  twilio: {
    accountSid?: string;
    authToken?: string;
    /** Preferred sender — Twilio then picks a number from the service. */
    messagingServiceSid?: string;
    /** A Twilio number (E.164) or an alphanumeric sender ID. */
    fromNumber?: string;
  };
  /**
   * ISO-2 country for numbers typed without a country code on a profile.
   * An order's number is read against its shipping country first.
   */
  defaultCountry?: string;
  /** Append the relevant page link — useful, but often a second segment. */
  includeLinks: boolean;
  logRetentionDays?: 7 | 30 | 90;
}

// ============================================
// Order Settings Sub-interface
// ============================================

interface ICommissionSettings {
  vendorRate: number; // Percentage
  /** In the store's own currency. */
  minWithdrawalAmount: number;
  /** A minimum of its own for a payout in another currency — see `resolveMinWithdrawal`. */
  minWithdrawalByCurrency?: Map<string, number>;
  /**
   * Draw payouts up on each seller's own schedule (weekly, every two weeks,
   * monthly) — see lib/finance/scheduled-payouts.ts. The store still sends the
   * money and marks each one paid.
   */
  autoPayoutDrafts?: boolean;
}

/**
 * Return and refund policy. Every default reproduces the behaviour Storify had
 * before these were settings, so an untouched store sees no change — see
 * `resolveReturnPolicy` in lib/return-policy.ts.
 */
interface IReturnPolicySettings {
  windowDays: number;
  /** No time limit on returns; `windowDays` is kept for when it is switched off. */
  windowUnlimited?: boolean;
  /** When the window starts counting — see `RETURN_WINDOW_STARTS`. */
  windowStart?: ReturnWindowStart;
  /** Shoppers ask for returns from their account; off, only the store opens them. */
  selfServe?: boolean;
  /** The most a seller's payout waits on a window with no time limit (D6). */
  payoutHoldMaxDays?: number;
  /** Collections with a return window of their own — see lib/returns/return-window.ts. */
  windowOverrides?: Array<{ collectionId: Types.ObjectId; windowDays: number }>;
  shippingRefund: ReturnShippingRefundMode;
  restockingFeePercent: number;
  returnShippingFee: number;
  refundAdminFeePercent: number;
  refundAdminFeeCap: number;
  billVendorCodShipping: boolean;
  /** What a shopper is told to do with an approved return — see lib/returns/return-shipping.ts. */
  instructions?: string;
  /** Collections sold as final sale — see lib/returns/final-sale.ts. */
  finalSaleCollectionIds?: Types.ObjectId[];
}

interface IOrderSettings {
  prefix: string;
  /**
   * The store's tax rate, a fraction: the standard class's rate in effect now
   * (Settings → Tax). The tax save writes it and every read works it out
   * again, so a scheduled rate starts on its date — see
   * `withEffectiveStoreRate` in lib/tax/tax-settings.ts. Not edited directly.
   */
  taxRate: number;
  freeShippingThreshold?: number;
  defaultShippingCost: number;
  /** Store-currency spend per loyalty point — see lib/customers/loyalty.ts. */
  loyaltySpendPerPoint?: number;
  commission: ICommissionSettings;
  returns: IReturnPolicySettings;
}

type ShippingRateType =
  | "flat"
  | "free_over"
  | "subtotal_range"
  | "weight_range";

type ShippingWeightUnit = "kg" | "lb";

type ShippingDutyMode = "DDP" | "DDU";

interface IShippingOrigin {
  country: string;
  state?: string;
  city?: string;
  postalCode?: string;
  address1?: string;
  address2?: string;
}

interface IShippingDeliveryDefaults {
  processingDaysMin: number;
  processingDaysMax: number;
  showEstimatedDelivery: boolean;
}

interface IShippingRate {
  id: string;
  name: string;
  type: ShippingRateType;
  price: number;
  freeOver?: number;
  minSubtotal?: number;
  maxSubtotal?: number;
  minWeight?: number;
  maxWeight?: number;
  pricePerWeightUnit?: number;
  minDays?: number;
  maxDays?: number;
  active: boolean;
}

interface IShippingZone {
  id: string;
  name: string;
  countries: string[];
  regions?: string[];
  rates: IShippingRate[];
  /**
   * "Rest of the world": priced only when no ordinary zone matched the address,
   * ignoring its own countries/regions. Supersedes the single `fallbackRate`.
   */
  isFallback?: boolean;
}

interface IFallbackShippingRate {
  enabled: boolean;
  name: string;
  price: number;
  minDays?: number;
  maxDays?: number;
}

interface ICustomsSettings {
  enabled: boolean;
  dutyMode: ShippingDutyMode;
  dutyRatePercent?: number;
  deMinimis?: number;
}

interface IVendorShippingSettings {
  enabled: boolean;
}

// ============================================
// Carrier integration (Shippo / Shiprocket)
// ============================================

/** A saved box. Carriers price by volume, so a parcel needs real dimensions. */
export interface ICarrierPackagePreset {
  id: string;
  name: string;
  length: number;
  width: number;
  height: number;
  dimensionUnit: DimensionUnit;
  /** Tare — the empty box's own weight, added to the contents. */
  emptyWeight?: number;
  weightUnit?: ParcelWeightUnit;
  /** Capacity in `weightUnit`; a heavier consignment will not choose this box. */
  maxWeight?: number;
  isDefault?: boolean;
  active: boolean;
}

export interface IShippoCarrierSettings {
  enabled: boolean;
  /** Shippo infers test/live from the token, so both are stored and selected. */
  mode: CarrierMode;
  testToken?: string;
  liveToken?: string;
  /** Minted by the register-webhook action; also stored hashed for comparison. */
  webhookSecret?: string;
  webhookSecretHash?: string;
  webhookRegisteredAt?: Date;
  labelFileType?: CarrierLabelFileType;
  /** Narrows a noisy rate list to services the merchant actually sells. */
  serviceTokenAllowList?: string[];
  authFailure?: ICarrierAuthFailure;
}

/**
 * The carrier last refused our credentials.
 *
 * A dead token is permanent by nature, so every queued job dead-letters on its
 * first attempt — correctly, and completely silently. Without somewhere to
 * record it the store keeps taking orders that quietly never ship, and the
 * carrier still reads as connected on the settings screen. Cleared by the next
 * call that succeeds, so it heals on its own once the credential is replaced.
 */
interface ICarrierAuthFailure {
  at: Date;
  /** The provider's own words, which usually name the actual problem. */
  message?: string;
}

export interface IShiprocketCarrierSettings {
  enabled: boolean;
  email?: string;
  password?: string;
  /**
   * Shiprocket ships from a *registered nickname*, not a free-form address,
   * so this is the one field without which nothing can be dispatched.
   */
  pickupLocationName?: string;
  channelId?: string;
  webhookToken?: string;
  courierIdAllowList?: number[];
  /**
   * The 240-hour login token. Persisted as well as held in process because a
   * serverless cold start would otherwise re-login on every invocation and
   * trip Shiprocket's auth throttle.
   */
  tokenCache?: { token?: string; expiresAt?: Date };
  authFailure?: ICarrierAuthFailure;
}

export interface ICarrierAutomationSettings {
  enabled: boolean;
  /** COD orders are never `paid`, so they only auto-ship when this is on. */
  includeCod: boolean;
  minOrderValue?: number;
  maxOrderValue?: number;
  rateChoice: CarrierRateChoice;
  fixedProvider?: CarrierProvider;
  fixedServiceToken?: string;
  /** Off means "create the draft and stop", leaving the buy to a human. */
  buyLabel: boolean;
  markOrderShipped: boolean;
  restrictToCountries?: string[];
  /** Abort guard, in the carrier account's own currency. */
  maxLabelCost?: number;
}

type IAddressHoldSettings = AddressHoldSettings;

interface ICarrierSettings {
  /** Master switch: off hides every carrier surface and blocks every call. */
  enabled: boolean;
  shippo: IShippoCarrierSettings;
  shiprocket: IShiprocketCarrierSettings;
  labelStorage: CarrierLabelStorage;
}

interface IShippingSettings {
  enabled: boolean;
  weightUnit?: ShippingWeightUnit;
  origin?: IShippingOrigin;
  delivery?: IShippingDeliveryDefaults;
  zones: IShippingZone[];
  fallbackRate?: IFallbackShippingRate;
  customs?: ICustomsSettings;
  vendorShipping?: IVendorShippingSettings;
  /**
   * Who takes the cash on a cash-on-delivery sale, store-wide. Individual
   * vendors may override it; see `lib/cod-collection.ts` for why the resolved
   * answer is frozen onto each consignment rather than read back from here.
   */
  codCollectedBy?: CodCollectedBy;
  carriers?: ICarrierSettings;
  packages?: ICarrierPackagePreset[];
  automation?: ICarrierAutomationSettings;
  addressHold?: Partial<IAddressHoldSettings>;
  /**
   * Tracking pages for couriers we do not book through an API.
   *
   * A hand-entered AWB has no tracking URL — the provider that would have
   * supplied one was never involved — so it reached the customer as text they
   * could do nothing with. `lib/shipping/tracking-urls.ts` ships a short
   * built-in list; this is how a merchant covers the courier they actually
   * use, and overrides ours when their lane is served by a local agent.
   */
  courierTrackingLinks?: ICourierTrackingLink[];
}

/** One courier's tracking page, as a merchant configures it. */
interface ICourierTrackingLink {
  carrier: string;
  urlTemplate: string;
}

// ============================================
// SEO Settings Sub-interface
// ============================================

interface ISEOSettings {
  metaTitle?: string;
  metaDescription?: string;
  metaKeywords?: string;
  ogImage?: string;
}

// ============================================
// Social Settings Sub-interface
// ============================================

interface ICustomShareButton {
  id: string;
  label: string;
  urlTemplate: string;
  enabled: boolean;
  /** Optional uploaded icon URL shown on the storefront share button. */
  icon?: string;
}

interface ISocialShareSettings {
  enabled: boolean;
  copyLink: boolean;
  facebook: boolean;
  twitter: boolean;
  whatsapp: boolean;
  telegram: boolean;
  pinterest: boolean;
  linkedin: boolean;
  email: boolean;
  custom: ICustomShareButton[];
}

interface ISocialSettings {
  facebookUrl?: string;
  twitterUrl?: string;
  instagramUrl?: string;
  youtubeUrl?: string;
  linkedinUrl?: string;
  tiktokUrl?: string;
  share?: ISocialShareSettings;
}

// ============================================
// Analytics Settings Sub-interface
// ============================================

export interface IAnalyticsSettings {
  googleAnalyticsId?: string;
  googleTagManagerId?: string;
  facebookPixelId?: string;
  tiktokPixelId?: string;
  plausibleDomain?: string;
  plausibleApiKey?: string;
  plausibleSelfHosted?: boolean;
  plausibleBaseUrl?: string;
}

// ============================================
// Maintenance Settings Sub-interface
// ============================================

interface IMaintenanceSettings {
  enabled: boolean;
  title?: string;
  message?: string;
  backgroundImageUrl?: string;
  countdownEnabled?: boolean;
  countdownEndsAt?: string;
  allowedIPs?: string[];
}

// ============================================
// Mobile App Settings Sub-interface
// ============================================

/**
 * The store's apps (lib/settings/mobile-app.ts). `shop` is the shopper app and
 * the API under /api/mobile/shop; `biz` is the business app (the store's
 * operators) and the API under /api/mobile/biz.
 */
interface IMobileAppSettings {
  shop: {
    enabled: boolean;
    scheme?: string;
    ios: {
      bundleId?: string;
      teamId?: string;
      appStoreUrl?: string;
      minVersion?: string;
      latestVersion?: string;
    };
    android: {
      packageName?: string;
      sha256CertFingerprints: string[];
      playStoreUrl?: string;
      minVersion?: string;
      latestVersion?: string;
    };
    allowDigitalPurchases: boolean;
    /** Credential: sent to Expo's push service when the account requires it. */
    expoAccessToken?: string;
  };
  biz: {
    enabled: boolean;
    scheme?: string;
    ios: {
      bundleId?: string;
      appStoreUrl?: string;
      minVersion?: string;
      latestVersion?: string;
    };
    android: {
      packageName?: string;
      playStoreUrl?: string;
      minVersion?: string;
      latestVersion?: string;
    };
  };
}

// ============================================
// Security Settings Sub-interface
// ============================================

export const RATE_LIMIT_PRESETS = [
  "default",
  "lenient",
  "moderate",
  "strict",
] as const;

type RateLimitPresetSetting = (typeof RATE_LIMIT_PRESETS)[number];

interface IRateLimitingSettings {
  enabled: boolean;
  ipPreset: RateLimitPresetSetting;
  adminPreset: RateLimitPresetSetting;
  vendorPreset: RateLimitPresetSetting;
  checkoutPreset: RateLimitPresetSetting;
  cartPreset: RateLimitPresetSetting;
  couponPreset: RateLimitPresetSetting;
  authPreset: RateLimitPresetSetting;
}

export interface ISecuritySettings {
  // Email Verification
  emailVerificationRequired: boolean;
  emailVerificationForVendors: boolean;
  emailVerificationRequiredSince?: Date;
  emailVerificationForVendorsSince?: Date;
  smtpVerifiedAt?: Date;
  smtpVerificationFingerprint?: string;

  // Two-Factor Authentication
  twoFactorEnabled: boolean;
  twoFactorRequiredForAdmin: boolean;
  twoFactorRequiredForVendors: boolean;
  twoFactorRequiredForStaff: boolean;

  // OAuth Providers
  googleOAuthEnabled: boolean;
  googleClientId?: string;
  googleClientSecret?: string;
  facebookOAuthEnabled: boolean;
  facebookAppId?: string;
  facebookAppSecret?: string;

  // Session Security
  sessionMaxAgeDays: number;
  maxLoginAttempts: number;
  lockoutDurationMinutes: number;

  // Rate Limiting
  rateLimiting?: IRateLimitingSettings;

  // Password Policy
  minPasswordLength: number;
  requireUppercase: boolean;
  requireNumbers: boolean;
  requireSpecialChars: boolean;
}

// ============================================
// POS Settings Sub-interface
// ============================================

interface IPOSCustomizeSettings {
  printedReceiptsEnabled: boolean;
  receiptPrinter?: string;
  /**
   * Kick the cash drawer open (ESC/POS, through QZ Tray) when cash changes
   * hands at the till. Each device names the printer its drawer hangs off;
   * see lib/pos/cash-drawer.ts. Off by default.
   */
  openCashDrawer?: boolean;
  soundEnabled: boolean;
  soundVolume: number;
  soundAddToCart: boolean;
  soundOrderComplete: boolean;
  soundPayment: boolean;
  soundError: boolean;
}

/**
 * Re-exported from `lib/pos/payment.ts`, which is the canonical list. The
 * duplicate that used to live here had drifted: it named three methods while
 * the schema enum and the POS tab both offered four.
 */
type POSPaymentMethod = POSSelectablePaymentMethod;

interface IPOSCheckoutSettings {
  paymentMethods: POSPaymentMethod[];
  /**
   * Let the till take part of a sale now and the rest later (a deposit), for a
   * sale with a customer attached. Off by default: a deposit is a promise the
   * shop has to keep track of.
   */
  allowDeposits?: boolean;
  /**
   * A till may only sell with its drawer open (a register session). Off by
   * default, so a store that does not count drawers sells as before.
   */
  requireOpenRegister?: boolean;
  /**
   * Shelf prices at the till already include tax: the total is what the
   * shelf says and the tax is the part of it that is tax. Off by default (tax
   * is added on top, as online). See lib/pos/order-totals.ts.
   */
  pricesIncludeTax?: boolean;
}

interface IPOSOrdersSettings {
  orderNumberPrefix: string;
}

/** How a register behaves with no connection (`lib/pos/offline-session.ts`). */
interface IPOSOfflineSettings {
  /** Hours a register may keep selling after its last sign-in check, 1–72. */
  sessionHours: number;
}

interface IPOSSettings {
  enabled: boolean;
  allowAdminSales: boolean;
  allowVendorSales: boolean;
  allowSellerSales: boolean;
  defaultPosLocationId?: string;
  customize: IPOSCustomizeSettings;
  checkout: IPOSCheckoutSettings;
  orders: IPOSOrdersSettings;
  offline?: IPOSOfflineSettings;
}

interface IMultiVendorModeSettings {
  enabled: boolean;
  canManageProducts: boolean;
  canViewOrders: boolean;
  canManageOrders: boolean;
  canManageStoreSettings: boolean;
  canViewAnalytics: boolean;
  canManageDiscounts: boolean;
  canManagePayouts: boolean;
  canAccessPOS: boolean;
  /**
   * One switch per capability pack — the layer that replaced the eight can*
   * booleans above. Absent on a store written before the split;
   * readVendorPolicyFlags() derives it from those booleans until the migration
   * writes it down, so nothing changes on deploy.
   */
  packPolicy?: Partial<Record<VendorPermissionPack, boolean>>;
}
/**
 * Platform-wide limits on what a vendor may promise with a pre-order.
 *
 * A pre-order is the platform taking money for something a VENDOR has not made
 * yet, so the risk lands here rather than on the seller: an over-promised
 * release date or an outsized deposit becomes the platform's refund and the
 * platform's chargeback. Until these settings existed, any vendor could open a
 * pre-order on any product for any lead time, with no cap and no review.
 *
 * The defaults deliberately change nothing on upgrade. `requireVendorApproval`
 * is OFF, so a store already selling pre-orders keeps selling them the day it
 * updates; `maxDepositPercent` is 100, which is the existing (implicit) clamp.
 * The one default that bites is `maxLeadDays`, set high enough to pass any
 * honest drop and low enough to stop a two-year promise. Tightening these is
 * the store owner's decision to make deliberately, not one to be made for them
 * by a version bump that quietly delists their catalogue.
 */
export interface IPreorderSettings {
  /**
   * Master switch for the whole store, set in Settings → Products. Off means
   * nobody — the admin, staff or a vendor — may open a new pre-order;
   * pre-orders already selling keep selling.
   */
  enabled: boolean;
  /** Require an admin to approve each vendor before they can sell one. */
  requireVendorApproval: boolean;
  /** How far ahead a release date may be set. */
  maxLeadDays: number;
  /** The largest deposit a vendor may ask for, as a percent of the line. */
  maxDepositPercent: number;
  /** Days past the release date an unpaid balance survives before expiry. */
  expiryGraceDays: number;
  /**
   * Ask for the balance — and release a fully-paid pre-order for fulfilment —
   * without anybody clicking, once the release date has come.
   *
   * Off by default, and deliberately so: asking for money is a statement that
   * the goods are ready, and only the store knows whether they are. A store
   * that ships on the day it promised can turn this on and stop chasing its
   * own queue; a store whose dates slip should leave it off and keep clicking.
   *
   * It never invents a date. It acts on the release date the vendor already
   * set, which is why it is safe in a way that guessing a NEW date would not
   * be (see `countOverdueReleases`, which still only counts).
   *
   * A fully-paid pre-order is additionally gated on stock actually existing —
   * releasing one consumes the received units, and that claim fails and
   * retries rather than shipping goods nobody has. An order that still owes a
   * balance consumes nothing yet, so for that one the date is the only gate,
   * exactly as it is when an admin clicks "ask for payment".
   */
  autoRelease: boolean;
  /** Days to wait past the release date before {@link autoRelease} acts. */
  autoReleaseDelayDays: number;
  /**
   * Hours between a balance notice the mail server ACCEPTED and the earliest
   * automatic charge of a saved card for it — 1 to 168, 24 by default. Frozen
   * on each balance request when it is made, so a later edit never shortens a
   * notice a shopper already has. A product decision, not a statement about
   * any jurisdiction's rules. See `lib/orders/preorder-notice.ts`.
   */
  balanceChargeNoticeHours: number;
  /**
   * Share of a pre-order payout held back against a late dispute, as a
   * percent. Zero — the default — switches the reserve off entirely.
   *
   * Card networks count a dispute window from the EXPECTED DELIVERY date, so a
   * pre-order sold three months ahead can be charged back long after the
   * vendor has been paid and moved on. Holding a slice for a while is the only
   * lever the platform has once the money has left.
   */
  reservePercent: number;
  /** How long a held slice stays held, counted from the payout. */
  reserveDays: number;
}

// ============================================
// Vendor Configuration Sub-interface
// ============================================

/** Verification-document keys an admin can mark required at registration. */
export const VENDOR_DOCUMENT_KEYS = [
  "businessLicense",
  "taxId",
  "taxCertificate",
  "governmentId",
] as const;
type VendorDocumentKey = (typeof VENDOR_DOCUMENT_KEYS)[number];

/**
 * Policy for the vendor onboarding + plan system. Separate from
 * `multiVendorMode` (mode + permission toggles); this group governs
 * registration, approval, and the subscription/plan feature. Every plan
 * surface is gated on `multiVendorMode.enabled && vendorConfig.plansEnabled`.
 */
/**
 * Which gateways may collect vendor→platform money (boosts, subscription
 * periods). An allowlist, not a capability: the effective offer is always
 * this ∩ settings.payment.<gw>.enabled — credentials stay in Payments.
 */
export interface IPlatformPaymentMethodSettings {
  stripe: boolean;
  paypal: boolean;
  razorpay: boolean;
  paystack: boolean;
  pesapal: boolean;
  iotec: boolean;
  orange_money: boolean;
  mtn_momo: boolean;
}

interface IVendorConfigSettings {
  /** Master switch for the vendor plan/subscription feature. */
  plansEnabled: boolean;
  /** Whether new vendors may self-register via /become-vendor. */
  allowRegistration: boolean;
  /** Force a plan choice at onboarding vs. a silent default fallback. */
  requirePlanSelection: boolean;
  /** Documents an applicant must supply (subset of VENDOR_DOCUMENT_KEYS). */
  requiredDocuments: VendorDocumentKey[];
  /** Plan auto-assigned when the applicant picks none (set once plans exist). */
  defaultPlanId?: string;
  /** Gateways vendors may pay plan subscriptions through. */
  paymentMethods: IPlatformPaymentMethodSettings;
  /**
   * Whether a vendor sees the email and phone of a shopper asking for a price
   * on its product. Off hides them from the vendor's Quotes page, its API and
   * its search alike; the vendor can still price the quote, because the store
   * sends the price to the shopper. Absent reads as on.
   */
  showQuoteContactToVendors: boolean;
  /**
   * Whether a vendor has Orders → Abandoned checkouts: the checkouts that held
   * its own products, with only its own lines and no shopper named. Off hides
   * the page, its menu entry and its API. Absent reads as on.
   */
  showAbandonedCheckoutsToVendors: boolean;
  /**
   * Whether vendors may send their own discount to a shopper who abandoned a
   * checkout with their goods, and the store's limits on it. Off by default:
   * the store's own recovery emails never offer money off, so a marketplace
   * decides for itself whether its sellers may. See
   * `lib/orders/abandoned-offers.ts`.
   */
  abandonedOffers?: {
    enabled?: boolean;
    /** Vendors may also set a standing offer the recovery email carries. */
    automatic?: boolean;
    /** The most an offer may take off the vendor's goods, in percent. */
    maxPercent?: number;
    /** Offers one vendor may send in a day. */
    maxPerVendorPerDay?: number;
    /** The longest an offer may stay valid (never past the recovery link's 14 days). */
    maxValidDays?: number;
  };
}

// ============================================
// Catalog Sub-interface
// ============================================

/**
 * How the catalogue presents itself on the storefront. Platform-wide on
 * purpose: `last` is a single global ordering, and a marketplace grid mixing
 * many vendors cannot honour two sellers asking for opposite orders.
 */
export interface ICatalogSettings {
  /** What listings do with a product nothing can be bought from. */
  outOfStockDisplay: OutOfStockDisplay;
  /**
   * Which formats a NEW product may take, and whether a product may hide its
   * price behind a quote — Settings → Products. Off stops the editor offering
   * it; products already using it are left alone. At least one format stays
   * on. Read through `resolveProductFeatures` (lib/products/product-features).
   */
  physicalProducts: boolean;
  digitalProducts: boolean;
  priceOnRequest: boolean;
}

// ============================================
// Boosting (Sponsored Products) Sub-interface
// ============================================

/**
 * Policy for paid product boosting. Pricing lives on the BoostPosition ladder;
 * the home section's title/limit live in the home-page builder. This section is
 * the feature gate, the two storefront depths it owns, and the booking rules.
 */
interface IBoostingSettings {
  /** Master switch. Off = no storefront output, no vendor nav, no purchases. */
  enabled: boolean;
  /** Gateways vendors may pay boosts through. */
  paymentMethods: IPlatformPaymentMethodSettings;
  /** Per-surface toggles for sponsored placements. */
  placements: {
    home: boolean;
    listing: boolean;
    productPage: boolean;
  };
  /** How many top ladder rungs render on a listing page (1–12). */
  listingSlots: number;
  /** How many top ladder rungs render on the product-page rail (1–12). */
  productPageSlots: number;
  /**
   * Drop a booked product that is out of stock. Not cosmetic: the day is
   * credited back to the vendor in proportion, so this is a refund policy.
   */
  hideOutOfStock: boolean;
  /** Minutes an unpaid checkout holds its booked days (35–120). */
  holdMinutes: number;
  /** How far ahead a booking may start, in days. */
  bookingHorizonDays: number;
  /** Longest single booking, in days. */
  maxBookingDays: number;
}

// ============================================
// Storage Settings Sub-interface
// ============================================

/** Fields every S3-compatible backend needs. */
interface IStorageCredentialsBase {
  bucketName?: string;
  /**
   * A second bucket, with no public access, for the files only the store may
   * open — identity documents, digital products, expense receipts. Same
   * account and keys as `bucketName`. Unset, they share the public bucket.
   */
  privateBucketName?: string;
  accessKeyId?: string;
  secretAccessKey?: string;
  publicUrl?: string;
}

/**
 * Cloudflare R2. No `region` — R2 has exactly one and the provider hardcodes
 * "auto". No `endpoint`: it is derived from `accountId`.
 */
export interface IR2StorageCredentials extends IStorageCredentialsBase {
  accountId?: string;
}

/** Amazon S3 proper. No endpoint — the SDK builds it from the region. */
export interface IS3StorageCredentials extends IStorageCredentialsBase {
  region?: string;
}

/**
 * Self-hosted MinIO. The endpoint is the whole point: it can be any host, so
 * unlike the others it has to be typed in full.
 */
export interface IMinioStorageCredentials extends IStorageCredentialsBase {
  endpoint?: string;
  region?: string;
}

/**
 * DigitalOcean Spaces. The region *is* the endpoint
 * (`<region>.digitaloceanspaces.com`), so only the datacenter slug is asked
 * for — nyc3, sgp1, fra1…
 */
export interface IDigitalOceanStorageCredentials
  extends IStorageCredentialsBase {
  region?: string;
}

export interface IStorageSettings {
  /**
   * `"local"` is legacy, never offered: pre-v1.5 installs still hold it and
   * their files live on the server's disk. Kept in the enum so those documents
   * stay valid until the store picks one of the four real providers.
   */
  provider: "cloudflare_r2" | "s3" | "minio" | "digitalocean" | "local";

  /**
   * One credential block per provider — the shape `IPaymentSettings` already
   * uses for gateways. Configuring one no longer overwrites another's keys, so
   * a provider can be tested (or migrated away from) without retyping the one
   * that is live.
   */
  r2: IR2StorageCredentials;
  s3: IS3StorageCredentials;
  minio: IMinioStorageCredentials;
  digitalocean: IDigitalOceanStorageCredentials;

  /**
   * Pre-v1.5 flat credentials: a single shared set that whichever provider was
   * active had claimed. Kept as a read-only fallback in
   * `resolveStorageCredentials` so an un-migrated install keeps serving media;
   * `pnpm db:migrate storage-credentials` moves them into the block above.
   * Nothing writes here any more — the admin save handler no longer accepts
   * these keys.
   *
   * @deprecated Removed in v2.0.
   */
  accountId?: string;
  endpoint?: string;
  region?: string;
  bucketName?: string;
  accessKeyId?: string;
  secretAccessKey?: string;
  publicUrl?: string;

  maxFileSizeMB: number;
  // Per-media-type limits, Shopify-style. Server picks the type-specific
  // limit when present; falls back to maxFileSizeMB for unknown types.
  maxImageSizeMB?: number;
  maxVideoSizeMB?: number;
  maxModelSizeMB?: number;
  allowedMimeTypes: string[];
  pathPrefix?: string;
}

import type {
  AISalesAgentModel,
  AISalesAgentReasoningEffort,
  AISalesAgentTone,
} from "@/lib/ai-sales-agent/models";

interface IAISalesAgentCapabilities {
  productQA: boolean;
  recommendations: boolean;
  cartActions: boolean;
  checkoutHandoff: boolean;
  orderStatus: boolean;
}

interface IAISalesAgentWidgetSettings {
  position: "bottom-right" | "bottom-left";
  primaryColor: string;
  accentColor: string;
  avatarUrl?: string;
  footerText?: string;
  headerTitle?: string;
  width: number;
  height: number;
  showFooterText: boolean;
}

interface IAISalesAgentFaqEntry {
  question: string;
  answer: string;
  tags?: string[];
}

export interface IAISalesAgentSettings {
  enabled: boolean;
  model: AISalesAgentModel;
  temperature: number;
  reasoningEffort: AISalesAgentReasoningEffort;
  maxRecommendations: number;
  /**
   * Tokens the assistant may spend per calendar month (UTC), all chats
   * together; 0 = unlimited. Past it the assistant answers from the
   * catalogue without the model — lib/ai-sales-agent/usage.ts.
   */
  monthlyTokenBudget: number;
  agentName: string;
  greeting: string;
  tone: AISalesAgentTone;
  instructions?: string;
  escalationMessage: string;
  widget: IAISalesAgentWidgetSettings;
  capabilities: IAISalesAgentCapabilities;
  faq: IAISalesAgentFaqEntry[];
}

interface IAIAuthoringSurfaces {
  products: boolean;
  categories: boolean;
  collections: boolean;
  brands: boolean;
  blogPosts: boolean;
  contentPages: boolean;
  reviews: boolean;
  heroBanner: boolean;
}

export interface IAIAuthoringSettings {
  enabled: boolean;
  /** Shared OpenAI key for all AI features; OPENAI_API_KEY is the env fallback. */
  apiKey?: string;
  /** Empty string = inherit OPENAI_AUTHORING_TEXT_MODEL env or the built-in default. */
  textModel: string;
  /** Empty string = inherit OPENAI_AUTHORING_IMAGE_MODEL env or the built-in default. */
  imageModel: string;
  surfaces: IAIAuthoringSurfaces;
  imageDefaults: {
    size: "auto" | "1024x1024" | "1024x1536" | "1536x1024";
    quality: "auto" | "medium" | "high";
  };
  brandVoice: {
    /** Empty string = no default tone. */
    tone: string;
    instructions: string;
    /** Style guidance appended to every image generation prompt. */
    imageStyle: string;
  };
  /** Brand kit — colors and logo used by image generation and social export. */
  brandKit: {
    /** Hex color, "" = none. Hints generation and sets the export pad color. */
    primaryColor: string;
    secondaryColor: string;
    /** Own-storage logo URL, "" = none. Optional lockup on social exports. */
    logoUrl: string;
  };
  access: {
    staffEnabled: boolean;
    vendorsEnabled: boolean;
  };
  limits: {
    /** 0 = unlimited. */
    textPerUserPerDay: number;
    imagePerUserPerDay: number;
  };
}

type IHomePageSettings = HomePageSettings;
type IContentPagesSettings = ContentPagesSettings;

interface IOnlineStoreSettings {
  activeTheme?: string;
  /** Per-theme values: { [themeId]: Record<fieldKey, value> }. */
  themeSettings?: Record<string, Record<string, unknown>>;
  /** Per-theme merchant CSS: { [themeId]: sheet }. See themes/custom-css.ts. */
  customCss?: Record<string, string>;
}
type INotificationSettings = NotificationSettings;
type IHeaderSettings = HeaderSettings;
type IFooterSettings = FooterSettings;
type ICheckoutSettings = CheckoutSettings;

// ============================================
// Main Settings Interface
// ============================================

/**
 * There is exactly one settings document, and until this existed nothing said
 * so. `findOne()` followed by `create({})` let two concurrent requests on a
 * fresh install both miss and both insert; from then on reads and writes could
 * land on different documents with no error anywhere. The constant key plus a
 * unique index turns that silent fork into a caught write.
 */
const SETTINGS_SINGLETON_KEY = "singleton";

export interface ISettings extends Document {
  /** Always `SETTINGS_SINGLETON_KEY`. Exists only to carry the unique index. */
  key?: string;

  // Grouped Sub-documents
  general: IGeneralSettings;
  appearance: IAppearanceSettings;
  payment: IPaymentSettings;
  email: IEmailSettings;
  sms: ISmsSettings;
  orders: IOrderSettings;
  /** Settings → Tax. Normalized at every read through `normalizeTaxSettings()`. */
  tax: StoredTaxSettings;
  shipping: IShippingSettings;
  seo: ISEOSettings;
  social: ISocialSettings;
  analytics: IAnalyticsSettings;
  maintenance: IMaintenanceSettings;
  mobileApp: IMobileAppSettings;
  security: ISecuritySettings;
  pos: IPOSSettings;
  multiVendorMode: IMultiVendorModeSettings;
  preorder: IPreorderSettings;
  vendorConfig: IVendorConfigSettings;
  catalog: ICatalogSettings;
  boosting: IBoostingSettings;
  notifications: INotificationSettings;
  storage: IStorageSettings;
  aiSalesAgent: IAISalesAgentSettings;
  aiAuthoring: IAIAuthoringSettings;
  header: IHeaderSettings;
  footer: IFooterSettings;
  /** Storefront checkout appearance (constrained editor, never sectionized). */
  checkout: ICheckoutSettings;
  homePage: IHomePageSettings;
  contentPages: IContentPagesSettings;
  /**
   * Store-wide product card configurator (element order groups, visibility,
   * style). Stored Mixed and normalized at every read through
   * `normalizeProductCardConfig()` — lib/products/product-card-config.ts,
   * not this document, defines the shape.
   */
  productCard: unknown;
  /**
   * Slide templates a merchant saved from the slider editor. Stored Mixed
   * and normalized at every read through `normalizeSlideTemplate()` —
   * lib/sliders/types.ts defines the shape.
   */
  sliderTemplates: unknown;
  /**
   * Theme engine state: which theme is active and each theme's setting
   * values, keyed by theme id so switching preserves both sides. Stored
   * Mixed and normalized at every read through `resolveActiveTheme()` —
   * the manifest's schema, not this document, defines the shape. Written
   * only by /api/admin/theme-settings, never by the settings PUT.
   */
  onlineStore: IOnlineStoreSettings;
  /** Set once by the install wizard; its presence hard-locks /install. */
  installedAt?: Date;
  /**
   * Short-lived lease held while a wizard run is creating the admin. The
   * lock itself is `installedAt`/an existing admin; this only stops two
   * concurrent runs from both getting through the check.
   */
  installClaimedAt?: Date | null;

  // Metadata
  updatedAt: Date;
  updatedBy?: string;
}

// ============================================
// Mongoose Schema
// ============================================

// Shared by vendorConfig.paymentMethods and boosting.paymentMethods. All
// default true: the allowlist only narrows what Payments already enables.
const PlatformPaymentMethodsSchema = new Schema<IPlatformPaymentMethodSettings>(
  {
    stripe: { type: Boolean, default: true },
    paypal: { type: Boolean, default: true },
    razorpay: { type: Boolean, default: true },
    paystack: { type: Boolean, default: true },
    pesapal: { type: Boolean, default: true },
    iotec: { type: Boolean, default: true },
    orange_money: { type: Boolean, default: true },
    mtn_momo: { type: Boolean, default: true },
  },
  { _id: false },
);

/**
 * Shared by both carrier blocks — the shape is the same and the meaning is the
 * same, and two copies is how one of them ends up without the message field.
 */
/**
 * One rate-limit preset field. A factory rather than a shared object because
 * Mongoose needs a distinct definition per path — and rather than seven copies
 * of the same enum literal, which is how six of them stay in step and the
 * seventh quietly does not.
 */
const rateLimitPresetField = () => ({
  type: String,
  enum: [...RATE_LIMIT_PRESETS],
  default: "default",
});

/**
 * One event's channel switches, built from the shared defaults. The fifteen
 * hand-written copies this replaced each restated their booleans as literals,
 * free to disagree with DEFAULT_NOTIFICATION_SETTINGS — and adding a channel
 * meant editing all fifteen.
 */
const notificationChannelField = (defaults: NotificationChannelSettings) => ({
  type: new Schema<NotificationChannelSettings>(
    {
      inApp: { type: Boolean, default: defaults.inApp },
      email: { type: Boolean, default: defaults.email },
      browserPush: { type: Boolean, default: defaults.browserPush },
      sms: { type: Boolean, default: defaults.sms },
    },
    { _id: false },
  ),
  default: () => ({ ...defaults }),
});

/** An audience's events — admin, staff, vendor or customer. */
const notificationGroupField = (
  defaults: Record<string, NotificationChannelSettings>,
) => ({
  type: new Schema(
    Object.fromEntries(
      Object.entries(defaults).map(([event, channels]) => [
        event,
        notificationChannelField(channels),
      ]),
    ),
    { _id: false },
  ),
  // A copy: handing Mongoose the shared constant let a document write into
  // the defaults every later document starts from.
  default: () => structuredClone(defaults),
});

const CarrierAuthFailureSchema = new Schema<ICarrierAuthFailure>(
  {
    at: { type: Date, required: true },
    message: { type: String, maxlength: 500 },
  },
  { _id: false },
);

const SettingsSchema = new Schema<ISettings>(
  {
    // Documents written before this field existed carry no key at all. A unique
    // index treats those as null and allows exactly one, which is precisely the
    // guarantee wanted — so an un-migrated install is already protected.
    key: {
      type: String,
      default: SETTINGS_SINGLETON_KEY,
      unique: true,
    },

    // General Settings
    general: {
      type: new Schema(
        {
          storeName: {
            type: String,
            required: true,
            default: DEFAULT_STORE_NAME,
          },
          storeDescription: String,
          storeEmail: {
            type: String,
            required: true,
            default: "store@example.com",
          },
          storePhone: String,
          storeDomain: String,
          storeAddress: String,
          logoUrl: String,
          darkModeLogoUrl: String,
          faviconUrl: String,
          appIconUrl: String,
          defaultLanguage: { type: String, default: DEFAULT_LANGUAGE },
          defaultCurrency: { type: String, default: DEFAULT_CURRENCY },
          supportedLanguages: {
            type: [String],
            default: ["en", "bn", "ar", "hi", "zh", "ja", "fr", "es"],
          },
          countryAvailability: {
            type: new Schema(
              {
                mode: {
                  type: String,
                  enum: Object.values(COUNTRY_AVAILABILITY_MODES),
                  default: DEFAULT_COUNTRY_AVAILABILITY.mode,
                },
                countryCodes: {
                  type: [String],
                  default: [],
                },
              },
              { _id: false },
            ),
            default: () => ({
              ...DEFAULT_COUNTRY_AVAILABILITY,
              countryCodes: [...DEFAULT_COUNTRY_AVAILABILITY.countryCodes],
            }),
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Appearance Settings
    appearance: {
      type: new Schema(
        {
          primaryColor: { type: String, default: DEFAULT_PRIMARY_COLOR },
          secondaryColor: { type: String, default: DEFAULT_SECONDARY_COLOR },
          accentColor: { type: String, default: DEFAULT_ACCENT_COLOR },
          skeletonColor: { type: String, default: "" },
          theme: {
            type: String,
            // "system" stays in the enum only so documents written before
            // OS-preference mode was removed still validate on save (Mongoose
            // validates the whole document, not just modified paths, and
            // setters don't run on hydrate). `migrateSettings()` rewrites it to
            // "light" and every read goes through `normalizeThemeMode`, so it
            // is never honored as a mode.
            enum: ["light", "dark", "system"],
            default: DEFAULT_THEME_MODE,
          },
          presetColor: {
            type: String,
            enum: ["default", "cyan", "purple", "blue", "orange", "red"],
            default: DEFAULT_PRESET_COLOR,
          },
          customPresets: {
            type: [
              new Schema(
                {
                  id: { type: String, required: true },
                  name: { type: String, default: "" },
                  primaryColor: { type: String, default: "" },
                  secondaryColor: { type: String, default: "" },
                  accentColor: { type: String, default: "" },
                },
                { _id: false },
              ),
            ],
            default: [],
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Payment Settings
    payment: {
      type: new Schema(
        {
          stripe: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                publishableKey: String,
                secretKey: String,
                webhookSecret: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          paypal: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                clientId: String,
                clientSecret: String,
                mode: {
                  type: String,
                  enum: ["sandbox", "live"],
                  default: "sandbox",
                },
                webhookId: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          razorpay: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                keyId: String,
                keySecret: String,
                webhookSecret: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          paystack: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                publicKey: String,
                secretKey: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          pesapal: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                consumerKey: String,
                consumerSecret: String,
                mode: {
                  type: String,
                  enum: ["sandbox", "live"],
                  default: "sandbox",
                },
                ipnId: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          iotec: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                clientId: String,
                clientSecret: String,
                walletId: String,
                mode: {
                  type: String,
                  enum: ["sandbox", "live"],
                  default: "sandbox",
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          orange_money: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                clientId: String,
                clientSecret: String,
                merchantKey: String,
                // Free text, not an enum: Orange's country coverage is
                // per-contract and grows, so a fixed list would lock out a
                // merchant in a country we never enumerated.
                country: { type: String, default: "dev" },
                mode: {
                  type: String,
                  enum: ["sandbox", "live"],
                  default: "sandbox",
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          mtn_momo: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                subscriptionKey: String,
                apiUser: String,
                apiKey: String,
                // Free text, not an enum: the OpCo value is issued at
                // onboarding and a fixed list would lock out a market we
                // never enumerated (same reasoning as Orange's country).
                targetEnvironment: String,
                callbackHost: String,
                mode: {
                  type: String,
                  enum: ["sandbox", "live"],
                  default: "sandbox",
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          cod: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: true },
                instructions: String,
                minOrderAmount: Number,
                maxOrderAmount: Number,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          /**
           * The human check a checkout asks for once cards have been refused
           * too often — see `lib/checkout/turnstile.ts`. Off, and with no
           * keys, until a store enters its own: the velocity pause beside it
           * works without any of this.
           */
          turnstile: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                siteKey: String,
                secretKey: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          /**
           * Which gateways write a checkout attempt instead of an order when
           * the shopper leaves to pay — the rollout switch for the
           * checkout-attempt work. See `lib/payments/attempt-gateways.ts`.
           *
           * Empty by default, which is today's behaviour for every gateway.
           * It lives here, beside the gateways it names, rather than in
           * `settings.checkout` (which is the storefront checkout's
           * appearance) — and it is deliberately absent from the admin UI:
           * this is an operator's switch, not a merchant setting.
           */
          attemptGateways: {
            type: [String],
            default: () => [],
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Email Settings
    email: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: false },
          smtp: {
            type: new Schema(
              {
                host: String,
                port: { type: Number, default: 587 },
                user: String,
                password: String,
                secure: { type: Boolean, default: false },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          fromEmail: String,
          fromName: String,
          replyTo: String,
          logRetentionDays: {
            type: Number,
            enum: [7, 30, 90],
            default: 30,
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // SMS Settings (Twilio)
    sms: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: false },
          twilio: {
            type: new Schema(
              {
                accountSid: String,
                authToken: String,
                messagingServiceSid: String,
                fromNumber: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          defaultCountry: String,
          includeLinks: { type: Boolean, default: true },
          logRetentionDays: {
            type: Number,
            enum: [7, 30, 90],
            default: 30,
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Order Settings
    orders: {
      type: new Schema(
        {
          prefix: {
            type: String,
            default: DEFAULT_ORDER_PREFIX,
            trim: true,
            uppercase: true,
            match: ORDER_PREFIX_PATTERN,
          },
          taxRate: {
            type: Number,
            default: DEFAULT_ORDER_TAX_RATE,
            min: 0,
            max: 1,
          },
          freeShippingThreshold: { type: Number, default: 0, min: 0 },
          defaultShippingCost: {
            type: Number,
            default: DEFAULT_ORDER_SHIPPING_COST,
            min: 0,
          },
          // What a customer spends, in the store currency, for each loyalty
          // point. One per unit was a dollar in one store and a taka in
          // another — see lib/customers/loyalty.ts.
          loyaltySpendPerPoint: {
            type: Number,
            default: DEFAULT_LOYALTY_SPEND_PER_POINT,
            min: MIN_LOYALTY_SPEND_PER_POINT,
          },
          commission: {
            type: new Schema(
              {
                vendorRate: {
                  type: Number,
                  default: DEFAULT_VENDOR_COMMISSION_RATE,
                  min: 0,
                  max: 100,
                },
                minWithdrawalAmount: {
                  type: Number,
                  default: DEFAULT_MIN_WITHDRAWAL_AMOUNT,
                  min: 0,
                },
                minWithdrawalByCurrency: {
                  type: Map,
                  of: { type: Number, min: 0 },
                  default: undefined,
                },
                autoPayoutDrafts: {
                  type: Boolean,
                  default: true,
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          returns: {
            type: new Schema(
              {
                windowDays: {
                  type: Number,
                  default: DEFAULT_RETURN_WINDOW_DAYS,
                  min: MIN_RETURN_WINDOW_DAYS,
                  max: MAX_RETURN_WINDOW_DAYS,
                },
                shippingRefund: {
                  type: String,
                  enum: RETURN_SHIPPING_REFUND_MODES,
                  default: DEFAULT_RETURN_SHIPPING_REFUND,
                },
                restockingFeePercent: {
                  type: Number,
                  default: DEFAULT_RESTOCKING_FEE_PERCENT,
                  min: 0,
                  max: 100,
                },
                returnShippingFee: {
                  type: Number,
                  default: DEFAULT_RETURN_SHIPPING_FEE,
                  min: 0,
                },
                refundAdminFeePercent: {
                  type: Number,
                  default: DEFAULT_REFUND_ADMIN_FEE_PERCENT,
                  min: 0,
                  max: 100,
                },
                // 0 means uncapped, which is why there is no max here.
                refundAdminFeeCap: {
                  type: Number,
                  default: DEFAULT_REFUND_ADMIN_FEE_CAP,
                  min: 0,
                },
                billVendorCodShipping: {
                  type: Boolean,
                  default: DEFAULT_BILL_VENDOR_COD_SHIPPING,
                },
                // Empty means the default wording, which is shown instead.
                instructions: {
                  type: String,
                  trim: true,
                  maxlength: RETURN_INSTRUCTIONS_MAX_LENGTH,
                  default: "",
                },
                // Every product in these collections is final sale.
                finalSaleCollectionIds: {
                  type: [{ type: Schema.Types.ObjectId, ref: "Collection" }],
                  default: [],
                },
                // R6. Every default here is how returns worked before: a
                // window in days, counted per parcel, asked for by shoppers.
                windowUnlimited: { type: Boolean, default: false },
                windowStart: {
                  type: String,
                  enum: RETURN_WINDOW_STARTS,
                  default: DEFAULT_RETURN_WINDOW_START,
                },
                selfServe: { type: Boolean, default: true },
                payoutHoldMaxDays: {
                  type: Number,
                  default: DEFAULT_PAYOUT_HOLD_MAX_DAYS,
                  min: MIN_RETURN_WINDOW_DAYS,
                  max: MAX_RETURN_WINDOW_DAYS,
                },
                windowOverrides: {
                  type: [
                    new Schema(
                      {
                        collectionId: {
                          type: Schema.Types.ObjectId,
                          ref: "Collection",
                          required: true,
                        },
                        windowDays: {
                          type: Number,
                          required: true,
                          min: MIN_RETURN_WINDOW_DAYS,
                          max: MAX_RETURN_WINDOW_DAYS,
                        },
                      },
                      { _id: false },
                    ),
                  ],
                  default: [],
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    shipping: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: false },
          weightUnit: {
            type: String,
            enum: ["kg", "lb"],
            default: "kg",
          },
          origin: {
            type: new Schema(
              {
                country: { type: String, default: "" },
                state: String,
                city: String,
                postalCode: String,
                address1: String,
                address2: String,
              },
              { _id: false },
            ),
            default: undefined,
          },
          delivery: {
            type: new Schema(
              {
                processingDaysMin: { type: Number, default: 0 },
                processingDaysMax: { type: Number, default: 0 },
                showEstimatedDelivery: { type: Boolean, default: true },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          zones: {
            type: [
              new Schema(
                {
                  id: { type: String, required: true },
                  name: { type: String, required: true },
                  countries: { type: [String], default: [] },
                  regions: { type: [String], default: [] },
                  isFallback: { type: Boolean, default: false },
                  rates: {
                    type: [
                      new Schema(
                        {
                          id: { type: String, required: true },
                          name: { type: String, required: true },
                          type: {
                            type: String,
                            enum: [
                              "flat",
                              "free_over",
                              "subtotal_range",
                              "weight_range",
                            ],
                            default: "flat",
                          },
                          price: { type: Number, default: 0 },
                          freeOver: Number,
                          minSubtotal: Number,
                          maxSubtotal: Number,
                          minWeight: Number,
                          maxWeight: Number,
                          pricePerWeightUnit: Number,
                          minDays: Number,
                          maxDays: Number,
                          active: { type: Boolean, default: true },
                        },
                        { _id: false },
                      ),
                    ],
                    default: [],
                  },
                },
                { _id: false },
              ),
            ],
            default: [],
          },
          fallbackRate: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                name: { type: String, default: "Standard" },
                price: { type: Number, default: 0 },
                minDays: Number,
                maxDays: Number,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          customs: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                dutyMode: {
                  type: String,
                  enum: ["DDP", "DDU"],
                  default: "DDU",
                },
                dutyRatePercent: Number,
                deMinimis: Number,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          vendorShipping: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          // Store-wide default for who collects COD cash. `vendor` preserves
          // the behaviour every existing order already has.
          codCollectedBy: {
            type: String,
            enum: Object.values(COD_COLLECTED_BY),
            default: COD_COLLECTED_BY.VENDOR,
          },

          // Carrier integration. Mongoose runs in strict mode, so a key absent
          // from this block is silently dropped by `settings.set()` — every new
          // carrier field must be declared here as well as on the interface.
          carriers: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                labelStorage: {
                  type: String,
                  enum: CARRIER_LABEL_STORAGE_MODES,
                  default: "carrier_url",
                },
                shippo: {
                  type: new Schema(
                    {
                      enabled: { type: Boolean, default: false },
                      mode: {
                        type: String,
                        enum: CARRIER_MODES,
                        default: "test",
                      },
                      testToken: String,
                      liveToken: String,
                      webhookSecret: String,
                      webhookSecretHash: String,
                      webhookRegisteredAt: Date,
                      labelFileType: {
                        type: String,
                        enum: CARRIER_LABEL_FILE_TYPES,
                        default: "PDF_4x6",
                      },
                      serviceTokenAllowList: { type: [String], default: [] },
                      authFailure: {
                        type: CarrierAuthFailureSchema,
                        default: undefined,
                      },
                    },
                    { _id: false },
                  ),
                  default: () => ({}),
                },
                shiprocket: {
                  type: new Schema(
                    {
                      enabled: { type: Boolean, default: false },
                      email: String,
                      password: String,
                      pickupLocationName: String,
                      channelId: String,
                      webhookToken: String,
                      courierIdAllowList: { type: [Number], default: [] },
                      tokenCache: {
                        type: new Schema(
                          {
                            token: String,
                            expiresAt: Date,
                          },
                          { _id: false },
                        ),
                        default: () => ({}),
                      },
                      authFailure: {
                        type: CarrierAuthFailureSchema,
                        default: undefined,
                      },
                    },
                    { _id: false },
                  ),
                  default: () => ({}),
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },

          // Seeded with one box so the packer never reaches its last-resort
          // branch on a fresh install, and no seed script is needed.
          packages: {
            type: [
              new Schema(
                {
                  id: { type: String, required: true },
                  name: { type: String, required: true, maxlength: 120 },
                  length: { type: Number, required: true, min: 0 },
                  width: { type: Number, required: true, min: 0 },
                  height: { type: Number, required: true, min: 0 },
                  dimensionUnit: {
                    type: String,
                    enum: DIMENSION_UNITS,
                    default: "cm",
                  },
                  emptyWeight: { type: Number, min: 0, default: 0 },
                  weightUnit: {
                    type: String,
                    enum: PARCEL_WEIGHT_UNITS,
                    default: "kg",
                  },
                  maxWeight: { type: Number, min: 0 },
                  isDefault: { type: Boolean, default: false },
                  active: { type: Boolean, default: true },
                },
                { _id: false },
              ),
            ],
            default: () => [{ ...DEFAULT_PACKAGE_PRESET }],
          },

          // Undeliverable addresses; defaults in address-hold-policy.
          addressHold: {
            type: new Schema(
              {
                suggestAtCheckout: { type: Boolean, default: true },
                checkAfterOrder: { type: Boolean, default: true },
                autoRequest: { type: Boolean, default: true },
                reminderDays: { type: [Number], default: () => [1, 3] },
                deadlineDays: { type: Number, min: 1, max: 60, default: 7 },
                onDeadline: {
                  type: String,
                  enum: ["notify", "cancel"],
                  default: "notify",
                },
                keepReturnShipping: { type: Boolean, default: false },
              },
              { _id: false },
            ),
            default: () => ({}),
          },

          automation: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                // Off by default: a COD order is unpaid by definition, and
                // auto-buying a label for one is the merchant's risk to take
                // deliberately rather than inherit.
                includeCod: { type: Boolean, default: false },
                minOrderValue: { type: Number, min: 0 },
                maxOrderValue: { type: Number, min: 0 },
                rateChoice: {
                  type: String,
                  enum: CARRIER_RATE_CHOICES,
                  default: "cheapest",
                },
                fixedProvider: { type: String, enum: CARRIER_PROVIDERS },
                fixedServiceToken: String,
                buyLabel: { type: Boolean, default: true },
                markOrderShipped: { type: Boolean, default: true },
                restrictToCountries: { type: [String], default: [] },
                maxLabelCost: { type: Number, min: 0 },
              },
              { _id: false },
            ),
            default: () => ({}),
          },

          // Empty by default: the built-in list already covers the couriers
          // named in `tracking-urls.ts`, and a store that never hand-enters an
          // AWB needs none of this.
          courierTrackingLinks: {
            type: [
              new Schema(
                {
                  carrier: { type: String, required: true, trim: true, maxlength: 100 },
                  urlTemplate: {
                    type: String,
                    required: true,
                    trim: true,
                    maxlength: 500,
                  },
                },
                { _id: false },
              ),
            ],
            default: () => [],
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // SEO Settings
    seo: {
      type: new Schema(
        {
          metaTitle: String,
          metaDescription: String,
          metaKeywords: String,
          ogImage: String,
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Social Settings
    social: {
      type: new Schema(
        {
          facebookUrl: String,
          twitterUrl: String,
          instagramUrl: String,
          youtubeUrl: String,
          linkedinUrl: String,
          tiktokUrl: String,
          share: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: true },
                copyLink: { type: Boolean, default: true },
                facebook: { type: Boolean, default: true },
                twitter: { type: Boolean, default: true },
                whatsapp: { type: Boolean, default: true },
                telegram: { type: Boolean, default: false },
                pinterest: { type: Boolean, default: false },
                linkedin: { type: Boolean, default: false },
                email: { type: Boolean, default: true },
                custom: {
                  type: [
                    new Schema(
                      {
                        id: String,
                        label: String,
                        urlTemplate: String,
                        enabled: { type: Boolean, default: true },
                        icon: String,
                      },
                      { _id: false },
                    ),
                  ],
                  default: [],
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Analytics Settings
    analytics: {
      type: new Schema(
        {
          googleAnalyticsId: String,
          googleTagManagerId: String,
          facebookPixelId: String,
          tiktokPixelId: String,
          plausibleDomain: String,
          plausibleApiKey: String,
          plausibleSelfHosted: { type: Boolean, default: false },
          plausibleBaseUrl: String,
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Maintenance Settings
    maintenance: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: false },
          title: {
            type: String,
            default: `${DEFAULT_STORE_NAME} is temporarily offline`,
          },
          message: {
            type: String,
            default:
              "We're making a few improvements behind the scenes. Thanks for your patience.",
          },
          backgroundImageUrl: String,
          countdownEnabled: { type: Boolean, default: false },
          countdownEndsAt: String,
          allowedIPs: { type: [String], default: [] },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Mobile apps. Off until the admin switches an app's API on; formats are
    // checked on save (validateMobileAppSettings), never here.
    mobileApp: {
      type: new Schema(
        {
          shop: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                scheme: { type: String, default: "" },
                ios: {
                  type: new Schema(
                    {
                      bundleId: String,
                      teamId: String,
                      appStoreUrl: String,
                      minVersion: String,
                      latestVersion: String,
                    },
                    { _id: false },
                  ),
                  default: () => ({}),
                },
                android: {
                  type: new Schema(
                    {
                      packageName: String,
                      sha256CertFingerprints: { type: [String], default: [] },
                      playStoreUrl: String,
                      minVersion: String,
                      latestVersion: String,
                    },
                    { _id: false },
                  ),
                  default: () => ({}),
                },
                allowDigitalPurchases: { type: Boolean, default: false },
                expoAccessToken: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          biz: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                scheme: { type: String, default: "" },
                ios: {
                  type: new Schema(
                    {
                      bundleId: String,
                      appStoreUrl: String,
                      minVersion: String,
                      latestVersion: String,
                    },
                    { _id: false },
                  ),
                  default: () => ({}),
                },
                android: {
                  type: new Schema(
                    {
                      packageName: String,
                      playStoreUrl: String,
                      minVersion: String,
                      latestVersion: String,
                    },
                    { _id: false },
                  ),
                  default: () => ({}),
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Security Settings
    security: {
      type: new Schema(
        {
          emailVerificationRequired: { type: Boolean, default: false },
          emailVerificationForVendors: { type: Boolean, default: false },
          emailVerificationRequiredSince: Date,
          emailVerificationForVendorsSince: Date,
          smtpVerifiedAt: Date,
          smtpVerificationFingerprint: String,
          twoFactorEnabled: { type: Boolean, default: false },
          twoFactorRequiredForAdmin: { type: Boolean, default: false },
          twoFactorRequiredForVendors: { type: Boolean, default: false },
          twoFactorRequiredForStaff: { type: Boolean, default: false },
          googleOAuthEnabled: { type: Boolean, default: false },
          googleClientId: String,
          googleClientSecret: String,
          facebookOAuthEnabled: { type: Boolean, default: false },
          facebookAppId: String,
          facebookAppSecret: String,
          // No `min`/`max` on these four, deliberately. Mongoose validates the
          // whole document on save, not just the modified paths, so a bound
          // added here would reject *every* future security save from any store
          // already holding an out-of-range value — locking the admin out of the
          // one screen where they could correct it. The range is enforced at the
          // two places that can do so safely instead: the settings API refuses
          // to store a new bad value, and each consumer clamps what it reads
          // (`normalizeSessionMaxAgeDays`, `normalizePasswordPolicy`,
          // `normalizeLockoutPolicy`).
          sessionMaxAgeDays: {
            type: Number,
            default: DEFAULT_SESSION_MAX_AGE_DAYS,
          },
          maxLoginAttempts: {
            type: Number,
            default: DEFAULT_MAX_LOGIN_ATTEMPTS,
          },
          lockoutDurationMinutes: {
            type: Number,
            default: DEFAULT_LOCKOUT_MINUTES,
          },
          rateLimiting: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: true },
                ipPreset: rateLimitPresetField(),
                adminPreset: rateLimitPresetField(),
                vendorPreset: rateLimitPresetField(),
                checkoutPreset: rateLimitPresetField(),
                cartPreset: rateLimitPresetField(),
                couponPreset: rateLimitPresetField(),
                authPreset: rateLimitPresetField(),
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          minPasswordLength: { type: Number, default: 8 },
          requireUppercase: { type: Boolean, default: false },
          requireNumbers: { type: Boolean, default: false },
          requireSpecialChars: { type: Boolean, default: false },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // POS Settings
    pos: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: false },
          allowAdminSales: { type: Boolean, default: true },
          allowVendorSales: { type: Boolean, default: true },
          allowSellerSales: { type: Boolean, default: true },
          defaultPosLocationId: { type: String },
          customize: {
            type: new Schema(
              {
                printedReceiptsEnabled: { type: Boolean, default: false },
                receiptPrinter: { type: String },
                openCashDrawer: { type: Boolean, default: false },
                soundEnabled: { type: Boolean, default: true },
                soundVolume: { type: Number, default: 50, min: 0, max: 100 },
                soundAddToCart: { type: Boolean, default: true },
                soundOrderComplete: { type: Boolean, default: true },
                soundPayment: { type: Boolean, default: true },
                soundError: { type: Boolean, default: true },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          checkout: {
            type: new Schema(
              {
                paymentMethods: {
                  type: [String],
                  enum: [...POS_SELECTABLE_PAYMENT_METHODS],
                  default: ["cash", "card"],
                },
                allowDeposits: { type: Boolean, default: false },
                requireOpenRegister: { type: Boolean, default: false },
                pricesIncludeTax: { type: Boolean, default: false },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          orders: {
            type: new Schema(
              {
                orderNumberPrefix: { type: String, default: "POS" },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          // Bounds repeated from lib/pos/offline-session.ts for documents saved
          // through `save()`; the settings route refuses a bad value at the
          // door (`validatePosSettings`), and the register clamps on read.
          offline: {
            type: new Schema(
              {
                sessionHours: { type: Number, default: 12, min: 1, max: 72 },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Multi-Vendor Mode
    multiVendorMode: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: false },
          canManageProducts: { type: Boolean, default: true },
          canViewOrders: { type: Boolean, default: true },
          canManageOrders: { type: Boolean, default: true },
          canManageStoreSettings: { type: Boolean, default: true },
          canViewAnalytics: { type: Boolean, default: true },
          canManageDiscounts: { type: Boolean, default: true },
          canManagePayouts: { type: Boolean, default: true },
          canAccessPOS: { type: Boolean, default: true },
          // Deliberately no default: an ABSENT map means "read the legacy
          // booleans above", while a present one is the operator's explicit
          // per-pack choice. Defaulting it would silently migrate every store.
          packPolicy: {
            type: new Schema(
              Object.fromEntries(
                ALL_VENDOR_PACKS.map((pack) => [pack, { type: Boolean }]),
              ),
              { _id: false },
            ),
            default: undefined,
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Pre-order guard rails (see IPreorderSettings for why these defaults)
    preorder: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: true },
          requireVendorApproval: { type: Boolean, default: false },
          maxLeadDays: { type: Number, default: 180, min: 1, max: 730 },
          maxDepositPercent: { type: Number, default: 100, min: 0, max: 100 },
          expiryGraceDays: { type: Number, default: 14, min: 1, max: 365 },
          // Off by default, like the reserve below and for the same reason: a
          // version bump must never start asking a store's shoppers for money
          // on its behalf.
          autoRelease: { type: Boolean, default: false },
          autoReleaseDelayDays: { type: Number, default: 0, min: 0, max: 90 },
          balanceChargeNoticeHours: { type: Number, default: 24, min: 1, max: 168 },
          // Off by default: withholding a vendor's money is a policy a store
          // opts into, never something a version bump starts doing to them.
          reservePercent: { type: Number, default: 0, min: 0, max: 50 },
          reserveDays: { type: Number, default: 90, min: 1, max: 365 },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Vendor Configuration (onboarding + plan policy)
    vendorConfig: {
      type: new Schema(
        {
          plansEnabled: { type: Boolean, default: false },
          allowRegistration: { type: Boolean, default: true },
          requirePlanSelection: { type: Boolean, default: false },
          requiredDocuments: {
            type: [String],
            enum: VENDOR_DOCUMENT_KEYS,
            default: [],
          },
          defaultPlanId: { type: String },
          paymentMethods: {
            type: PlatformPaymentMethodsSchema,
            default: () => ({}),
          },
          showQuoteContactToVendors: { type: Boolean, default: true },
          showAbandonedCheckoutsToVendors: { type: Boolean, default: true },
          abandonedOffers: {
            type: new Schema(
              {
                enabled: { type: Boolean, default: false },
                automatic: { type: Boolean, default: true },
                maxPercent: { type: Number, min: 1, max: 90, default: 30 },
                maxPerVendorPerDay: { type: Number, min: 1, max: 1000, default: 20 },
                maxValidDays: { type: Number, min: 1, max: 14, default: 14 },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // How the catalogue presents itself on the storefront.
    catalog: {
      type: new Schema(
        {
          // Defaults to "show" — the behaviour every storefront had before
          // this field existed. An upgrade must not reorder a live store's
          // grids; the install wizard opts new stores into "last" instead.
          outOfStockDisplay: {
            type: String,
            enum: [...OUT_OF_STOCK_DISPLAY_VALUES],
            default: DEFAULT_OUT_OF_STOCK_DISPLAY,
          },
          // On by default: every store could sell all of these before the
          // switches existed, and an upgrade must not take one away.
          physicalProducts: { type: Boolean, default: true },
          digitalProducts: { type: Boolean, default: true },
          priceOnRequest: { type: Boolean, default: true },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Settings → Tax (lib/tax/tax-settings.ts). Empty until the first save:
    // the store runs on `orders.taxRate` until then. No defaults below — a
    // missing `calculation.posPricesIncludeTax` reads the POS setting it
    // replaced, which a default would hide.
    tax: {
      type: new Schema(
        {
          classes: {
            type: [
              new Schema(
                { key: String, name: String, description: String },
                { _id: false },
              ),
            ],
            default: undefined,
          },
          regions: {
            type: [
              new Schema(
                {
                  key: String,
                  name: String,
                  country: String,
                  registrationLabel: String,
                  registrationNumber: String,
                  rates: {
                    type: [
                      new Schema(
                        {
                          classKey: String,
                          effectiveFrom: { type: Date, default: null },
                          components: {
                            type: [
                              new Schema(
                                { name: String, rate: Number, compound: Boolean },
                                { _id: false },
                              ),
                            ],
                            default: undefined,
                          },
                        },
                        { _id: false },
                      ),
                    ],
                    default: undefined,
                  },
                },
                { _id: false },
              ),
            ],
            default: undefined,
          },
          calculation: {
            type: new Schema(
              { posPricesIncludeTax: Boolean },
              { _id: false },
            ),
            default: undefined,
          },
          // How vendors may change their products' tax; absent reads as
          // "approval" (`vendorTaxChangePolicy`).
          marketplace: {
            type: new Schema(
              { vendorTaxChanges: String },
              { _id: false },
            ),
            default: undefined,
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Boosting (sponsored products). Pricing lives on the BoostPosition
    // ladder; this section is the feature gate, the depths and the booking
    // rules.
    boosting: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: false },
          paymentMethods: {
            type: PlatformPaymentMethodsSchema,
            default: () => ({}),
          },
          placements: {
            type: new Schema(
              {
                home: { type: Boolean, default: true },
                listing: { type: Boolean, default: true },
                productPage: { type: Boolean, default: true },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          // 12 is MAX_PLACEMENT_DEPTH — how deep a single surface renders, not
          // how many rungs the ladder may have (BOOST_MAX_POSITIONS is 50).
          listingSlots: { type: Number, default: 2, min: 1, max: 12 },
          productPageSlots: { type: Number, default: 8, min: 1, max: 12 },
          hideOutOfStock: { type: Boolean, default: true },
          // 35 is the floor because Stripe requires checkout.session.expires_at
          // to be at least 30 minutes out and the hold is stamped before the
          // session is created.
          holdMinutes: { type: Number, default: 45, min: 35, max: 120 },
          bookingHorizonDays: { type: Number, default: 60, min: 7, max: 365 },
          maxBookingDays: { type: Number, default: 60, min: 1, max: 365 },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Notification Settings
    notifications: {
      type: new Schema(
        {
          admin: notificationGroupField(DEFAULT_NOTIFICATION_SETTINGS.admin),
          staff: notificationGroupField(DEFAULT_NOTIFICATION_SETTINGS.staff),
          vendor: notificationGroupField(DEFAULT_NOTIFICATION_SETTINGS.vendor),
          customer: notificationGroupField(
            DEFAULT_NOTIFICATION_SETTINGS.customer,
          ),
        },
        { _id: false },
      ),
      default: () => structuredClone(DEFAULT_NOTIFICATION_SETTINGS),
    },

    // Storage Settings
    storage: {
      type: new Schema(
        {
          provider: {
            type: String,
            // "local" is not selectable — see IStorageSettings. It stays in
            // the enum so pre-v1.5 documents remain valid documents.
            enum: ["cloudflare_r2", "s3", "minio", "digitalocean", "local"],
            default: "cloudflare_r2",
          },

          // Per-provider credentials. Kept apart so switching provider in the
          // admin never clobbers the other one's keys.
          r2: {
            type: new Schema(
              {
                accountId: String,
                bucketName: String,
                privateBucketName: String,
                accessKeyId: String,
                secretAccessKey: String,
                publicUrl: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          s3: {
            type: new Schema(
              {
                region: { type: String, default: "us-east-1" },
                bucketName: String,
                privateBucketName: String,
                accessKeyId: String,
                secretAccessKey: String,
                publicUrl: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          minio: {
            type: new Schema(
              {
                endpoint: String,
                region: { type: String, default: "us-east-1" },
                bucketName: String,
                privateBucketName: String,
                accessKeyId: String,
                secretAccessKey: String,
                publicUrl: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          digitalocean: {
            type: new Schema(
              {
                region: { type: String, default: "nyc3" },
                bucketName: String,
                privateBucketName: String,
                accessKeyId: String,
                secretAccessKey: String,
                publicUrl: String,
              },
              { _id: false },
            ),
            default: () => ({}),
          },

          // Deprecated pre-v1.5 flat credentials. Still declared so mongoose
          // hydrates them on an un-migrated document — the resolver's fallback
          // reads them, and `db:migrate storage-credentials` clears them once
          // they have been copied into the block above. `region` deliberately
          // lost its "auto" default: re-stamping it would resurrect the field
          // on every save after the migration removed it.
          accountId: String,
          endpoint: String,
          region: String,
          bucketName: String,
          accessKeyId: String,
          secretAccessKey: String,
          publicUrl: String,

          maxFileSizeMB: { type: Number, default: 20 },
          maxImageSizeMB: { type: Number, default: 20 },
          maxVideoSizeMB: { type: Number, default: 1024 },
          maxModelSizeMB: { type: Number, default: 500 },
          allowedMimeTypes: {
            type: [String],
            // The admin narrows this list from the Storage tab; the settings
            // API refuses anything outside it. Kept in one place so the default
            // and the ceiling cannot drift apart.
            default: () => [...SUPPORTED_UPLOAD_MIME_TYPES],
          },
          pathPrefix: { type: String, default: "uploads/" },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    aiSalesAgent: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: false },
          model: {
            type: String,
            enum: ["gpt-5", "gpt-5-mini", "gpt-5-nano", "gpt-4.1-mini"],
            default: "gpt-5-mini",
          },
          temperature: { type: Number, default: 0.3, min: 0, max: 1 },
          reasoningEffort: {
            type: String,
            enum: ["minimal", "low", "medium", "high"],
            default: "minimal",
          },
          maxRecommendations: { type: Number, default: 4, min: 1, max: 8 },
          monthlyTokenBudget: { type: Number, default: 0, min: 0 },
          agentName: { type: String, default: "Sales AI" },
          greeting: {
            type: String,
            default: "Hi! I can help you find products, compare options, add items to your cart, and check order status.",
          },
          tone: {
            type: String,
            enum: ["friendly", "professional", "playful", "luxury"],
            default: "friendly",
          },
          instructions: { type: String, default: "" },
          escalationMessage: {
            type: String,
            default:
              "I can connect you with the store team for anything that needs a human review.",
          },
          widget: {
            type: new Schema(
              {
                position: {
                  type: String,
                  enum: ["bottom-right", "bottom-left"],
                  default: "bottom-right",
                },
                // The theme's primary (lib/ai-sales-agent/settings.ts): a store
                // that never picks colours gets a chat in its own brand.
                // Mongoose fills these on every read, so a hex default here
                // would override the code default for every such store.
                primaryColor: { type: String, default: "var(--theme-primary)" },
                accentColor: { type: String, default: "var(--theme-primary)" },
                avatarUrl: String,
                footerText: { type: String, default: "Powered by AI" },
                headerTitle: { type: String, default: "" },
                width: { type: Number, default: 400, min: 320, max: 640 },
                height: { type: Number, default: 680, min: 420, max: 900 },
                showFooterText: { type: Boolean, default: true },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          capabilities: {
            type: new Schema(
              {
                productQA: { type: Boolean, default: true },
                recommendations: { type: Boolean, default: true },
                cartActions: { type: Boolean, default: true },
                checkoutHandoff: { type: Boolean, default: true },
                orderStatus: { type: Boolean, default: true },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          faq: {
            type: [
              new Schema(
                {
                  question: { type: String, default: "" },
                  answer: { type: String, default: "" },
                  tags: { type: [String], default: [] },
                },
                { _id: false },
              ),
            ],
            default: () => [],
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    aiAuthoring: {
      type: new Schema(
        {
          enabled: { type: Boolean, default: true },
          apiKey: String,
          textModel: {
            type: String,
            enum: ["", "gpt-4.1-mini", "gpt-4.1", "gpt-5-mini", "gpt-5"],
            default: "",
          },
          imageModel: {
            type: String,
            enum: ["", "gpt-image-1", "gpt-image-1-mini"],
            default: "",
          },
          surfaces: {
            type: new Schema(
              {
                products: { type: Boolean, default: true },
                categories: { type: Boolean, default: true },
                collections: { type: Boolean, default: true },
                brands: { type: Boolean, default: true },
                blogPosts: { type: Boolean, default: true },
                contentPages: { type: Boolean, default: true },
                reviews: { type: Boolean, default: true },
                heroBanner: { type: Boolean, default: true },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          imageDefaults: {
            type: new Schema(
              {
                size: {
                  type: String,
                  enum: ["auto", "1024x1024", "1024x1536", "1536x1024"],
                  default: "auto",
                },
                quality: {
                  type: String,
                  enum: ["auto", "medium", "high"],
                  default: "high",
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          brandVoice: {
            type: new Schema(
              {
                tone: {
                  type: String,
                  enum: [
                    "",
                    "friendly",
                    "professional",
                    "luxury",
                    "playful",
                    "supportive",
                  ],
                  default: "",
                },
                instructions: { type: String, default: "", maxlength: 2000 },
                imageStyle: { type: String, default: "", maxlength: 1000 },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          brandKit: {
            type: new Schema(
              {
                primaryColor: { type: String, default: "", maxlength: 9 },
                secondaryColor: { type: String, default: "", maxlength: 9 },
                logoUrl: { type: String, default: "", maxlength: 2048 },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          access: {
            type: new Schema(
              {
                staffEnabled: { type: Boolean, default: true },
                vendorsEnabled: { type: Boolean, default: true },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
          limits: {
            type: new Schema(
              {
                textPerUserPerDay: {
                  type: Number,
                  default: 0,
                  min: 0,
                  max: 100000,
                },
                imagePerUserPerDay: {
                  type: Number,
                  default: 0,
                  min: 0,
                  max: 100000,
                },
              },
              { _id: false },
            ),
            default: () => ({}),
          },
        },
        { _id: false },
      ),
      default: () => ({}),
    },

    // Storefront Header Settings
    header: {
      type: Schema.Types.Mixed,
      default: () => getDefaultHeaderSettings(),
    },

    footer: {
      type: Schema.Types.Mixed,
      default: () => getDefaultFooterSettings(),
    },

    checkout: {
      type: Schema.Types.Mixed,
      default: () => getDefaultCheckoutSettings(),
    },

    // Home Page Settings
    homePage: {
      type: Schema.Types.Mixed,
      default: () => getDefaultHomePageSettings(),
    },
    contentPages: {
      type: Schema.Types.Mixed,
      default: () => getDefaultContentPagesSettings(),
    },

    onlineStore: {
      type: Schema.Types.Mixed,
      default: () => ({}),
    },

    // Product card configurator. Absent on older documents — readers
    // normalize, so no default beyond an empty object is needed here.
    productCard: {
      type: Schema.Types.Mixed,
      default: () => ({}),
    },

    // Saved slide templates. Absent on older documents — readers normalize.
    sliderTemplates: {
      type: Schema.Types.Mixed,
      default: () => ({}),
    },

    updatedBy: String,

    // Stamped by the install wizard's finish step. Deliberately NOT in the
    // admin settings PUT allow-list, so no API can unset it and reopen the
    // wizard on a live store.
    installedAt: Date,

    // The wizard's concurrency lease — see `claimInstall` in
    // lib/install/status.ts. Also kept out of the settings PUT allow-list:
    // it is machinery, not configuration.
    installClaimedAt: Date,
  },
  {
    timestamps: true,
  },
);

// Delete cached model in development so schema changes take effect on hot reload
if (process.env.NODE_ENV !== "production" && mongoose.models.Settings) {
  mongoose.deleteModel("Settings");
}

export const Settings: Model<ISettings> =
  mongoose.models.Settings ||
  mongoose.model<ISettings>("Settings", SettingsSchema);

let hasCheckedSettingsMigration = false;

function isDuplicateKeyError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    (error as { code?: unknown }).code === 11000
  );
}

/**
 * Fetch the settings document, creating it if the store is brand new.
 *
 * One atomic `findOneAndUpdate` rather than find-then-create: the empty filter
 * matches whatever document already exists, so a second caller never inserts a
 * rival. If two callers do race an insert on a truly empty collection, the
 * unique key rejects the loser — whose retry then finds the winner's document.
 */
export async function loadSettingsDocument(): Promise<ISettings> {
  // A plain read is the whole story once the store exists — and it exists on
  // every request after the install wizard. Reading through the upsert below
  // turned every settings read into an update command bound to the primary.
  const existing = await Settings.findOne();
  if (existing) return existing;

  try {
    const result = await Settings.findOneAndUpdate(
      {},
      { $setOnInsert: { key: SETTINGS_SINGLETON_KEY } },
      {
        upsert: true,
        returnDocument: "after",
        setDefaultsOnInsert: true,
        includeResultMetadata: true,
      },
    );
    const settings = result.value as ISettings;

    // A store created from here on starts on the return policy the rest of the
    // world settled on, rather than on the one that exists only to leave older
    // installs alone.
    //
    // Written here rather than as the schema default because a schema default
    // is also applied when HYDRATING a stored document that lacks the path —
    // and every install predating `orders.returns` lacks it. As a schema
    // default this would have silently changed their refunds. `upserted` is
    // only set on a genuine insert, so only a brand new store is touched.
    if (result.lastErrorObject?.upserted && settings) {
      settings.set(
        "orders.returns.shippingRefund",
        NEW_STORE_RETURN_SHIPPING_REFUND,
      );
      await settings.save();
    }
    return settings;
  } catch (error) {
    if (!isDuplicateKeyError(error)) throw error;
    const settings = await Settings.findOne();
    if (settings) return settings;
    throw error;
  }
}

/**
 * A copy of plain data that shares no object or array with it. Anything else
 * — ObjectId, Date, the other BSON values — is kept as it is.
 */
function copyPlainData<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map((entry: unknown) => copyPlainData(entry)) as T;
  }
  if (
    value !== null &&
    typeof value === "object" &&
    Object.getPrototypeOf(value) === Object.prototype
  ) {
    const copy: Record<string, unknown> = {};
    for (const [key, entry] of Object.entries(value)) {
      copy[key] = copyPlainData(entry);
    }
    return copy as T;
  }
  return value;
}

async function loadSettings(): Promise<ISettings> {
  // What a hydrated `findOne()` returns — the same `$init`, with defaults for
  // the paths the stored document lacks — without reading it a second time.
  // From a copy: hydrating keeps a Mixed path's object as it finds it, and the
  // plain data is shared with every `getSettingsLean()` caller in the request.
  return Settings.hydrate(copyPlainData(await getSettingsLean()));
}

/**
 * Singleton settings accessor, memoized per server request.
 *
 * `getSettings()` is called many times inside a single request (payment
 * finalizers, product/vendor/payout list routes, notification fan-out, etc.)
 * for the same ~62KB singleton doc. Memoized, a request gets the *same
 * hydrated* Mongoose document every time — so the settings-mutation paths that
 * do `getSettings()` → `settings.set(...)` → `settings.save()` keep working.
 * The document is hydrated from `getSettingsLean()`'s data, so a request that
 * calls both readers — a storefront page does — reads the collection once.
 *
 * Two memos, because React's `cache()` covers only a server component render:
 * in a route handler it memoizes nothing. A route handler opts in with
 * `withRequestScope` (lib/api/request-scope.ts) — the checkout routes do.
 * Outside both (scripts, tests, background jobs) every call reads. The memo
 * lasts one request, so settings edited via the admin PUT are visible on the
 * very next request.
 */
export const getSettings: () => Promise<ISettings> = cache(() =>
  requestMemo("settings", loadSettings),
);

/** The settings document's data without Mongoose's document methods. */
export type ISettingsData = Omit<ISettings, keyof Document>;

async function loadSettingsData(): Promise<ISettingsData> {
  // Once per process, before the first read by either reader.
  if (!hasCheckedSettingsMigration) {
    hasCheckedSettingsMigration = true;
    await migrateSettings();
  }

  // The store's tax rate is the one in effect now, worked out on every read
  // so a scheduled rate starts on its date (lib/tax/tax-settings.ts).
  const data = await Settings.findOne().lean<ISettingsData | null>();
  if (data) return withEffectiveStoreRate(data, Date.now());
  // A brand-new database: let the upsert mint the singleton, then read it
  // back as plain data so this path never hands out a hydrated document.
  return withEffectiveStoreRate(
    (await loadSettingsDocument()).toObject() as ISettingsData,
    Date.now(),
  );
}

/**
 * Read-only settings, memoised per request like `getSettings()`, as a plain
 * object: no hydration into 87 sub-schemas, no document methods. For the
 * majority of callers that only read fields — a request path that must
 * `set()`/`save()` keeps using `getSettings()`. This is the request's one
 * read of the collection: `getSettings()` hydrates its document from it.
 */
export const getSettingsLean: () => Promise<ISettingsData> = cache(() =>
  requestMemo("settings:lean", loadSettingsData),
);

// ============================================
// Migration Helper (for existing data)
// ============================================

export async function migrateSettings(): Promise<void> {
  const settings = await Settings.findOne();
  if (!settings) return;

  // A store that forked before the unique key existed keeps serving whichever
  // document `findOne` happens to return, so say so loudly rather than let an
  // admin wonder why half their saves seem to vanish. Not repaired
  // automatically: only a human can tell which copy is the real one.
  const settingsCount = await Settings.estimatedDocumentCount();
  if (settingsCount > 1) {
    console.error(
      `Found ${settingsCount} settings documents; there must be exactly one. ` +
        "Saves and reads may disagree until the extras are removed.",
    );
  }

  type LegacySettingsDoc = Record<string, unknown> & {
    general?: Record<string, unknown>;
    appearance?: Record<string, unknown>;
    payment?: {
      stripe?: Record<string, unknown>;
    };
    email?: Record<string, unknown>;
    orders?: Record<string, unknown>;
    seo?: Record<string, unknown>;
    social?: Record<string, unknown>;
    maintenance?: Record<string, unknown>;
    pos?: {
      customize?: unknown;
      checkout?: unknown;
    };
  };

  // Check if migration is needed (old flat structure exists)
  const doc = settings.toObject() as unknown as LegacySettingsDoc;

  // Migration: old flat fields to new structure
  const updates: Record<string, unknown> = {};
  // Paths to remove from the document. These cannot live in `updates`: Mongoose
  // strips undefined values out of an update before it is sent, so a
  // `$set: { path: undefined }` reaches Mongo as an empty `$set` and the legacy
  // field survives. Every guard below reads the *stored* document, so a field
  // that is never actually removed makes its branch fire again on every cold
  // start — re-applying stale legacy values over whatever the admin has since
  // configured. `$unset` is what makes this migration run once.
  const unsets: Record<string, 1> = {};
  let needsMigration = false;

  // No back-fill of `key` here, deliberately: Mongoose fills a missing path
  // from its schema default on read, so the hydrated document always looks like
  // it has one and nothing could tell the difference. It does not need one —
  // the unique index treats an absent field as null and permits exactly one,
  // which is the guarantee wanted either way.

  // Migrate general fields
  if (doc.storeName && !doc.general?.storeName) {
    needsMigration = true;
    updates["general.storeName"] = doc.storeName;
    updates["general.storeEmail"] = doc.storeEmail;
    updates["general.storeDescription"] = doc.storeDescription;
    updates["general.storePhone"] = doc.storePhone;
    updates["general.storeAddress"] = doc.storeAddress;
    updates["general.logoUrl"] = doc.logoUrl;
    updates["general.faviconUrl"] = doc.faviconUrl;
    updates["general.defaultLanguage"] = doc.defaultLanguage;
    updates["general.defaultCurrency"] = doc.defaultCurrency;
    updates["general.supportedLanguages"] = doc.supportedLanguages;
    // Straight to its modern home. Parking it on the deprecated
    // `general.multiVendorEnabled` meant the value only reached
    // `multiVendorMode.enabled` on the *next* boot, via the branch below.
    if (doc.multiVendorEnabled !== undefined) {
      updates["multiVendorMode.enabled"] = Boolean(doc.multiVendorEnabled);
    }
  }

  // Older installs stamped a bundled placeholder ("/favicon.svg", "/favicon.ico")
  // into the favicon field. Those files no longer ship, so a stored placeholder
  // is a dead path — clear it and let the store simply have no favicon until an
  // admin uploads one.
  const generalFaviconUrl =
    typeof doc.general?.faviconUrl === "string"
      ? doc.general.faviconUrl.trim()
      : "";
  if (generalFaviconUrl && !resolveFaviconUrl(generalFaviconUrl)) {
    needsMigration = true;
    updates["general.faviconUrl"] = "";
  }

  // The seeder wrote this app's own name into two fields that outrank
  // `general.storeName`: `seo.metaTitle`, which becomes the browser tab title,
  // the `og:title` and the search-result headline for every page that does not
  // set its own, and `email.fromName`, which signs every outbound email. A store
  // renamed in Settings → General kept showing the demo brand in all of them.
  // Cleared rather than only ignored on read, so the SEO and Email tabs show the
  // empty fields the storefront actually behaves as having.
  if (isLegacySeededBrandText(doc.seo?.metaTitle as string | undefined)) {
    needsMigration = true;
    updates["seo.metaTitle"] = "";
  }
  if (isLegacySeededBrandText(doc.email?.fromName as string | undefined)) {
    needsMigration = true;
    updates["email.fromName"] = "";
  }

  // Migrate appearance fields
  if (doc.primaryColor && !doc.appearance?.primaryColor) {
    needsMigration = true;
    updates["appearance.primaryColor"] = doc.primaryColor;
    updates["appearance.secondaryColor"] = doc.secondaryColor;
    updates["appearance.accentColor"] = doc.accentColor;
    updates["appearance.theme"] = normalizeThemeMode(doc.theme);
  }

  // Retire the legacy "system" theme. The app no longer follows the OS
  // preference, so an existing store configured as "system" becomes light —
  // rewritten here (rather than only normalized on read) so the admin
  // Appearance tab shows the mode the storefront actually renders.
  const configuredTheme =
    updates["appearance.theme"] ?? doc.appearance?.theme;
  if (configuredTheme === "system") {
    needsMigration = true;
    updates["appearance.theme"] = DEFAULT_THEME_MODE;
  }

  // Migrate payment fields
  if (doc.stripeEnabled !== undefined && !doc.payment?.stripe?.enabled) {
    needsMigration = true;
    updates["payment.stripe.enabled"] = doc.stripeEnabled;
    updates["payment.stripe.publishableKey"] = doc.stripePublishableKey;
    updates["payment.stripe.secretKey"] = doc.stripeSecretKey;
    updates["payment.stripe.webhookSecret"] = doc.stripeWebhookSecret;
    updates["payment.cod.enabled"] = doc.codEnabled;
    updates["payment.cod.instructions"] = doc.codInstructions;
  }

  // Migrate email fields
  if (doc.smtpEnabled !== undefined && !doc.email?.enabled) {
    needsMigration = true;
    updates["email.enabled"] = doc.smtpEnabled;
    updates["email.smtp.host"] = doc.smtpHost;
    updates["email.smtp.port"] = doc.smtpPort;
    updates["email.smtp.user"] = doc.smtpUser;
    updates["email.smtp.password"] = doc.smtpPassword;
    updates["email.smtp.secure"] = doc.smtpSecure;
    updates["email.fromEmail"] = doc.smtpFromEmail;
    updates["email.fromName"] = doc.smtpFromName;
  }

  // Migrate order fields
  if (doc.orderPrefix && !doc.orders?.prefix) {
    needsMigration = true;
    updates["orders.prefix"] = doc.orderPrefix;
    updates["orders.taxRate"] = doc.taxRate;
    updates["orders.freeShippingThreshold"] = doc.freeShippingThreshold;
    updates["orders.defaultShippingCost"] = doc.defaultShippingCost;
    updates["orders.commission.vendorRate"] = doc.vendorCommissionRate;
    updates["orders.commission.minWithdrawalAmount"] = doc.minWithdrawalAmount;
  }

  // Migrate SEO fields
  if (doc.metaTitle && !doc.seo?.metaTitle) {
    needsMigration = true;
    updates["seo.metaTitle"] = doc.metaTitle;
    updates["seo.metaDescription"] = doc.metaDescription;
    updates["seo.metaKeywords"] = doc.metaKeywords;
  }

  // Migrate social fields
  if (doc.facebookUrl && !doc.social?.facebookUrl) {
    needsMigration = true;
    updates["social.facebookUrl"] = doc.facebookUrl;
    updates["social.twitterUrl"] = doc.twitterUrl;
    updates["social.instagramUrl"] = doc.instagramUrl;
    updates["social.youtubeUrl"] = doc.youtubeUrl;
  }

  // Migrate maintenance fields
  if (doc.maintenanceMode !== undefined && !doc.maintenance?.enabled) {
    needsMigration = true;
    updates["maintenance.enabled"] = doc.maintenanceMode;
    updates["maintenance.message"] = doc.maintenanceMessage;
  }

  // Initialize POS nested structure defaults if missing
  if (doc.pos) {
    if (!doc.pos.customize) {
      needsMigration = true;
      updates["pos.customize.printedReceiptsEnabled"] = false;
    }
    if (!doc.pos.checkout) {
      needsMigration = true;
      updates["pos.checkout.paymentMethods"] = ["cash", "card"];
    }
  }

  // Migrate multi-vendor fields
  if (doc.general?.multiVendorEnabled !== undefined) {
    needsMigration = true;
    updates["multiVendorMode.enabled"] = Boolean(doc.general.multiVendorEnabled);
    unsets["general.multiVendorEnabled"] = 1;
  }
  if (doc.vendorPermissions) {
    const vp = doc.vendorPermissions as Record<string, unknown>;
    needsMigration = true;
    updates["multiVendorMode.canManageProducts"] = Boolean(vp.canManageProducts);
    updates["multiVendorMode.canViewOrders"] = Boolean(vp.canViewOrders);
    updates["multiVendorMode.canManageOrders"] = Boolean(vp.canManageOrders);
    updates["multiVendorMode.canManageStoreSettings"] = Boolean(
      vp.canManageStoreSettings,
    );
    updates["multiVendorMode.canViewAnalytics"] = Boolean(vp.canViewAnalytics);
    updates["multiVendorMode.canManageDiscounts"] = Boolean(
      vp.canManageDiscounts ?? vp.canManageProducts,
    );
    updates["multiVendorMode.canManagePayouts"] = Boolean(vp.canManagePayouts);
    updates["multiVendorMode.canAccessPOS"] = Boolean(vp.canAccessPOS);
    unsets["vendorPermissions"] = 1;
  }

  if (needsMigration) {
    // Mongo refuses an update that both sets and unsets the same path, and the
    // removals are what the guards above key on — so a removal always wins.
    for (const path of Object.keys(unsets)) delete updates[path];

    const operation: Record<string, unknown> = {};
    if (Object.keys(updates).length > 0) operation.$set = updates;
    if (Object.keys(unsets).length > 0) operation.$unset = unsets;

    if (Object.keys(operation).length > 0) {
      await Settings.updateOne({ _id: settings._id }, operation);
      console.log("Settings migration completed successfully");
    }
  }
}
