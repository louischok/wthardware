"use client";

import Link from "next/link";
import { useForm } from "react-hook-form";
import { useTranslations } from "next-intl";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Suspense, useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { Mail, Lock, Loader2, Shield } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  signIn,
  signInWithGoogle,
  signInWithFacebook,
  authClient,
  getSession,
} from "@/lib/auth-client";
import { Separator } from "@/components/ui/separator";
import { LoginSchema, type LoginInput } from "@/lib/validations";
import { sanitizeReturnPath } from "@/lib/return-path";
import { useRouter, useParams, useSearchParams } from "next/navigation";
import { GoogleIcon, FacebookIcon } from "@/components/auth/oauth-icons";

interface LoginPageProps {
  /** Resolved on the server so the buttons render in the initial HTML. */
  oauthEnabled: { google: boolean; facebook: boolean };
  demoModeEnabled: boolean;
}


function LoginContent({ oauthEnabled }: LoginPageProps) {
  const t = useTranslations();
  const router = useRouter();
  const params = useParams();
  const locale = params.locale as string;
  const searchParams = useSearchParams();

  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [isFacebookLoading, setIsFacebookLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dismissedSearchErrorKey, setDismissedSearchErrorKey] = useState<
    string | null
  >(null);

  // 2FA state
  const [requires2FA, setRequires2FA] = useState(false);
  const [is2FALoading, setIs2FALoading] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState("");
  // Trusting the device skips the second factor here for 30 days, so it is the
  // user's call — on a shared or public machine it must stay off.
  const [trustDevice, setTrustDevice] = useState(false);

  const formatRoleLabel = (role: string) => {
    const value = role.trim();
    if (!value) return "";
    return value.charAt(0).toUpperCase() + value.slice(1);
  };

  const searchErrorCode = searchParams.get("error");
  const searchErrorRole = searchParams.get("role") || "";
  const searchErrorEmail = searchParams.get("email") || "";
  const searchErrorKey = searchErrorCode
    ? `${searchErrorCode}:${searchErrorRole}:${searchErrorEmail}`
    : null;
  let searchErrorMessage: string | null = null;

  if (searchErrorCode === "oauth_account_role_conflict") {
    const role = formatRoleLabel(searchErrorRole);
    searchErrorMessage = t("auth.oauthRoleConflict", {
      email:
        searchErrorEmail ||
        t("auth.thisEmail"),
      role: role || t("auth.vendorRole"),
    });
  } else if (
    searchErrorCode === "oauth_customer_only" ||
    searchErrorCode === "OAUTH_SIGNIN_IS_ONLY_AVAILABLE_FOR_CUSTOMERS"
  ) {
    searchErrorMessage = t("auth.oauthCustomerOnly");
  }

  const visibleError =
    error ||
    (searchErrorKey !== dismissedSearchErrorKey ? searchErrorMessage : null);

  const dismissSearchError = () => {
    if (searchErrorKey) {
      setDismissedSearchErrorKey(searchErrorKey);
    }
  };

  const form = useForm<LoginInput>({
    resolver: zodResolver(LoginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const resolveRoleAfterLogin = async (userRole?: string) => {
    if (userRole) return userRole;

    const sessionResult = await getSession();
    const sessionUser = sessionResult.data?.user as
      | { role?: string; roles?: string[] }
      | undefined;

    if (sessionUser?.role) return sessionUser.role;
    if (sessionUser?.roles?.includes("admin")) return "admin";
    if (sessionUser?.roles?.includes("vendor")) return "vendor";
    if (sessionUser?.roles?.includes("staff")) return "staff";
    if (sessionUser?.roles?.includes("seller")) return "seller";

    return undefined;
  };

  /**
   * `redirect` is this page's own convention, but most of the app links here
   * with `?callbackUrl=` (account pages, wishlist, become-vendor, chat). Both
   * are accepted so those return-to targets aren't silently dropped.
   * Sanitized to same-origin paths so a crafted link can't bounce a fresh
   * login to an external site.
   */
  const getRedirectParam = () =>
    sanitizeReturnPath(
      searchParams.get("redirect") || searchParams.get("callbackUrl"),
    );

  const redirectAfterLogin = async (userRole?: string) => {
    // A deep return target (checkout, wishlist, inbox) wins over the role
    // dashboards. Home callbacks never reach here — sanitizeReturnPath drops
    // them so every role lands on its dashboard when there's nothing to
    // return to.
    const redirectParam = getRedirectParam();
    if (redirectParam) {
      router.push(redirectParam);
      router.refresh();
      return;
    }

    const resolvedRole = await resolveRoleAfterLogin(userRole);

    // Default role-based redirects
    let redirectPath = `/${locale}/account`;
    if (resolvedRole === "admin") {
      redirectPath = `/${locale}/admin/dashboard`;
    } else if (resolvedRole === "vendor") {
      redirectPath = `/${locale}/vendor/dashboard`;
    } else if (resolvedRole === "staff" || resolvedRole === "seller") {
      redirectPath = `/${locale}/staff/dashboard`;
    }
    router.push(redirectPath);
    router.refresh();
  };

  const onSubmit = async (data: LoginInput) => {
    setIsLoading(true);
    setError(null);
    dismissSearchError();

    try {
      const result = await signIn.email({
        email: data.email,
        password: data.password,
      });

      if (result.error) {
        if (result.error.code === "EMAIL_NOT_VERIFIED") {
          router.push(
            `/${locale}/verify-email?email=${encodeURIComponent(data.email)}`,
          );
          return;
        }
        setError(result.error.message || t("errors.unauthorized"));
        return;
      }

      const signInData = result.data as unknown as {
        user?: { id?: string; email?: string; role?: string };
        twoFactorRedirect?: boolean;
      };
      if (signInData?.twoFactorRedirect) {
        setRequires2FA(true);
        return;
      }

      await redirectAfterLogin(signInData?.user?.role);
    } catch {
      setError(t("common.error"));
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    setError(null);
    dismissSearchError();
    try {
      const redirectParam = getRedirectParam();
      const callbackURL = `/${locale}/role-redirect${
        redirectParam ? `?redirect=${encodeURIComponent(redirectParam)}` : ""
      }`;
      await signInWithGoogle({
        callbackURL,
        newUserCallbackURL: callbackURL,
        errorCallbackURL: `/${locale}/login`,
      });
      // OAuth redirects automatically
    } catch {
      setError("Failed to sign in with Google");
      setIsGoogleLoading(false);
    }
  };

  const handleFacebookSignIn = async () => {
    setIsFacebookLoading(true);
    setError(null);
    dismissSearchError();
    try {
      const redirectParam = getRedirectParam();
      const callbackURL = `/${locale}/role-redirect${
        redirectParam ? `?redirect=${encodeURIComponent(redirectParam)}` : ""
      }`;
      await signInWithFacebook({
        callbackURL,
        newUserCallbackURL: callbackURL,
        errorCallbackURL: `/${locale}/login`,
      });
      // OAuth redirects automatically
    } catch {
      setError("Failed to sign in with Facebook");
      setIsFacebookLoading(false);
    }
  };

  const handle2FAVerify = async () => {
    if (twoFactorCode.length !== 6) return;

    setIs2FALoading(true);
    setError(null);

    try {
      const verifyResult = await authClient.twoFactor.verifyTotp({
        code: twoFactorCode,
        trustDevice,
      });
      if (verifyResult.error) {
        setError(verifyResult.error.message || "Invalid 2FA code");
        return;
      }

      const session = await getSession();
      const userRole = (
        session.data?.user as { role?: string } | undefined
      )?.role;
      await redirectAfterLogin(userRole);
    } catch {
      setError("An error occurred. Please try again.");
    } finally {
      setIs2FALoading(false);
    }
  };

  // 2FA Verification Screen
  if (requires2FA) {
    return (
      <Card className="shadow-lg">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-2">
            <Shield className="h-12 w-12 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold">
            {t("auth.twoFactorTitle")}
          </CardTitle>
          <CardDescription>
            {t("auth.twoFactorDescription")}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="p-3 text-sm text-destructive bg-destructive/10 rounded-md">
              {error}
            </div>
          )}
          <div className="space-y-2">
            <Input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={6}
              value={twoFactorCode}
              onChange={(e) =>
                setTwoFactorCode(e.target.value.replace(/\D/g, ""))
              }
              placeholder="000000"
              className="text-center text-2xl tracking-widest font-mono"
              disabled={is2FALoading}
            />
          </div>
          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            <input
              type="checkbox"
              className="size-4 rounded border-input accent-primary"
              checked={trustDevice}
              onChange={(event) => setTrustDevice(event.target.checked)}
              disabled={is2FALoading}
            />
            {t("auth.trustThisDevice")}
          </label>
          <Button
            className="w-full"
            onClick={handle2FAVerify}
            disabled={is2FALoading || twoFactorCode.length !== 6}
          >
            {is2FALoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {t("common.loading")}
              </>
            ) : (
              t("auth.verify")
            )}
          </Button>
        </CardContent>
        <CardFooter>
          <Button
            variant="link"
            className="w-full"
            onClick={() => {
              setRequires2FA(false);
              setTwoFactorCode("");
              setError(null);
            }}
          >
            {t("auth.backToLogin")}
          </Button>
        </CardFooter>
      </Card>
    );
  }

  return (
      <Card className="shadow-lg">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-2xl font-bold">
            {t("auth.welcomeBack")}
          </CardTitle>
          <CardDescription>{t("auth.signIn")}</CardDescription>
        </CardHeader>
        <CardContent>
          {/* OAuth Buttons */}
          {(oauthEnabled.google || oauthEnabled.facebook) && (
            <>
              <div className="space-y-2">
                {oauthEnabled.google && (
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full gap-2"
                    onClick={handleGoogleSignIn}
                    disabled={isGoogleLoading || isFacebookLoading || isLoading}
                  >
                    {isGoogleLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <GoogleIcon className="h-4 w-4" />
                    )}
                    {t("auth.continueWithGoogle")}
                  </Button>
                )}
                {oauthEnabled.facebook && (
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full gap-2"
                    onClick={handleFacebookSignIn}
                    disabled={isGoogleLoading || isFacebookLoading || isLoading}
                  >
                    {isFacebookLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <FacebookIcon className="h-4 w-4" />
                    )}
                    {t("auth.continueWithFacebook")}
                  </Button>
                )}
              </div>
              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <Separator />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">
                    {t("auth.orContinueWith")}
                  </span>
                </div>
              </div>
            </>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {visibleError && (
                <div className="p-3 text-sm text-destructive bg-destructive/10 rounded-md">
                  {visibleError}
                </div>
              )}

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("auth.email")}</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          {...field}
                          type="email"
                          placeholder="name@example.com"
                          className="pl-10"
                          disabled={isLoading}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("auth.password")}</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          {...field}
                          type="password"
                          placeholder="••••••••"
                          className="pl-10"
                          disabled={isLoading}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex items-center justify-end">
                <Link
                  href={`/${locale}/forgot-password`}
                  className="text-sm text-primary hover:underline"
                >
                  {t("auth.forgotPassword")}
                </Link>
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {t("common.loading")}
                  </>
                ) : (
                  t("auth.signIn")
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex flex-col gap-4">
          <div className="relative w-full">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">
                {t("auth.noAccount")}
              </span>
            </div>
          </div>
          <Button variant="outline" className="w-full" asChild>
            {/* Keep the return-to target across the switch to sign-up, so a
                guest who registers instead still lands where they meant to. */}
            <Link
              href={`/${locale}/register${
                getRedirectParam()
                  ? `?redirect=${encodeURIComponent(getRedirectParam()!)}`
                  : ""
              }`}
            >
              {t("auth.createAccount")}
            </Link>
          </Button>
        </CardFooter>
      </Card>
  );
}

function LoginFallback() {
  return (
    <Card className="shadow-lg">
      <CardContent className="flex flex-col items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground mb-4" />
        <p className="text-muted-foreground">Loading...</p>
      </CardContent>
    </Card>
  );
}

export function LoginPageClient(props: LoginPageProps) {
  return (
    <Suspense fallback={<LoginFallback />}>
      <LoginContent {...props} />
    </Suspense>
  );
}
