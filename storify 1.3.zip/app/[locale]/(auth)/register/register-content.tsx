"use client";

import { Suspense, useState } from "react";
import Link from "next/link";
import { useRouter, useParams, useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Mail, Lock, User, Loader2, Store } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { signUp, signInWithGoogle, signInWithFacebook } from "@/lib/auth-client";
import { RegisterSchema, type RegisterInput } from "@/lib/validations";
import { sanitizeReturnPath } from "@/lib/return-path";
import { useMultiVendorMode } from "@/providers/app-settings-provider";
import { GoogleIcon, FacebookIcon } from "@/components/auth/oauth-icons";

interface RegisterPageProps {
  /** Resolved on the server so the buttons render in the initial HTML. */
  oauthEnabled: { google: boolean; facebook: boolean };
  emailVerificationRequired: boolean;
}

function RegisterContent({
  oauthEnabled,
  emailVerificationRequired,
}: RegisterPageProps) {
  const t = useTranslations();
  const router = useRouter();
  const params = useParams();
  const locale = params.locale as string;
  const searchParams = useSearchParams();
  // Return-to target handed over from the login page (or a guarded page), so
  // a guest who registers instead of signing in still lands where they meant
  // to go. Same-origin paths only.
  const redirectParam = sanitizeReturnPath(
    searchParams.get("redirect") || searchParams.get("callbackUrl"),
  );
  const { isMultiVendor } = useMultiVendorMode();

  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [isFacebookLoading, setIsFacebookLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const form = useForm<RegisterInput>({
    resolver: zodResolver(RegisterSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
    },
  });

  const onSubmit = async (data: RegisterInput) => {
    setIsLoading(true);
    setError(null);

    try {
      const result = await signUp.email({
        name: data.name,
        email: data.email,
        password: data.password,
        callbackURL: `/${locale}/email-verified`,
      });

      if (result.error) {
        setError(result.error.message || t("common.error"));
        return;
      }

      const signUpData = result.data as unknown as {
        token?: string | null;
        user?: { id?: string };
      };
      // Server-rendered flag, with the sign-up response as a cross-check —
      // better-auth returns a null token when it deferred the session until
      // the email is verified.
      const verificationRequired =
        emailVerificationRequired || signUpData?.token === null;

      router.push(
        verificationRequired
          ? `/${locale}/verify-email?email=${encodeURIComponent(data.email)}`
          : (redirectParam ?? `/${locale}/role-redirect`),
      );
    } catch {
      setError(t("common.error"));
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    setError(null);
    try {
      const callbackURL = `/${locale}/role-redirect${
        redirectParam ? `?redirect=${encodeURIComponent(redirectParam)}` : ""
      }`;
      await signInWithGoogle({
        callbackURL,
        newUserCallbackURL: callbackURL,
        errorCallbackURL: `/${locale}/login`,
      });
      // OAuth redirects automatically
    } catch {
      setError("Failed to sign in with Google");
      setIsGoogleLoading(false);
    }
  };

  const handleFacebookSignIn = async () => {
    setIsFacebookLoading(true);
    setError(null);
    try {
      const callbackURL = `/${locale}/role-redirect${
        redirectParam ? `?redirect=${encodeURIComponent(redirectParam)}` : ""
      }`;
      await signInWithFacebook({
        callbackURL,
        newUserCallbackURL: callbackURL,
        errorCallbackURL: `/${locale}/login`,
      });
      // OAuth redirects automatically
    } catch {
      setError("Failed to sign in with Facebook");
      setIsFacebookLoading(false);
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader className="space-y-1 text-center">
        <CardTitle className="text-2xl font-bold">
          {t("auth.createAccount")}
        </CardTitle>
        <CardDescription>
          {t("auth.createAccountDescription")}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* OAuth Buttons */}
        {(oauthEnabled.google || oauthEnabled.facebook) && (
          <>
            {oauthEnabled.google && (
              <Button
                type="button"
                variant="outline"
                className="w-full gap-2"
                onClick={handleGoogleSignIn}
                disabled={isGoogleLoading || isLoading || isFacebookLoading}
              >
                {isGoogleLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <GoogleIcon className="h-4 w-4" />
                )}
                {t("auth.continueWithGoogle")}
              </Button>
            )}
            {oauthEnabled.facebook && (
              <Button
                type="button"
                variant="outline"
                className="w-full gap-2 mt-2"
                onClick={handleFacebookSignIn}
                disabled={isFacebookLoading || isLoading || isGoogleLoading}
              >
                {isFacebookLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <FacebookIcon className="h-4 w-4" />
                )}
                {t("auth.continueWithFacebook")}
              </Button>
            )}
            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <Separator />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">
                  {t("auth.orContinueWith")}
                </span>
              </div>
            </div>
          </>
        )}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {error && (
              <div className="p-3 text-sm text-destructive bg-destructive/10 rounded-md">
                {error}
              </div>
            )}

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("auth.fullName")}</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        {...field}
                        placeholder="John Doe"
                        className="pl-10"
                        disabled={isLoading}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("auth.email")}</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        {...field}
                        type="email"
                        placeholder="name@example.com"
                        className="pl-10"
                        disabled={isLoading}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("auth.password")}</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        {...field}
                        type="password"
                        placeholder="••••••••"
                        className="pl-10"
                        disabled={isLoading}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t("common.loading")}
                </>
              ) : (
                t("auth.signUp")
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex flex-col gap-4">
        <p className="text-center text-sm text-muted-foreground">
          {t("auth.termsAgreement")}{" "}
          <Link
            href={`/${locale}/terms`}
            className="text-primary hover:underline"
          >
            {t("auth.termsOfService")}
          </Link>{" "}
          {t("auth.and")}{" "}
          <Link
            href={`/${locale}/privacy`}
            className="text-primary hover:underline"
          >
            {t("auth.privacyPolicy")}
          </Link>
        </p>

        {/* Want to sell? Link - now uses dynamic setting */}
        {isMultiVendor && (
          <div className="flex items-center justify-center gap-2 py-2 px-4 rounded-lg bg-primary/5 border border-primary/10">
            <Store className="h-4 w-4 text-primary" />
            <span className="text-sm text-muted-foreground">
              {t("auth.wantToSell")}{" "}
              <Link
                href={`/${locale}/become-vendor`}
                className="text-primary font-medium hover:underline"
              >
                {t("auth.becomeVendor")}
              </Link>
            </span>
          </div>
        )}

        <div className="relative w-full">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-card px-2 text-muted-foreground">
              {t("auth.hasAccount")}
            </span>
          </div>
        </div>
        <Button variant="outline" className="w-full" asChild>
          <Link
            href={`/${locale}/login${
              redirectParam
                ? `?redirect=${encodeURIComponent(redirectParam)}`
                : ""
            }`}
          >
            {t("auth.signIn")}
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}

function RegisterFallback() {
  return (
    <Card className="shadow-lg">
      <CardContent className="flex flex-col items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground mb-4" />
        <p className="text-muted-foreground">Loading...</p>
      </CardContent>
    </Card>
  );
}

export function RegisterPageClient(props: RegisterPageProps) {
  return (
    <Suspense fallback={<RegisterFallback />}>
      <RegisterContent {...props} />
    </Suspense>
  );
}
