import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";

// Route-level fallback shown instantly on navigation while the server resolves
// the brand list. Mirrors brands/page.tsx (header + separator + card grid).
export default function BrandsLoading() {
  return (
    <div className="container mx-auto px-4 py-8 lg:py-12" aria-busy="true">
      <p className="sr-only" aria-live="polite">
        Loading brands...
      </p>

      <div className="mb-8 space-y-3">
        <Skeleton className="h-9 w-40" />
        <Skeleton className="h-5 w-96 max-w-full" />
      </div>

      <Separator className="mb-8" />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4 xl:grid-cols-5">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="overflow-hidden rounded-md border bg-background">
            <Skeleton className="aspect-4/3 w-full rounded-none" />
            <div className="p-3">
              <Skeleton className="h-4 w-3/4" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
