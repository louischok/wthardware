import { setRequestLocale } from "next-intl/server";
import { notFound } from "next/navigation";
import { ContentPageView } from "@/components/store/content-page-view";
import { getStorefrontSettings } from "@/lib/storefront-settings";

interface PageProps {
  params: Promise<{ locale: string }>;
}

export default async function PrivacyPage({ params }: PageProps) {
  const { locale } = await params;
  setRequestLocale(locale);

  const { contentPages } = await getStorefrontSettings();
  if (!contentPages.privacy.visible) {
    notFound();
  }

  return (
    <ContentPageView
      title={contentPages.privacy.title}
      content={contentPages.privacy.content}
    />
  );
}
