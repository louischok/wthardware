import { setRequestLocale } from "next-intl/server";
import { MenuForm } from "@/components/admin/menus/menu-form";
import { requireAdminPageAccess } from "@/lib/admin-page-guard";

interface PageProps {
  params: Promise<{ locale: string; id: string }>;
}

export default async function EditMenuPage({ params }: PageProps) {
  const { locale, id } = await params;
  setRequestLocale(locale);
  await requireAdminPageAccess(locale);
  return (
    <div className="mx-auto w-full max-w-6xl">
      <MenuForm menuId={id} />
    </div>
  );
}
