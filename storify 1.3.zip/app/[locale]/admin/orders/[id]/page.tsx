import { Suspense } from "react";
import { notFound } from "next/navigation";
import { setRequestLocale } from "next-intl/server";
import { STAFF_PERMISSIONS } from "@/config/permissions.config";
import { requireAdminOrStaffPageAccess } from "@/lib/staff-page-guard";
import { getOrderDetails, getOrderReturnRequests } from "@/lib/order-details";
import { OrderItems } from "@/components/admin/order-details/order-items";
import { OrderHeader } from "@/components/admin/order-details/order-header";
import { OrderCustomer } from "@/components/admin/order-details/order-customer";
import { OrderTimeline } from "@/components/admin/order-details/order-timeline";
import { OrderTimelineSkeleton } from "@/components/admin/order-details/order-details-skeleton";

interface PageProps {
  params: Promise<{ locale: string; id: string }>;
}

export default async function OrderDetailsPage({ params }: PageProps) {
  const { locale, id } = await params;
  setRequestLocale(locale);

  const access = await requireAdminOrStaffPageAccess({
    locale,
    required: [STAFF_PERMISSIONS.VIEW_ORDERS],
  });
  const canEditOrder =
    !access?.staffPermissions ||
    access.staffPermissions.includes(STAFF_PERMISSIONS.EDIT_ORDERS) ||
    access.staffPermissions.includes(STAFF_PERMISSIONS.MANAGE_ORDERS);
  const canRefund = !access?.staffPermissions;

  // The header needs both, and neither depends on the other — issued together
  // they cost one round-trip instead of two.
  const [order, returnRequests] = await Promise.all([
    getOrderDetails(id),
    getOrderReturnRequests(id),
  ]);

  if (!order) {
    notFound();
  }

  return (
    <div className="space-y-6">
      <OrderHeader
        // Remount per order so the header's return-request state cannot carry
        // over from the previously viewed order.
        key={String(order._id)}
        order={order}
        locale={locale}
        readOnly={!canEditOrder}
        canRefund={canRefund}
        returnRequests={returnRequests}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <OrderItems order={order} />
          {/* Streamed separately: the order itself never waits on the audit trail. */}
          <Suspense fallback={<OrderTimelineSkeleton />}>
            <OrderTimeline orderId={String(order._id)} />
          </Suspense>
        </div>

        <div className="lg:col-span-1">
          <OrderCustomer order={order} />
        </div>
      </div>
    </div>
  );
}
