import { setRequestLocale, getTranslations } from "next-intl/server";
import { connectDB } from "@/lib/db";
import { getSettings } from "@/models/settings.model";
import { redirect } from "next/navigation";
import { requireAdminOrStaffPageAccess } from "@/lib/staff-page-guard";
import { STAFF_PERMISSIONS } from "@/config/permissions.config";
import { canAccessPOS } from "@/lib/rbac";

interface PageProps {
  params: Promise<{ locale: string }>;
}

export default async function AdminPosStaffPage({ params }: PageProps) {
  const { locale } = await params;
  setRequestLocale(locale);

  const t = await getTranslations({ locale });

  const { session } = await requireAdminOrStaffPageAccess({
    locale,
    required: [STAFF_PERMISSIONS.MANAGE_POS],
  });

  await connectDB();
  const settings = await getSettings();
  if (!settings.pos?.enabled) {
    redirect(`/${locale}/admin`);
  }
  if (!(await canAccessPOS(session.user))) {
    redirect(`/${locale}/admin`);
  }

  return (
    <div className="space-y-2">
      <h1 className="text-3xl font-bold">{t("admin.posStaff")}</h1>
      <p className="text-muted-foreground">{t("admin.pos")}</p>
    </div>
  );
}
