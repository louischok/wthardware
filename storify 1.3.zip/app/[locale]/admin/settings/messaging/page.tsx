"use client";

import { useTranslations } from "next-intl";
import { ChannelConnectionsPanel } from "@/components/chat/channel-connections-panel";
import { PlatformLiveChatSettingsPanel } from "@/components/chat/platform-live-chat-settings-panel";
import { SettingsTabHeader } from "@/components/admin/settings/sections/settings-tab-header";

/**
 * Omnichannel configuration, alongside every other store setting.
 *
 * This section deliberately does NOT go through `SectionLoader` /
 * `saveSection` like the others: channel connections are their own collection
 * (each row holding an encrypted provider credential) and live-chat hours are
 * their own singleton, so both panels own their loading and saving. Folding
 * them into the shared settings document would mean putting access tokens in
 * the same payload the settings API returns to the browser.
 */
export default function Page() {
  const t = useTranslations();

  const tSafe = (key: string, fallback: string) => {
    try {
      const translate = t as unknown as (k: string) => string;
      const res = translate(key);
      return typeof res === "string" && res !== key ? res : fallback;
    } catch {
      return fallback;
    }
  };

  return (
    <div className="space-y-4">
      <SettingsTabHeader
        title={tSafe("admin.settings.messaging.title", "Omnichannel Messaging")}
        description={tSafe(
          "admin.settings.messaging.description",
          "Live chat hours, escalation, and the WhatsApp, Messenger, Instagram and Telegram accounts the marketplace replies from",
        )}
      />
      <PlatformLiveChatSettingsPanel />
      <ChannelConnectionsPanel canManage />
    </div>
  );
}
