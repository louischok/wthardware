import { Suspense } from "react";
import { notFound } from "next/navigation";
import { setRequestLocale } from "next-intl/server";
import { OrderHeader } from "@/components/admin/order-details/order-header";
import { OrderItems } from "@/components/admin/order-details/order-items";
import { OrderCustomer } from "@/components/admin/order-details/order-customer";
import { OrderTimeline } from "@/components/admin/order-details/order-timeline";
import { OrderTimelineSkeleton } from "@/components/admin/order-details/order-details-skeleton";
import { getOrderDetails, getOrderReturnRequests } from "@/lib/order-details";
import { requireStaffAreaAccess } from "@/lib/staff-area-guard";
import { STAFF_PERMISSIONS } from "@/config/permissions.config";

interface PageProps {
  params: Promise<{ locale: string; id: string }>;
}

export default async function StaffOrderDetailsPage({ params }: PageProps) {
  const { locale, id } = await params;
  setRequestLocale(locale);

  const access = await requireStaffAreaAccess({
    locale,
    required: [STAFF_PERMISSIONS.VIEW_ORDERS],
  });
  const readOnly = !(
    access.staffPermissions.includes(STAFF_PERMISSIONS.MANAGE_ORDERS) ||
    access.staffPermissions.includes(STAFF_PERMISSIONS.EDIT_ORDERS) ||
    access.staffPermissions.includes(STAFF_PERMISSIONS.DELETE_ORDERS)
  );

  const [order, returnRequests] = await Promise.all([
    getOrderDetails(id),
    getOrderReturnRequests(id),
  ]);

  if (!order) notFound();

  return (
    <div className="space-y-6">
      <OrderHeader
        key={String(order._id)}
        order={order}
        locale={locale}
        readOnly={readOnly}
        returnRequests={returnRequests}
      />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <OrderItems order={order} />
          <Suspense fallback={<OrderTimelineSkeleton />}>
            <OrderTimeline orderId={String(order._id)} />
          </Suspense>
        </div>
        <div className="lg:col-span-1">
          <OrderCustomer order={order} />
        </div>
      </div>
    </div>
  );
}
