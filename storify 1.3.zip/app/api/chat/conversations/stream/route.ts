import { Types } from "mongoose";
import { withApi } from "@/lib/api/handler";
import {
  listConversations,
  requireConversationViewer,
  serializeConversationMessage,
} from "@/lib/conversations/service";
import { resolveConversationViewer } from "@/lib/conversations/viewer";
import { ConversationMessage } from "@/models";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 300;

const encoder = new TextEncoder();

/**
 * How far back the first poll of a connection replays delivery-status changes.
 * Wide enough to cover an EventSource reconnect (the 2.5s retry, plus the
 * `maxDuration` recycle), narrow enough that a fresh connection does not
 * replay hundreds of frames.
 */
const RECONNECT_REPLAY_MS = 30_000;

/**
 * Overlap re-scanned on each status poll, on top of the newest `updatedAt`
 * already seen. It absorbs the skew between this process's clock and Mongo's,
 * and a write that lands with a timestamp fractionally behind one already
 * observed. Anything it re-reads is discarded by the message-state map, so the
 * only cost of the margin is a handful of documents.
 */
const STATUS_WATERMARK_OVERLAP_MS = 5_000;

/** Delivery-status rows read per poll. */
const STATUS_POLL_LIMIT = 500;

function eventFrame(event: string, data: unknown, id?: string) {
  const lines = [
    ...(id ? [`id: ${id}`] : []),
    `event: ${event}`,
    `data: ${JSON.stringify(data)}`,
    "",
    "",
  ];
  return encoder.encode(lines.join("\n"));
}

function commentFrame(value: string) {
  return encoder.encode(`: ${value}\n\n`);
}

export const GET = withApi(
  { auth: "user" },
  async ({ request, session }) => {
    const viewer = requireConversationViewer(
      await resolveConversationViewer({ session }),
    );
    const requestedCursor = request.headers.get("last-event-id");
    // Replays a small overlap on a brand-new stream. Clients de-duplicate by
    // message ID, while the overlap closes the race between their initial REST
    // fetch and EventSource becoming ready.
    const initialCursor = Types.ObjectId.createFromTime(
      Math.max(0, Math.floor(Date.now() / 1000) - 5),
    );

    let closed = false;
    let pollTimer: ReturnType<typeof setInterval> | undefined;
    let heartbeatTimer: ReturnType<typeof setInterval> | undefined;
    const close = () => {
      closed = true;
      if (pollTimer) clearInterval(pollTimer);
      if (heartbeatTimer) clearInterval(heartbeatTimer);
    };
    request.signal.addEventListener("abort", close, { once: true });

    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        let inFlight = false;
        let lastConversationSignature = "";
        let messageCursor =
          requestedCursor && Types.ObjectId.isValid(requestedCursor)
            ? new Types.ObjectId(requestedCursor)
            : initialCursor;
        let messageState = new Map<string, string>();
        let messageStateInitialized = false;
        // Bounds the first poll's status replay to the reconnect gap rather
        // than the whole 10-minute `recentlyUpdated` window.
        const reconnectFloor = Date.now() - RECONNECT_REPLAY_MS;
        /**
         * Oldest `updatedAt` the next status poll still has to look at.
         *
         * This query was the single most expensive thing the feature does: it
         * re-read up to 500 documents from a fixed 10-minute window every 2.5
         * seconds for every connected agent, serialized each one, and then
         * discarded nearly all of them because their state had not changed.
         * Advancing a watermark instead means a quiet inbox costs an indexed
         * range scan that matches nothing. The emitted frames are identical —
         * the first poll already refused to replay anything older than
         * `reconnectFloor`, so fetching that history was pure waste.
         */
        let statusFloor = new Date(reconnectFloor);

        const enqueue = (chunk: Uint8Array) => {
          if (closed) return;
          try {
            controller.enqueue(chunk);
          } catch {
            close();
          }
        };

        const poll = async () => {
          if (closed || inFlight) return;
          inFlight = true;
          try {
            const { conversations } = await listConversations({
              viewer,
              limit: 100,
            });
            // Stream messages for exactly the threads the client is holding.
            // Deriving the ids from this already-bounded result replaces an
            // unlimited `_id` scan that, for an admin viewer, materialised the
            // entire conversations collection on every 2.5s tick.
            const conversationIds = conversations.map(
              (conversation) => new Types.ObjectId(conversation._id),
            );
            const signature = JSON.stringify(
              conversations.map((conversation) => [
                conversation._id,
                conversation.updatedAt,
                conversation.unreadForCustomer,
                conversation.unreadForStore,
              ]),
            );
            if (signature !== lastConversationSignature) {
              lastConversationSignature = signature;
              enqueue(
                eventFrame("conversation.snapshot", {
                  conversations,
                  serverTime: new Date().toISOString(),
                }),
              );
            }

            if (!conversationIds.length) return;
            const messages = await ConversationMessage.find({
              conversationId: { $in: conversationIds },
              _id: { $gt: messageCursor },
            })
              .sort({ _id: 1 })
              .limit(100)
              .lean();
            for (const message of messages) {
              const messageId = String(message._id);
              messageCursor = message._id as Types.ObjectId;
              enqueue(
                eventFrame(
                  "message.created",
                  serializeConversationMessage(message),
                  messageId,
                ),
              );
            }

            const recentlyUpdated = await ConversationMessage.find({
              conversationId: { $in: conversationIds },
              $expr: { $gt: ["$updatedAt", "$createdAt"] },
              updatedAt: { $gte: statusFloor },
            })
              .sort({ updatedAt: -1, _id: -1 })
              .limit(STATUS_POLL_LIMIT)
              .lean();
            const nextMessageState = new Map<string, string>();
            let newestUpdatedAt = statusFloor.getTime();
            for (const message of recentlyUpdated) {
              const messageId = String(message._id);
              const updatedAt = new Date(message.updatedAt);
              newestUpdatedAt = Math.max(newestUpdatedAt, updatedAt.getTime());
              const state = JSON.stringify([
                message.deliveryStatus,
                message.errorCode,
                message.errorMessage,
                updatedAt.toISOString(),
              ]);
              nextMessageState.set(messageId, state);
              // An absent previous entry means "first seen changed", which is
              // exactly the first delivery tick (queued -> sent) and must be
              // emitted. Comparing `previous` for truthiness swallowed it.
              // On the very first poll everything the watermark returned is
              // inside the reconnect gap, so all of it is worth replaying.
              if (messageStateInitialized && messageState.get(messageId) === state) {
                continue;
              }
              enqueue(
                eventFrame(
                  "message.updated",
                  serializeConversationMessage(message),
                ),
              );
            }
            // A saturated page means rows at or below the oldest one returned
            // were cut off by the limit, so the watermark must stop there
            // instead of jumping to the newest and stranding them — the old
            // fixed 10-minute window forgave that by re-scanning; a watermark
            // does not. `Math.max` keeps the floor monotonic so subtracting the
            // overlap can never walk it backwards.
            const oldestConsumed = recentlyUpdated[recentlyUpdated.length - 1];
            const nextFloor =
              recentlyUpdated.length >= STATUS_POLL_LIMIT && oldestConsumed
                ? new Date(oldestConsumed.updatedAt).getTime()
                : newestUpdatedAt;
            statusFloor = new Date(
              Math.max(
                statusFloor.getTime(),
                nextFloor - STATUS_WATERMARK_OVERLAP_MS,
              ),
            );
            messageState = nextMessageState;
            messageStateInitialized = true;
          } catch (error) {
            console.error("Conversation stream poll failed:", error);
            enqueue(
              eventFrame("stream-error", {
                message: "Live chat is temporarily unavailable",
              }),
            );
          } finally {
            inFlight = false;
          }
        };

        enqueue(encoder.encode("retry: 2500\n\n"));
        enqueue(commentFrame("connected"));
        void poll();
        pollTimer = setInterval(() => void poll(), 2500);
        heartbeatTimer = setInterval(
          () => enqueue(commentFrame(`keep-alive ${Date.now()}`)),
          25000,
        );
      },
      cancel() {
        close();
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
      },
    });
  },
);
