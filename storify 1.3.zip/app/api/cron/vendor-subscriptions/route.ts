import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { reconcileDueSubscriptions } from "@/lib/vendor-plans";
import { revalidateProductContent } from "@/lib/cache-invalidation";
import { reconcileVendorPaymentInvitations } from "@/lib/vendor-payment-invitations";
import { getSettings } from "@/models/settings.model";
import { reconcileStripeVendorSubscriptions } from "@/lib/vendor-billing-reconciliation";

/**
 * Periodic vendor-subscription reconciliation. Advances the dunning state
 * machine (enter grace, retry, expire) for subscriptions whose lifecycle clock
 * has passed, so a lapsed vendor is reconciled even if they never open their
 * dashboard — closing the read-time-only gap of getEffectiveSubscription.
 *
 * Guarded by CRON_SECRET, mirroring /api/cron/email-deliveries.
 */
export async function GET(request: NextRequest) {
  const secret = process.env.CRON_SECRET;
  const authorization = request.headers.get("authorization");
  if (!secret || authorization !== `Bearer ${secret}`) {
    return NextResponse.json(
      { success: false, message: "Unauthorized" },
      { status: 401 },
    );
  }

  await connectDB();
  const settings = await getSettings();
  const [subscriptions, stripeBilling, paymentInvitations] = await Promise.all([
    reconcileDueSubscriptions(100),
    reconcileStripeVendorSubscriptions(settings, 100),
    reconcileVendorPaymentInvitations(settings, 100),
  ]);

  // If any store was deactivated this run (a paid plan lapsed), bust the
  // storefront caches so the now-hidden stores drop out immediately instead of
  // waiting out the approved-vendor list's 60s revalidate window. Done here in
  // the cron's request context — revalidateTag is unsafe from a plain read
  // path, which is why the reconcile function only reports the count.
  if (
    subscriptions.deactivated > 0 ||
    stripeBilling.deactivated > 0 ||
    paymentInvitations.expired > 0
  ) {
    revalidateProductContent();
  }

  return NextResponse.json({
    success: true,
    data: { subscriptions, stripeBilling, paymentInvitations },
  });
}
