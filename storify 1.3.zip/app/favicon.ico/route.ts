/**
 * GET/HEAD /favicon.ico
 *
 * Serves the favicon configured in Admin → Settings → Branding.
 *
 * This has to be a route, not a file in public/. Link-preview crawlers
 * (WhatsApp, Telegram, Slack, Discord, iMessage) don't read the
 * `<link rel="icon">` tags this app renders per store — they request
 * `https://<host>/favicon.ico` by convention and use whatever comes back. A
 * bundled public/favicon.ico therefore branded every tenant's shared links
 * with the app's own icon no matter what they had uploaded.
 *
 * When no favicon is configured this answers 404 on purpose. There is
 * deliberately no bundled fallback: shipping one would put our icon on a
 * store's links, which is the bug this route exists to fix.
 */

import { type NextRequest } from "next/server";
import { DEFAULT_FAVICON_URL } from "@/config/branding.config";
import { getStorefrontMetadataSettings } from "@/lib/storefront-metadata";

// Settings are read per request (the underlying getter is cached and
// settings-tag invalidated) so a favicon change goes live without a rebuild.
export const dynamic = "force-dynamic";

const FALLBACK_CONTENT_TYPE = "image/x-icon";

const CONTENT_TYPES: Record<string, string> = {
  ico: "image/x-icon",
  png: "image/png",
  svg: "image/svg+xml",
  webp: "image/webp",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  avif: "image/avif",
  bmp: "image/bmp",
};

/** Best-effort content type from the URL extension (query string stripped). */
function contentTypeFor(url: string): string {
  const extension = url.split("?")[0].split(".").pop()?.toLowerCase() ?? "";
  return CONTENT_TYPES[extension] ?? FALLBACK_CONTENT_TYPE;
}

function notFound() {
  return new Response(null, {
    status: 404,
    headers: {
      // Short, not immutable: an admin who uploads a favicon should see it
      // appear without waiting out a long-lived negative cache.
      "Cache-Control": "public, max-age=60",
    },
  });
}

export async function GET(request: NextRequest) {
  const { faviconUrl } = await getStorefrontMetadataSettings();

  // `DEFAULT_FAVICON_URL` is this very route, so bailing here is both the
  // "nothing configured" answer and the guard against fetching ourselves.
  if (!faviconUrl || faviconUrl === DEFAULT_FAVICON_URL) return notFound();

  // Uploads are stored as site-relative paths; custom storage (S3, CDN) yields
  // absolute URLs. Resolve against the configured public origin so the fetch
  // works the same either way.
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || request.nextUrl.origin;

  let target: URL;
  try {
    target = new URL(faviconUrl, baseUrl);
  } catch {
    return notFound();
  }

  if (target.protocol !== "http:" && target.protocol !== "https:") {
    return notFound();
  }

  let upstream: Response;
  try {
    upstream = await fetch(target, { cache: "no-store" });
  } catch {
    return notFound();
  }

  if (!upstream.ok || !upstream.body) return notFound();

  return new Response(upstream.body, {
    status: 200,
    headers: {
      "Content-Type":
        upstream.headers.get("content-type") ?? contentTypeFor(faviconUrl),
      // Crawlers re-fetch this constantly; an hour of sharing keeps previews
      // fast while still letting a favicon change propagate the same day.
      "Cache-Control": "public, max-age=3600, stale-while-revalidate=86400",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
