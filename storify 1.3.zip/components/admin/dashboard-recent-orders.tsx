"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useLocale, useTranslations } from "next-intl";
import {
  Banknote,
  CreditCard,
  PackageCheck,
  Smartphone,
  Wallet,
} from "lucide-react";
import { AppImage } from "@/components/ui/app-image";
import { cn, truncateByWords } from "@/lib/utils";
import { useCurrency } from "@/providers/currency-provider";
import type { RecentOrder } from "@/lib/admin/dashboard-types";

function getStatusPill(t: ReturnType<typeof useTranslations>, orderStatus: string) {
  const config: Record<string, { label: string; className: string }> = {
    pending: {
      label: t("admin.dashboardPage.status.pending"),
      className: "bg-red-500/15 text-red-600 dark:text-red-400",
    },
    processing: {
      label: t("admin.dashboardPage.status.processing"),
      className: "bg-blue-500/15 text-blue-700 dark:text-blue-300",
    },
    shipped: {
      label: t("admin.dashboardPage.status.shipped"),
      className: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
    },
    delivered: {
      label: t("admin.dashboardPage.status.delivered"),
      className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
    },
    cancelled: {
      label: t("admin.dashboardPage.status.cancelled"),
      className: "bg-rose-500/15 text-rose-700 dark:text-rose-300",
    },
  };
  return config[orderStatus] || config.pending;
}

function getPaymentMethodMeta(
  t: ReturnType<typeof useTranslations>,
  paymentMethod?: string,
) {
  const key = (paymentMethod || "card").toLowerCase();
  if (key.includes("card")) {
    return { label: t("admin.dashboardPage.payment.creditCard"), Icon: CreditCard };
  }
  if (key.includes("paypal")) {
    return { label: t("admin.dashboardPage.payment.paypal"), Icon: Wallet };
  }
  if (key.includes("razorpay")) return { label: "Razorpay", Icon: Wallet };
  if (key.includes("paystack")) return { label: "Paystack", Icon: Wallet };
  if (key.includes("pesapal")) return { label: "Pesapal", Icon: Wallet };
  if (key.includes("iotec")) return { label: "ioTec Pay", Icon: Wallet };
  if (key.includes("cod") || key.includes("cash")) {
    return { label: t("admin.dashboardPage.payment.cashOnDelivery"), Icon: Banknote };
  }
  if (key.includes("upi")) {
    return { label: t("admin.dashboardPage.payment.upi"), Icon: Smartphone };
  }
  return {
    label: paymentMethod || t("admin.dashboardPage.payment.card"),
    Icon: CreditCard,
  };
}

/** The five newest orders, already flattened server-side to one line per order. */
export function DashboardRecentOrders({ orders }: { orders: RecentOrder[] }) {
  const t = useTranslations();
  const intlLocale = useLocale();
  const params = useParams<{ locale: string }>();
  const locale = params?.locale || intlLocale || "en";
  const { formatPrice } = useCurrency();

  return (
    <section className="rounded-sm border bg-card p-4">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <h3 className="text-xl font-semibold text-foreground">
          {t("admin.dashboardPage.recentOrders")}
        </h3>
        <Link
          href={`/${locale}/admin/orders`}
          className="text-sm text-muted-foreground hover:text-foreground sm:text-base"
        >
          {t("admin.dashboardPage.viewAllOrders")}
        </Link>
      </div>

      <div className="mt-4 space-y-3">
        {orders.length === 0 ? (
          <div className="rounded-xl border border-border px-4 py-10 text-center text-muted-foreground">
            {t("admin.dashboardPage.noRecentOrders")}
          </div>
        ) : (
          orders.map((order) => (
            <RecentOrderCard
              key={order._id}
              order={order}
              locale={locale}
              t={t}
              formatPrice={formatPrice}
            />
          ))
        )}
      </div>
    </section>
  );
}

function RecentOrderCard({
  order,
  locale,
  t,
  formatPrice,
}: {
  order: RecentOrder;
  locale: string;
  t: ReturnType<typeof useTranslations>;
  formatPrice: (amount: number) => string;
}) {
  const statusMeta = getStatusPill(t, order.status);
  const paymentMeta = getPaymentMethodMeta(t, order.paymentMethod);
  const productName = order.primaryItemName;
  const displayProductName = productName
    ? truncateByWords(productName, 5)
    : t("admin.dashboardPage.orderLabel", { orderNumber: order.orderNumber });

  return (
    <Link
      href={`/${locale}/admin/orders/${order._id}`}
      className="grid grid-cols-1 gap-4 rounded-sm border border-border px-4 py-3 transition-colors hover:bg-muted/40 sm:grid-cols-2 lg:grid-cols-[minmax(260px,2.1fr)_1.1fr_0.6fr_0.8fr_1fr_0.7fr]"
    >
      <div className="flex items-center gap-3 sm:col-span-2 lg:col-span-1">
        <div className="relative h-16 w-16 overflow-hidden rounded-lg border border-border bg-muted">
          {order.primaryItemImage ? (
            <AppImage
              src={order.primaryItemImage}
              alt={productName || order.orderNumber}
              fill
              className="object-cover"
              sizes="64px"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-muted text-muted-foreground">
              <PackageCheck className="size-5" />
            </div>
          )}
        </div>
        <div className="min-w-0">
          <p
            className="truncate text-sm font-medium text-foreground"
            title={
              productName && displayProductName !== productName
                ? productName
                : undefined
            }
          >
            {displayProductName}
          </p>
          <p className="text-xs text-muted-foreground">{order.orderNumber}</p>
        </div>
      </div>

      <div>
        <p className="text-xs text-muted-foreground">
          {t("admin.dashboardPage.customer")}
        </p>
        <p className="mt-1 text-sm font-medium text-foreground">
          {order.customerName || t("common.guest")}
        </p>
      </div>

      <div>
        <p className="text-xs text-muted-foreground">{t("common.qty")}</p>
        <p className="mt-1 text-sm font-medium text-foreground">
          {order.itemCount}{" "}
          {order.itemCount === 1
            ? t("admin.dashboardPage.pc")
            : t("admin.dashboardPage.pcs")}
        </p>
      </div>

      <div>
        <p className="text-xs text-muted-foreground">{t("common.status")}</p>
        <span
          className={cn(
            "mt-1 inline-flex rounded-sm px-2 py-1 text-[12px] font-medium",
            statusMeta.className,
          )}
        >
          {statusMeta.label}
        </span>
      </div>

      <div>
        <p className="text-xs text-muted-foreground">
          {t("admin.dashboardPage.paymentMethod")}
        </p>
        <p className="mt-1 inline-flex items-center gap-1.5 text-sm font-medium text-foreground">
          <paymentMeta.Icon className="size-3.5 text-muted-foreground" />
          {paymentMeta.label}
        </p>
      </div>

      <div className="sm:col-span-2 lg:col-span-1 lg:text-right">
        <p className="text-xs text-muted-foreground">
          {t("admin.dashboardPage.totalPrice")}
        </p>
        <p className="mt-1 text-sm font-semibold text-foreground">
          {formatPrice(order.total)}
        </p>
      </div>
    </Link>
  );
}
